// \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/host/inputs.ts
var observers = /* @__PURE__ */ new WeakMap();
function finishNativeInput(mount) {
	if (mount.inputFallbackTimer !== void 0) {
		clearTimeout(mount.inputFallbackTimer);
		mount.inputFallbackTimer = void 0;
	}
	if (!mount.inputFlushScheduled) {
		mount.inputFlushScheduled = true;
		queueMicrotask(() => {
			mount.inputFlushScheduled = false;
			mount.nativeInputPending = false;
			if (!mount.disposed && !mount.faulted) mount.onHostInput?.();
		});
	}
}
function attachInputBoundary(mount) {
	const begin = () => {
		mount.nativeInputPending = true;
		if (mount.inputFallbackTimer === void 0) mount.inputFallbackTimer = setTimeout(() => {
			mount.inputFallbackTimer = void 0;
			if (!mount.disposed && !mount.faulted) finishNativeInput(mount);
		}, 0);
	};
	const finish = () => finishNativeInput(mount);
	mount.container.addEventListener("input", begin, true);
	mount.container.addEventListener("change", begin, true);
	mount.container.addEventListener("input", finish);
	mount.container.addEventListener("change", finish);
	return () => {
		mount.container.removeEventListener("input", begin, true);
		mount.container.removeEventListener("change", begin, true);
		mount.container.removeEventListener("input", finish);
		mount.container.removeEventListener("change", finish);
		if (mount.inputFallbackTimer !== void 0) clearTimeout(mount.inputFallbackTimer);
		mount.inputFallbackTimer = void 0;
		mount.nativeInputPending = false;
	};
}
function observeControlledInput(mount, node, ref, vnode, counts) {
	if (vnode.form?.mode !== "controlled" || observers.has(node)) return;
	const onInput = () => {
		if (mount.disposed || mount.faulted) return;
		const sequence = ++mount.inputSequence;
		mount.dirtyForms.set(ref, sequence);
		if (node.localName === "input" && node.type === "radio" && node.name) {
			const input = node;
			for (const [otherRef, otherNode] of mount.nodes) if (otherNode.nodeType === 1 && otherNode.localName === "input") {
				const other = otherNode;
				if (other.type === "radio" && other.name === input.name && other.form === input.form) mount.dirtyForms.set(otherRef, sequence);
			}
		}
		if (mount.inputFallbackTimer === void 0) mount.inputFallbackTimer = setTimeout(() => {
			mount.inputFallbackTimer = void 0;
			if (!mount.disposed && !mount.faulted) finishNativeInput(mount);
		}, 0);
	};
	node.addEventListener("input", onInput, true);
	node.addEventListener("change", onInput, true);
	counts.listenerAdds += 2;
	observers.set(node, { dispose: (removedCounts) => {
		node.removeEventListener("input", onInput, true);
		node.removeEventListener("change", onInput, true);
		mount.dirtyForms.delete(ref);
		if (removedCounts) removedCounts.listenerRemoves += 2;
	} });
}
function releaseInputObserver(node, counts) {
	observers.get(node)?.dispose(counts);
	observers.delete(node);
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/observe/trace.ts
function emitTrace(sink, event) {
	try {
		sink?.emit(event);
	} catch {}
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/host/events.ts
var listeners = /* @__PURE__ */ new WeakMap();
function setEvent(element, name, binding, counts, mount, ref) {
	let entries = listeners.get(element);
	const old = entries?.get(name);
	if (old && binding && old.binding.capture === binding.capture) {
		old.binding = binding;
		return;
	}
	if (old) {
		element.removeEventListener(name, old.wrapper, old.binding.capture);
		entries.delete(name);
		counts.listenerRemoves++;
	}
	if (!binding) return;
	if (!entries) {
		entries = /* @__PURE__ */ new Map();
		listeners.set(element, entries);
	}
	const listener = {
		binding,
		wrapper: (event) => {
			if (!mount) {
				listener.binding.handler(event);
				return;
			}
			const previous = mount.eventCause, cause = `${mount.id}:event-${++mount.eventSequence}`;
			mount.eventCause = cause;
			emitTrace(mount.trace, {
				causeIds: [cause],
				mountId: mount.id,
				phase: "event",
				nodeRef: ref,
				detail: {
					name,
					capture: listener.binding.capture
				}
			});
			try {
				listener.binding.handler(event);
			} finally {
				mount.eventCause = previous;
			}
		}
	};
	entries.set(name, listener);
	element.addEventListener(name, listener.wrapper, binding.capture);
	counts.listenerAdds++;
}
function clearEvents(node, counts) {
	releaseInputObserver(node, counts);
	if (node.nodeType !== 1) return;
	const element = node;
	listeners.get(element)?.forEach((listener, name) => {
		element.removeEventListener(name, listener.wrapper, listener.binding.capture);
		if (counts) counts.listenerRemoves++;
	});
	listeners.delete(element);
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/vdom.ts
var identity = (key = null) => ({
	key,
	renderedRootKey: null,
	boundaries: []
});
var emptyRoot = () => freezeTree({
	kind: "root",
	children: []
});
var ok = (value) => ({
	ok: true,
	value
});
var fail = (code, message, path) => ({
	ok: false,
	diagnostics: [{
		code,
		message,
		path
	}]
});
function unwrap(result) {
	if (!result.ok) throw new Error(result.diagnostics.map((d) => `${d.code}: ${d.message}`).join("\n"));
	return result.value;
}
function errorDiagnostic(error) {
	return {
		code: "ENGINE_ERROR",
		message: error instanceof Error ? error.message : String(error)
	};
}
var immutableData = /* @__PURE__ */ new WeakSet();
var freezing = /* @__PURE__ */ new WeakSet();
var isImmutableData = (value) => immutableData.has(value);
function freezeTree(value) {
	if (value && typeof value === "object" && !immutableData.has(value)) {
		if (freezing.has(value)) throw new Error("순환 데이터는 VDOM에 사용할 수 없습니다.");
		freezing.add(value);
		try {
			const prototype = Object.getPrototypeOf(value);
			let stable = prototype === null || prototype === Object.prototype || Array.isArray(value) && prototype === Array.prototype;
			for (const key of Reflect.ownKeys(value)) {
				const property = Object.getOwnPropertyDescriptor(value, key);
				if (!Object.hasOwn(property, "value")) {
					stable = false;
					continue;
				}
				const child = property.value;
				freezeTree(child);
				if (child && typeof child === "object" && !immutableData.has(child)) stable = false;
			}
			Object.freeze(value);
			if (stable) immutableData.add(value);
		} finally {
			freezing.delete(value);
		}
	}
	return value;
}
function equalData(a, b) {
	if (Object.is(a, b)) return true;
	if (!a || !b || typeof a !== "object" || typeof b !== "object") return false;
	if (Array.isArray(a) !== Array.isArray(b)) return false;
	const aa = a, bb = b;
	const keys = Object.keys(aa);
	return keys.length === Object.keys(bb).length && keys.every((k) => Object.hasOwn(bb, k) && equalData(aa[k], bb[k]));
}
function compatible(a, b) {
	return a.kind === b.kind && equalData(a.identity, b.identity) && (a.kind !== "element" || b.kind === "element" && a.tag === b.tag);
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/host/browserState.ts
function attachBrowserState(mount) {
	const ending = /* @__PURE__ */ new Set();
	const changed = () => {
		try {
			mount.onCompositionChange?.();
		} catch {}
	};
	const start = (event) => {
		const target = event.target;
		if (!target || !mount.container.contains(target)) return;
		ending.delete(target);
		mount.composing.add(target);
		changed();
	};
	const end = (event) => {
		const target = event.target;
		if (!target || !mount.composing.has(target)) return;
		ending.add(target);
		if (mount.compositionEndTimer === void 0) mount.compositionEndTimer = setTimeout(() => {
			mount.compositionEndTimer = void 0;
			if (mount.disposed) return;
			for (const node of ending) {
				mount.composing.delete(node);
				const ref = mount.refs.get(node);
				if (ref) mount.dirtyForms.set(ref, ++mount.inputSequence);
			}
			ending.clear();
			for (const ref of mount.heldForms) {
				const node = mount.nodes.get(ref);
				if (!node || !isComposing(mount, node)) {
					if (node) mount.dirtyForms.set(ref, ++mount.inputSequence);
					mount.heldForms.delete(ref);
				}
			}
			changed();
			mount.onCompositionEnd?.();
			mount.onHostInput?.();
		}, 0);
	};
	const focus = () => {
		mount.focusVersion++;
	};
	mount.container.addEventListener("compositionstart", start, true);
	mount.container.addEventListener("compositionend", end, true);
	mount.container.ownerDocument.addEventListener("focusin", focus, true);
	return () => {
		mount.container.removeEventListener("compositionstart", start, true);
		mount.container.removeEventListener("compositionend", end, true);
		mount.container.ownerDocument.removeEventListener("focusin", focus, true);
		if (mount.compositionEndTimer !== void 0) clearTimeout(mount.compositionEndTimer);
		mount.compositionEndTimer = void 0;
		mount.composing.clear();
		mount.heldForms.clear();
		ending.clear();
	};
}
function isComposing(mount, node) {
	return [...mount.composing].some((target) => target === node || target.contains(node));
}
function compositionConflict(mount, plan) {
	if (!mount.composing.size) return [];
	const conflicts = /* @__PURE__ */ new Set();
	for (const target of mount.composing) for (const op of plan.operations) {
		if (op.kind === "CREATE_SUBTREE" || op.kind === "SYNC_FORM" || op.kind === "SET_EVENT") continue;
		const node = mount.nodes.get(op.node);
		if (!node) continue;
		const ancestor = node === target || node.contains(target);
		const destructive = op.kind === "REMOVE_SUBTREE" || op.kind === "PLACE_BEFORE" && op.placement === "move";
		const inputMode = (op.kind === "SET_ATTR" || op.kind === "REMOVE_ATTR") && [
			"type",
			"disabled",
			"readonly",
			"inputmode",
			"contenteditable",
			"hidden",
			"inert",
			"form",
			"multiple"
		].includes(op.name.toLowerCase());
		const style = op.kind === "SET_STYLE" || op.kind === "REMOVE_STYLE";
		const editingText = (op.kind === "SET_TEXT" || op.kind === "SET_COMMENT") && target.contains(node);
		if (ancestor && (destructive || inputMode || style) || editingText) conflicts.add(op.node);
	}
	return [...conflicts];
}
function saveSelection(mount) {
	const element = mount.container.ownerDocument.activeElement;
	if (!element || !mount.container.contains(element) || isComposing(mount, element)) return null;
	const ref = mount.refs.get(element);
	if (!ref) return null;
	let range = null;
	if (["input", "textarea"].includes(element.localName)) {
		const field = element;
		if (field.selectionStart !== null && field.selectionEnd !== null) range = {
			start: field.selectionStart,
			end: field.selectionEnd,
			direction: field.selectionDirection ?? "none"
		};
	}
	return {
		element,
		ref,
		focusVersion: mount.focusVersion,
		type: element.getAttribute("type"),
		range
	};
}
function restoreSelection(mount, saved) {
	if (!saved || mount.disposed) return;
	const { element, range } = saved, doc = mount.container.ownerDocument;
	if (!element.isConnected || mount.nodes.get(saved.ref) !== element || !mount.container.contains(element) || element.getAttribute("type") !== saved.type || mount.focusVersion !== saved.focusVersion || isComposing(mount, element)) return;
	if (doc.activeElement !== element) {
		if (doc.activeElement !== doc.body && doc.activeElement !== null) return;
		element.focus({ preventScroll: true });
	}
	if (doc.activeElement === element && range) {
		const field = element;
		const start = Math.min(range.start, field.value.length), end = Math.min(range.end, field.value.length);
		if (field.selectionStart !== start || field.selectionEnd !== end || field.selectionDirection !== range.direction) field.setSelectionRange(start, end, range.direction);
	}
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/mount.ts
var mountSequence = 0;
function createMount(container, trace) {
	const id = `mount-${++mountSequence}`, rootRef = `${id}/root`;
	const mount = {
		id,
		container,
		revision: 0,
		nextCaptureRef: 0,
		disposed: false,
		faulted: false,
		trace,
		dirtyForms: /* @__PURE__ */ new Map(),
		inputSequence: 0,
		inputFlushScheduled: false,
		nativeInputPending: false,
		eventSequence: 0,
		traceCauses: [],
		composing: /* @__PURE__ */ new Set(),
		heldForms: /* @__PURE__ */ new Set(),
		focusVersion: 0,
		view: {
			mountId: id,
			revision: 0,
			rootRef,
			snapshot: emptyRoot(),
			children: []
		},
		nodes: /* @__PURE__ */ new Map([[rootRef, container]]),
		refs: new WeakMap([[container, rootRef]])
	};
	const releaseInput = attachInputBoundary(mount), releaseBrowserState = attachBrowserState(mount);
	mount.disposeHostObservers = () => {
		releaseInput();
		releaseBrowserState();
	};
	return mount;
}
function disposeMount(mount) {
	if (mount.disposed) return;
	mount.disposeHostObservers?.();
	mount.disposeHostObservers = void 0;
	for (const node of mount.nodes.values()) {
		clearEvents(node);
		mount.refs.delete(node);
	}
	mount.nodes.clear();
	mount.dirtyForms.clear();
	mount.onHostInput = void 0;
	mount.onCompositionEnd = void 0;
	mount.onCompositionChange = void 0;
	mount.container.replaceChildren();
	mount.view = {
		...mount.view,
		snapshot: emptyRoot(),
		children: []
	};
	mount.disposed = true;
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/validate.ts
var htmlTags = new Set("a abbr address area article aside audio b bdi bdo blockquote br button canvas caption cite code col colgroup datalist dd del details dfn div dl dt em fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 header hgroup hr i img input ins kbd label legend li main map mark menu meter nav ol optgroup option output p picture pre progress q rp rt ruby s samp search section select small source span strong sub summary sup table tbody td textarea tfoot th thead time tr track u ul var video wbr".split(" "));
var voidTags = new Set("area br col hr img input source track wbr".split(" "));
var booleanAttrs = new Set("allowfullscreen async autofocus autoplay checked controls default defer disabled formnovalidate hidden inert ismap itemscope loop multiple muted nomodule novalidate open playsinline readonly required reversed selected".split(" "));
function attributeProblem(name, value) {
	if (!/^[a-z_][a-z0-9_.:-]*$/i.test(name)) return `잘못된 속성 이름: ${name}`;
	if (/^on/i.test(name) || [
		"srcdoc",
		"is",
		"xmlns",
		"form"
	].includes(name)) return `지원하지 않는 속성: ${name}`;
	if (name === "srcset") for (const candidate of value.split(",")) {
		const [url, ...descriptors] = candidate.trim().split(/\s+/);
		const problem = attributeProblem("src", url);
		if (problem || descriptors.length > 1 || descriptors.some((d) => !/^(\d+w|(?:\d*\.)?\d+x)$/.test(d))) return problem ?? "잘못된 srcset 후보입니다.";
	}
	if ([
		"href",
		"src",
		"action",
		"formaction",
		"poster",
		"cite",
		"xlink:href"
	].includes(name)) {
		const compact = value.replace(/[\u0000-\u0020\u007f]/g, "");
		const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(compact)?.[1].toLowerCase();
		if (scheme && ![
			"https",
			"http",
			"mailto",
			"tel"
		].includes(scheme)) return `허용하지 않는 URL: ${name}`;
	}
	return null;
}
function styleProblem(name, value) {
	if (!/^(--[\w-]+|[a-z-]+)$/.test(name)) return true;
	const decoded = value.replace(/\\([a-f\d]{1,6})\s?|\\(.)/gi, (_, hex, char) => hex ? String.fromCodePoint(Math.min(parseInt(hex, 16), 1114111)) : char ?? "");
	if (/expression\s*\(|@import|behavior\s*:/i.test(decoded) || ["behavior", "-moz-binding"].includes(name)) return true;
	for (const url of decoded.matchAll(/url\s*\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/gi)) if (attributeProblem("src", (url[1] ?? url[2] ?? url[3]).trim())) return true;
	return false;
}
var validatedRoots = /* @__PURE__ */ new WeakSet();
function validateTree(tree) {
	if (validatedRoots.has(tree)) return ok(tree);
	let problem = null;
	let problemPath = "root";
	const rootRadioGroups = /* @__PURE__ */ new Set();
	function children(nodes, path, formGroups = null, selectMode = null) {
		const keys = /* @__PURE__ */ new Set();
		nodes.forEach((node, i) => {
			const here = `${path}/${i}`;
			function reject(message) {
				if (!problem) {
					problem = message;
					problemPath = here;
				}
			}
			if (node.identity.key === "") reject("빈 key는 허용하지 않습니다.");
			if (node.identity.key !== null) {
				if (keys.has(node.identity.key)) reject(`중복 key: ${node.identity.key}`);
				keys.add(node.identity.key);
			}
			if (node.kind !== "element") return;
			if (!htmlTags.has(node.tag)) reject(`미지원 HTML 태그: ${node.tag}`);
			if (voidTags.has(node.tag) && node.children.length) reject(`${node.tag}에는 자식을 넣을 수 없습니다.`);
			for (const [name, value] of Object.entries(node.attrs)) {
				const message = attributeProblem(name, value);
				if (message) reject(message);
				if (name === "style") reject("style은 별도 style 맵을 사용합니다.");
			}
			for (const [name, value] of Object.entries(node.style)) if (styleProblem(name, value.value) || !["", "important"].includes(value.priority)) reject(`미지원 CSS 입력: ${name}`);
			const inputType = (node.attrs.type ?? "text").toLowerCase();
			if (node.tag === "form" && formGroups) reject("form 안에 form을 중첩할 수 없습니다.");
			if (node.tag === "input" && inputType === "radio") {
				if (node.form?.mode === "snapshot" && !formGroups) reject("Phase 1 radio는 영역 내부의 독립된 form 안에 있어야 합니다.");
				const group = node.attrs.name;
				if (group && (node.form?.checked || node.form?.mode === "uncontrolled" && node.form.defaultChecked)) {
					const checked = formGroups ?? rootRadioGroups;
					if (checked.has(group)) reject("같은 radio 그룹에 checked=true를 여러 개 지정할 수 없습니다.");
					checked.add(group);
				}
			}
			if (node.tag === "input" && inputType === "file" && (node.form?.mode === "controlled" || node.form?.value || node.form?.defaultValue)) reject("file input의 선택 파일/value 제어는 지원하지 않습니다.");
			if (node.form && ![
				"input",
				"textarea",
				"select"
			].includes(node.tag)) reject("폼 정책은 input/textarea/select에만 사용합니다.");
			if (node.form && ![
				"snapshot",
				"controlled",
				"uncontrolled"
			].includes(node.form.mode)) reject("잘못된 폼 소유 모드입니다.");
			if (node.form && node.form.mode !== "snapshot") {
				if ([
					"value",
					"checked",
					"selected"
				].some((k) => Object.hasOwn(node.attrs, k))) reject("현재 폼 값은 form 필드로만 지정합니다.");
				if (node.tag === "textarea" && node.children.length) reject("textarea 값은 form 필드로 지정합니다.");
				if (node.form.mode === "uncontrolled" && (node.form.value !== void 0 || node.form.checked !== void 0)) reject("uncontrolled의 초기 값은 defaultValue/defaultChecked를 사용합니다.");
				if (node.form.mode === "controlled" && (node.form.defaultValue !== void 0 || node.form.defaultChecked !== void 0)) reject("controlled에는 default 값을 함께 지정할 수 없습니다.");
				if (node.form.mode === "controlled") {
					if (node.tag === "select" && node.form.selectedIndices === void 0) reject("controlled select는 selectedIndices가 필요합니다.");
					else if (node.tag === "input" && ["checkbox", "radio"].includes(inputType) && node.form.checked === void 0) reject("controlled checkbox/radio는 checked가 필요합니다.");
					else if ((node.tag === "textarea" || node.tag === "input" && ![
						"checkbox",
						"radio",
						"file"
					].includes(inputType)) && node.form.value === void 0) reject("controlled 입력에는 value가 필요합니다.");
				}
			}
			if (node.tag === "option" && selectMode && selectMode !== "snapshot" && Object.hasOwn(node.attrs, "selected")) reject("Phase 2 option 선택은 select의 selectedIndices로만 지정합니다.");
			if (node.form) {
				if (node.form.value !== void 0 && typeof node.form.value !== "string") reject("form.value는 문자열이어야 합니다.");
				if (node.form.checked !== void 0 && typeof node.form.checked !== "boolean") reject("form.checked는 boolean이어야 합니다.");
				if (node.form.selectedIndices !== void 0) {
					if (node.tag !== "select") reject("selectedIndices는 select에만 사용합니다.");
					const indices = node.form.selectedIndices;
					const countOptions = (nodes) => nodes.reduce((n, child) => n + (child.kind === "element" ? child.tag === "option" ? 1 : countOptions(child.children) : 0), 0);
					const count = countOptions(node.children);
					if (indices.some((index) => !Number.isInteger(index) || index < 0 || index >= count) || new Set(indices).size !== indices.length) reject("selectedIndices에 중복 또는 범위 밖의 index가 있습니다.");
					if (!Object.hasOwn(node.attrs, "multiple") && indices.length > 1) reject("single select는 최대 하나만 선택할 수 있습니다.");
				}
				if (node.tag === "select" && (node.form.value !== void 0 || node.form.defaultValue !== void 0 || node.form.checked !== void 0)) reject("select의 현재/초기 선택은 selectedIndices로 지정합니다.");
			}
			for (const name of Object.keys(node.events)) if (!/^[a-z][a-z0-9]*$/.test(name) || name.startsWith("on")) reject(`native 이벤트 이름을 사용하세요: ${name}`);
			children(node.children, here, node.tag === "form" ? /* @__PURE__ */ new Set() : formGroups, node.tag === "select" ? node.form?.mode ?? "uncontrolled" : selectMode);
		});
	}
	children(tree.children, "root");
	if (problem) return fail("INVALID_TREE", problem, problemPath);
	if (isImmutableData(tree)) validatedRoots.add(tree);
	return ok(tree);
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/keyed.ts
function keyedEligibility(old, next) {
	const nodes = [...old.map((entry) => entry.vnode), ...next];
	if (nodes.some((node) => node.kind !== "element")) return "mixed-node-kinds";
	return nodes.some((node) => node.identity.key === null) ? "missing-key" : "keyed";
}
function increasingPositions(slots) {
	const tails = [], predecessors = new Array(slots.length).fill(-1);
	slots.forEach((slot, index) => {
		if (slot.oldIndex === null) return;
		let low = 0, high = tails.length;
		while (low < high) {
			const middle = low + high >>> 1;
			if (slots[tails[middle]].oldIndex < slot.oldIndex) low = middle + 1;
			else high = middle;
		}
		if (low > 0) predecessors[index] = tails[low - 1];
		tails[low] = index;
	});
	const stable = /* @__PURE__ */ new Set();
	let current = tails.at(-1) ?? -1;
	while (current !== -1) {
		stable.add(current);
		current = predecessors[current];
	}
	return stable;
}
function planKeyedChildren(old, next, strategy) {
	if (keyedEligibility(old, next) !== "keyed") return fail("NOT_KEYED", "양쪽 직접 자식이 모두 key가 있는 element여야 합니다.");
	for (const nodes of [old.map((node) => node.vnode), next]) {
		const keys = /* @__PURE__ */ new Set();
		for (const node of nodes) {
			const key = node.identity.key;
			if (!key || keys.has(key)) return fail("DUPLICATE_KEY", `빈 key 또는 중복 key: ${key}`);
			keys.add(key);
		}
	}
	const byKey = new Map(old.map((node, index) => [node.vnode.identity.key, {
		node,
		index
	}]));
	const reused = /* @__PURE__ */ new Set();
	const slots = next.map((vnode, newIndex) => {
		const oldSlot = byKey.get(vnode.identity.key);
		if (!oldSlot || !compatible(oldSlot.node.vnode, vnode)) return {
			newIndex,
			oldIndex: null,
			previous: void 0,
			vnode
		};
		reused.add(oldSlot.node.ref);
		return {
			newIndex,
			oldIndex: oldSlot.index,
			previous: oldSlot.node,
			vnode
		};
	});
	let maximum = -1, monotonic = true;
	const greedyStable = /* @__PURE__ */ new Set();
	for (const slot of slots) if (slot.oldIndex !== null) {
		if (slot.oldIndex < maximum) monotonic = false;
		else {
			maximum = slot.oldIndex;
			greedyStable.add(slot.newIndex);
		}
	}
	const usedLIS = strategy === "lis" && !monotonic;
	const stableNewIndices = usedLIS ? increasingPositions(slots) : greedyStable;
	return ok({
		slots,
		stableNewIndices,
		usedLIS,
		moveNewIndices: slots.filter((slot) => slot.oldIndex !== null && !stableNewIndices.has(slot.newIndex)).map((slot) => slot.newIndex),
		insertNewIndices: slots.filter((slot) => slot.oldIndex === null).map((slot) => slot.newIndex),
		removedRefs: old.filter((node) => !reused.has(node.ref)).map((node) => node.ref)
	});
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/reconcile.ts
var planSequence = 0;
function diff(base, target, options = {}) {
	const validBase = validateTree(base.snapshot);
	if (!validBase.ok) return validBase;
	const valid = validateTree(target);
	if (!valid.ok) return valid;
	const strategy = options.strategy ?? "lis";
	if (![
		"positional",
		"greedy",
		"lis"
	].includes(strategy)) return fail("UNSUPPORTED_STRATEGY", "지원하지 않는 재배치 전략입니다.");
	const id = options.planId ?? `plan-${++planSequence}`;
	let nextRef = 0;
	const creates = [], removes = [], updates = [], placements = [], forms = [];
	const newRefs = /* @__PURE__ */ new Set();
	const reconciliations = [];
	let visitedNodes = 0, reusedSubtrees = 0;
	function create(vnode) {
		const ref = `${base.mountId}/${id}/${++nextRef}`;
		newRefs.add(ref);
		return {
			ref,
			vnode,
			children: vnode.kind === "element" ? vnode.children.map(create) : []
		};
	}
	function elementChanges(old, next, ref) {
		if ([
			"input",
			"textarea",
			"select"
		].includes(next.tag) && (old.form?.mode ?? "uncontrolled") !== (next.form?.mode ?? "uncontrolled")) throw new Error("같은 노드의 폼 소유 모드는 변경할 수 없습니다.");
		for (const name of Object.keys(old.attrs)) if (!Object.hasOwn(next.attrs, name)) updates.push({
			kind: "REMOVE_ATTR",
			node: ref,
			name
		});
		for (const [name, value] of Object.entries(next.attrs)) if (old.attrs[name] !== value) updates.push({
			kind: "SET_ATTR",
			node: ref,
			name,
			value
		});
		for (const name of Object.keys(old.style)) if (!Object.hasOwn(next.style, name)) updates.push({
			kind: "REMOVE_STYLE",
			node: ref,
			name
		});
		for (const [name, value] of Object.entries(next.style)) if (!equalData(old.style[name], value)) updates.push({
			kind: "SET_STYLE",
			node: ref,
			name,
			value
		});
		for (const name of /* @__PURE__ */ new Set([...Object.keys(old.events), ...Object.keys(next.events)])) if (!equalData(old.events[name], next.events[name])) updates.push({
			kind: "SET_EVENT",
			node: ref,
			name,
			binding: next.events[name] ?? null
		});
		if (next.form && (!equalData(old.form, next.form) || !equalData(old.children, next.children) || !equalData(old.attrs, next.attrs) || next.form.mode === "controlled" && options.dirtyFormRefs?.has(ref))) forms.push({
			kind: "SYNC_FORM",
			node: ref,
			policy: next.form
		});
	}
	function reconcileChildren(old, next, parent) {
		function reconcileNode(previous, vnode) {
			visitedNodes++;
			if (options.reuseVNode !== false && previous?.vnode === vnode) {
				reusedSubtrees++;
				if (options.dirtyFormRefs?.size) {
					const syncDirty = (node) => {
						if (options.dirtyFormRefs.has(node.ref) && node.vnode.kind === "element" && node.vnode.form?.mode === "controlled") forms.push({
							kind: "SYNC_FORM",
							node: node.ref,
							policy: node.vnode.form
						});
						node.children.forEach(syncDirty);
					};
					syncDirty(previous);
				}
				return previous;
			}
			if (!previous) {
				const tree = create(vnode);
				creates.push({
					kind: "CREATE_SUBTREE",
					tree
				});
				return tree;
			}
			if (vnode.kind === "element" && previous.vnode.kind === "element") {
				elementChanges(previous.vnode, vnode, previous.ref);
				return {
					ref: previous.ref,
					vnode,
					children: reconcileChildren(previous.children, vnode.children, previous.ref)
				};
			}
			if (vnode.kind !== "element" && previous.vnode.kind !== "element" && vnode.text !== previous.vnode.text) updates.push({
				kind: vnode.kind === "text" ? "SET_TEXT" : "SET_COMMENT",
				node: previous.ref,
				value: vnode.text
			});
			return {
				ref: previous.ref,
				vnode,
				children: []
			};
		}
		const eligibility = strategy === "positional" ? "positional-requested" : keyedEligibility(old, next);
		let result, moved = /* @__PURE__ */ new Set();
		if (eligibility === "keyed" && strategy !== "positional") {
			const keyed = unwrap(planKeyedChildren(old, next, strategy));
			result = keyed.slots.map((slot) => reconcileNode(slot.previous, slot.vnode));
			for (const node of keyed.removedRefs) removes.push({
				kind: "REMOVE_SUBTREE",
				node,
				parent
			});
			moved = new Set(keyed.moveNewIndices);
			reconciliations.push({
				parent,
				strategy,
				reason: "keyed",
				usedLIS: keyed.usedLIS,
				reused: next.length - keyed.insertNewIndices.length,
				inserts: keyed.insertNewIndices.length,
				removes: keyed.removedRefs.length,
				moves: moved.size
			});
		} else {
			let removed = 0, inserted = 0;
			result = next.map((vnode, index) => {
				const previous = old[index];
				if (previous && compatible(previous.vnode, vnode)) return reconcileNode(previous, vnode);
				if (previous) {
					removes.push({
						kind: "REMOVE_SUBTREE",
						node: previous.ref,
						parent
					});
					removed++;
				}
				inserted++;
				return reconcileNode(void 0, vnode);
			});
			for (let i = next.length; i < old.length; i++) {
				removes.push({
					kind: "REMOVE_SUBTREE",
					node: old[i].ref,
					parent
				});
				removed++;
			}
			reconciliations.push({
				parent,
				strategy: "positional",
				reason: eligibility,
				usedLIS: false,
				reused: next.length - inserted,
				inserts: inserted,
				removes: removed,
				moves: 0
			});
		}
		for (let i = result.length - 1; i >= 0; i--) if (newRefs.has(result[i].ref) || moved.has(i)) placements.push({
			kind: "PLACE_BEFORE",
			placement: newRefs.has(result[i].ref) ? "insert" : "move",
			node: result[i].ref,
			parent,
			anchor: result[i + 1]?.ref ?? null
		});
		return result;
	}
	try {
		const children = reconcileChildren(base.children, target.children, base.rootRef);
		const operations = [
			...creates,
			...removes,
			...updates,
			...placements,
			...forms
		];
		return ok({
			id,
			mountId: base.mountId,
			baseRevision: base.revision,
			target,
			nextView: {
				...base,
				revision: base.revision + (operations.length || !equalData(base.snapshot, target) ? 1 : 0),
				snapshot: target,
				children
			},
			operations,
			reconciliations,
			visitedNodes,
			reusedSubtrees
		});
	} catch (error) {
		return fail("DIFF_ERROR", error instanceof Error ? error.message : String(error));
	}
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/planValidation.ts
function equalHostData(a, b) {
	if (a === b) return true;
	if (a.kind !== b.kind) return false;
	if (a.kind !== "element" || b.kind !== "element") return a.kind !== "element" && b.kind !== "element" && a.text === b.text;
	let left = 0, right = 0;
	const aa = a, bb = b;
	for (const key in aa) if (Object.hasOwn(aa, key) && key !== "identity" && key !== "children") {
		left++;
		if (!Object.hasOwn(bb, key) || !equalData(aa[key], bb[key])) return false;
	}
	for (const key in bb) if (Object.hasOwn(bb, key) && key !== "identity" && key !== "children") right++;
	return left === right;
}
function validatePlan(mount, plan) {
	if (mount.disposed || mount.faulted) return fail("MOUNT_UNAVAILABLE", "해제되었거나 오류 상태인 mount입니다.");
	if (plan.mountId !== mount.id || plan.baseRevision !== mount.revision) return fail("STALE_PLAN", "다른 mount 또는 오래된 revision의 계획입니다.");
	const valid = validateTree(plan.target);
	if (!valid.ok) return valid;
	try {
		const changed = plan.operations.length > 0 || !equalData(mount.view.snapshot, plan.target);
		if (plan.nextView.mountId !== mount.id || plan.nextView.rootRef !== mount.view.rootRef || plan.nextView.revision !== mount.revision + (changed ? 1 : 0) || !equalData(plan.nextView.snapshot, plan.target)) throw new Error("nextView의 mount/revision/target이 일치하지 않습니다.");
		const graph = /* @__PURE__ */ new Map();
		const original = /* @__PURE__ */ new Map();
		const created = /* @__PURE__ */ new Set();
		const requireNode = (ref) => {
			const node = graph.get(ref);
			if (!node) throw new Error(`없는 ref: ${ref}`);
			return node;
		};
		const rootRef = mount.view.rootRef;
		graph.set(rootRef, {
			vnode: null,
			parent: null,
			previous: null,
			next: null,
			first: null,
			last: null
		});
		function load(tree, parent, fresh) {
			if (graph.has(tree.ref) || fresh && mount.nodes.has(tree.ref)) throw new Error(`중복 ref: ${tree.ref}`);
			const children = tree.vnode.kind === "element" ? tree.vnode.children : [];
			if (tree.children.length !== children.length || tree.children.some((child, i) => !equalData(child.vnode, children[i]))) throw new Error("ViewNode와 VNode 자식이 다릅니다.");
			graph.set(tree.ref, {
				vnode: tree.vnode,
				parent,
				previous: null,
				next: null,
				first: null,
				last: null
			});
			if (fresh) created.add(tree.ref);
			else original.set(tree.ref, tree.vnode);
			loadChildren(tree.ref, tree.children, fresh);
		}
		function loadChildren(parent, children, fresh) {
			const owner = requireNode(parent);
			owner.first = children[0]?.ref ?? null;
			owner.last = children.at(-1)?.ref ?? null;
			children.forEach((child, i) => {
				load(child, parent, fresh);
				const node = requireNode(child.ref);
				node.previous = children[i - 1]?.ref ?? null;
				node.next = children[i + 1]?.ref ?? null;
			});
		}
		loadChildren(rootRef, mount.view.children, false);
		for (const [ref, entry] of graph) {
			const node = mount.nodes.get(ref);
			if (!node || mount.refs.get(node) !== ref) throw new Error(`DOM binding 불일치: ${ref}`);
			if (ref === rootRef && node !== mount.container) throw new Error("root binding이 container와 다릅니다.");
			if (entry.parent && node.parentNode !== mount.nodes.get(entry.parent)) throw new Error(`DOM parent 불일치: ${ref}`);
			const expectedType = entry.vnode?.kind === "element" ? 1 : entry.vnode?.kind === "text" ? 3 : 8;
			if (entry.vnode && (node.nodeType !== expectedType || entry.vnode.kind === "element" && node.localName !== entry.vnode.tag)) throw new Error(`DOM type 불일치: ${ref}`);
			let child = entry.first;
			for (const domChild of node.childNodes) {
				if (child === null || mount.nodes.get(child) !== domChild) throw new Error(`DOM 자식 구조 변경: ${ref}`);
				child = requireNode(child).next;
			}
			if (child !== null) throw new Error(`DOM 자식 누락: ${ref}`);
		}
		if (graph.size !== mount.nodes.size) throw new Error("mount registry에 view 밖의 ref가 있습니다.");
		function unlink(ref) {
			const node = requireNode(ref);
			if (!node.parent) return;
			const parent = requireNode(node.parent);
			if (node.previous) requireNode(node.previous).next = node.next;
			else parent.first = node.next;
			if (node.next) requireNode(node.next).previous = node.previous;
			else parent.last = node.previous;
			node.parent = node.previous = node.next = null;
		}
		function erase(ref) {
			let child = requireNode(ref).first;
			while (child) {
				const next = requireNode(child).next;
				erase(child);
				child = next;
			}
			graph.delete(ref);
		}
		let lastPhase = 0;
		for (const op of plan.operations) {
			const phase = op.kind === "CREATE_SUBTREE" ? 0 : op.kind === "REMOVE_SUBTREE" ? 1 : op.kind === "PLACE_BEFORE" ? 3 : op.kind === "SYNC_FORM" ? 4 : 2;
			if (phase < lastPhase) throw new Error("Patch 명령의 실행 단계 순서가 잘못되었습니다.");
			lastPhase = phase;
			if (op.kind === "CREATE_SUBTREE") {
				load(op.tree, null, true);
				continue;
			}
			const node = requireNode(op.node);
			if (!node.vnode) throw new Error("container 자체를 수정하는 명령은 허용하지 않습니다.");
			if (op.kind === "REMOVE_SUBTREE") {
				if (node.parent !== op.parent || created.has(op.node)) throw new Error("삭제 parent 또는 대상이 잘못되었습니다.");
				unlink(op.node);
				erase(op.node);
				continue;
			}
			if (op.kind === "PLACE_BEFORE") {
				const parent = requireNode(op.parent);
				if (parent.vnode && parent.vnode.kind !== "element") throw new Error("텍스트/주석은 자식을 가질 수 없습니다.");
				if (op.node === op.anchor || op.node === op.parent) throw new Error("자기 자신을 anchor/parent로 사용할 수 없습니다.");
				if (op.anchor !== null && requireNode(op.anchor).parent !== op.parent) throw new Error("anchor는 해당 parent의 직접 자식이어야 합니다.");
				if (op.placement === "insert" ? !created.has(op.node) || node.parent !== null : created.has(op.node) || node.parent !== op.parent) throw new Error("insert/move 또는 부모 scope가 잘못되었습니다.");
				let ancestor = op.parent;
				while (ancestor) {
					if (ancestor === op.node) throw new Error("순환 배치입니다.");
					ancestor = requireNode(ancestor).parent;
				}
				unlink(op.node);
				node.parent = op.parent;
				node.next = op.anchor;
				node.previous = op.anchor ? requireNode(op.anchor).previous : parent.last;
				if (node.previous) requireNode(node.previous).next = op.node;
				else parent.first = op.node;
				if (op.anchor) requireNode(op.anchor).previous = op.node;
				else parent.last = op.node;
				continue;
			}
			if (op.kind === "SET_TEXT" || op.kind === "SET_COMMENT") {
				if (node.vnode.kind !== (op.kind === "SET_TEXT" ? "text" : "comment")) throw new Error("텍스트/주석 명령의 대상 type이 다릅니다.");
				node.vnode = {
					...node.vnode,
					text: op.value
				};
				continue;
			}
			if (node.vnode.kind !== "element") throw new Error("element 명령의 대상 type이 다릅니다.");
			const value = node.vnode;
			switch (op.kind) {
				case "SET_ATTR":
					node.vnode = {
						...value,
						attrs: {
							...value.attrs,
							[op.name]: op.value
						}
					};
					break;
				case "REMOVE_ATTR": {
					const attrs = { ...value.attrs };
					delete attrs[op.name];
					node.vnode = {
						...value,
						attrs
					};
					break;
				}
				case "SET_STYLE":
					node.vnode = {
						...value,
						style: {
							...value.style,
							[op.name]: op.value
						}
					};
					break;
				case "REMOVE_STYLE": {
					const style = { ...value.style };
					delete style[op.name];
					node.vnode = {
						...value,
						style
					};
					break;
				}
				case "SET_EVENT": {
					const events = { ...value.events };
					if (op.binding) events[op.name] = op.binding;
					else delete events[op.name];
					node.vnode = {
						...value,
						events
					};
					break;
				}
				case "SYNC_FORM":
					node.vnode = {
						...value,
						form: op.policy
					};
					break;
				default: throw new Error("알 수 없는 Patch 명령입니다.");
			}
		}
		const visited = /* @__PURE__ */ new Set([rootRef]);
		function compareChildren(parent, expected) {
			let current = requireNode(parent).first;
			for (const tree of expected) {
				if (current !== tree.ref || visited.has(tree.ref)) throw new Error("계획 실행 결과와 nextView 순서/ref가 다릅니다.");
				visited.add(tree.ref);
				const actual = requireNode(tree.ref), before = original.get(tree.ref);
				if (before && !compatible(before, tree.vnode)) throw new Error("호환되지 않는 identity를 재사용했습니다.");
				if (!actual.vnode || !equalHostData(actual.vnode, tree.vnode)) throw new Error("계획의 host 값이 nextView와 다릅니다.");
				const vnodeChildren = tree.vnode.kind === "element" ? tree.vnode.children : [];
				if (tree.children.length !== vnodeChildren.length || tree.children.some((child, i) => !equalData(child.vnode, vnodeChildren[i]))) throw new Error("nextView의 VNode와 자식 view가 다릅니다.");
				compareChildren(tree.ref, tree.children);
				current = actual.next;
			}
			if (current !== null) throw new Error("계획 실행 후 여분의 자식이 남습니다.");
		}
		if (!equalData(plan.nextView.children.map((n) => n.vnode), plan.target.children)) throw new Error("nextView와 target이 다릅니다.");
		compareChildren(rootRef, plan.nextView.children);
		if (visited.size !== graph.size) throw new Error("배치되지 않은 subtree가 있습니다.");
		return ok(plan);
	} catch (error) {
		return fail("INVALID_PLAN", error instanceof Error ? error.message : String(error));
	}
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/host/forms.ts
function syncForm(element, policy, initial, counts) {
	if (policy.mode === "uncontrolled" && !initial) return;
	const value = policy.mode === "uncontrolled" ? policy.defaultValue : policy.value;
	const checked = policy.mode === "uncontrolled" ? policy.defaultChecked : policy.checked;
	if (value !== void 0 && ["input", "textarea"].includes(element.localName)) {
		const input = element;
		if (initial && policy.mode === "uncontrolled" && input.defaultValue !== value) {
			input.defaultValue = value;
			counts.propertyWrites++;
		}
		if (input.value !== value) {
			input.value = value;
			counts.propertyWrites++;
		} else counts.skippedHostCalls++;
	}
	if (checked !== void 0 && element.localName === "input") {
		const input = element;
		if (initial && policy.mode === "uncontrolled" && input.defaultChecked !== checked) {
			input.defaultChecked = checked;
			counts.propertyWrites++;
		}
		if (input.checked !== checked) {
			input.checked = checked;
			counts.propertyWrites++;
		} else counts.skippedHostCalls++;
	}
	if (policy.selectedIndices !== void 0 && element.localName === "select") {
		const select = element;
		const selected = new Set(policy.selectedIndices);
		if (!select.multiple) {
			const index = policy.selectedIndices[0] ?? -1;
			if (select.selectedIndex !== index) {
				select.selectedIndex = index;
				counts.propertyWrites++;
			}
		} else Array.from(select.options).forEach((option, i) => {
			if (option.selected !== selected.has(i)) {
				option.selected = selected.has(i);
				counts.propertyWrites++;
			}
		});
		if (initial && policy.mode === "uncontrolled") Array.from(select.options).forEach((option, i) => {
			if (option.defaultSelected !== selected.has(i)) {
				option.defaultSelected = selected.has(i);
				counts.propertyWrites++;
			}
		});
	}
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/core/patch.ts
var emptyCounters = () => ({
	createdNodes: 0,
	removedNodes: 0,
	insertedRoots: 0,
	movedRoots: 0,
	textWrites: 0,
	attributeWrites: 0,
	styleWrites: 0,
	propertyWrites: 0,
	listenerAdds: 0,
	listenerRemoves: 0,
	skippedHostCalls: 0
});
function commit(mount, plan) {
	const valid = validatePlan(mount, plan);
	if (!valid.ok) return {
		status: "rejected",
		diagnostics: valid.diagnostics
	};
	const conflicts = compositionConflict(mount, plan);
	if (conflicts.length) {
		emitTrace(mount.trace, {
			causeIds: mount.traceCauses,
			mountId: mount.id,
			phase: "deferred",
			detail: {
				planId: plan.id,
				reason: "composition",
				refs: conflicts
			}
		});
		return {
			status: "deferred",
			reason: "composition",
			refs: conflicts
		};
	}
	const selection = saveSelection(mount);
	const counters = emptyCounters();
	const oldNodes = mount.trace?.detailed ? new Map(mount.nodes) : null;
	const initialForms = [];
	const nodeAt = (ref) => {
		const node = mount.nodes.get(ref);
		if (!node) throw new Error(`찾을 수 없는 ref: ${ref}`);
		return node;
	};
	function create(tree) {
		const vnode = tree.vnode, doc = mount.container.ownerDocument;
		const node = vnode.kind === "element" ? doc.createElement(vnode.tag) : vnode.kind === "text" ? doc.createTextNode(vnode.text) : doc.createComment(vnode.text);
		mount.nodes.set(tree.ref, node);
		mount.refs.set(node, tree.ref);
		counters.createdNodes++;
		if (vnode.kind === "element") {
			const element = node;
			for (const [name, value] of Object.entries(vnode.attrs)) {
				element.setAttribute(name, value);
				counters.attributeWrites++;
			}
			for (const [name, style] of Object.entries(vnode.style)) {
				element.style.setProperty(name, style.value, style.priority);
				counters.styleWrites++;
			}
			observeControlledInput(mount, element, tree.ref, vnode, counters);
			for (const [name, binding] of Object.entries(vnode.events)) setEvent(element, name, binding, counters, mount, tree.ref);
			for (const child of tree.children) element.appendChild(create(child));
			if (vnode.form) initialForms.push({
				element,
				tree
			});
		}
		return node;
	}
	function release(node) {
		for (const child of Array.from(node.childNodes)) release(child);
		clearEvents(node, counters);
		const ref = mount.refs.get(node);
		if (ref) {
			mount.nodes.delete(ref);
			mount.heldForms.delete(ref);
			mount.dirtyForms.delete(ref);
		}
		mount.refs.delete(node);
		counters.removedNodes++;
	}
	try {
		for (const op of plan.operations) switch (op.kind) {
			case "CREATE_SUBTREE":
				create(op.tree);
				break;
			case "REMOVE_SUBTREE": {
				const node = nodeAt(op.node), parent = nodeAt(op.parent);
				if (node.parentNode !== parent) throw new Error("삭제 대상의 parent가 변경되었습니다.");
				parent.removeChild(node);
				release(node);
				break;
			}
			case "SET_TEXT":
			case "SET_COMMENT":
				nodeAt(op.node).nodeValue = op.value;
				counters.textWrites++;
				break;
			case "SET_ATTR":
				nodeAt(op.node).setAttribute(op.name, op.value);
				counters.attributeWrites++;
				break;
			case "REMOVE_ATTR":
				nodeAt(op.node).removeAttribute(op.name);
				counters.attributeWrites++;
				break;
			case "SET_STYLE":
				nodeAt(op.node).style.setProperty(op.name, op.value.value, op.value.priority);
				counters.styleWrites++;
				break;
			case "REMOVE_STYLE":
				nodeAt(op.node).style.removeProperty(op.name);
				counters.styleWrites++;
				break;
			case "SET_EVENT":
				setEvent(nodeAt(op.node), op.name, op.binding, counters, mount, op.node);
				break;
			case "PLACE_BEFORE": {
				const node = nodeAt(op.node), parent = nodeAt(op.parent), anchor = op.anchor === null ? null : nodeAt(op.anchor);
				if (anchor && anchor.parentNode !== parent) throw new Error("anchor가 parent의 직접 자식이 아닙니다.");
				if (node.parentNode === parent && node.nextSibling === anchor) {
					counters.skippedHostCalls++;
					break;
				}
				parent.insertBefore(node, anchor);
				if (op.placement === "insert") counters.insertedRoots++;
				else counters.movedRoots++;
				break;
			}
		}
		for (const { element, tree } of initialForms) if (tree.vnode.kind === "element" && tree.vnode.form) syncForm(element, tree.vnode.form, true, counters);
		for (const op of plan.operations) if (op.kind === "SYNC_FORM") {
			const element = nodeAt(op.node);
			if (isComposing(mount, element)) {
				mount.heldForms.add(op.node);
				continue;
			}
			syncForm(element, op.policy, false, counters);
		}
		restoreSelection(mount, selection);
		mount.view = plan.nextView;
		mount.revision = plan.nextView.revision;
		const status = plan.operations.length === 0 && plan.baseRevision === mount.revision ? "noop" : "committed";
		const identity = oldNodes ? [...mount.nodes].filter(([ref]) => ref !== mount.view.rootRef).map(([ref, node]) => ({
			ref,
			reused: oldNodes.get(ref) === node,
			kind: node.nodeType,
			tag: node.nodeType === 1 ? node.localName : null
		})) : void 0;
		emitTrace(mount.trace, {
			causeIds: mount.traceCauses,
			mountId: mount.id,
			commitId: mount.revision,
			phase: "patch",
			detail: {
				planId: plan.id,
				status,
				...counters,
				...identity ? { identity } : {}
			}
		});
		return {
			status,
			revision: mount.revision,
			counters
		};
	} catch (error) {
		mount.faulted = true;
		return {
			status: "faulted",
			error
		};
	}
}
function applySnapshot(mount, plan) {
	if (!plan.ok) return {
		status: "rejected",
		diagnostics: plan.diagnostics
	};
	emitTrace(mount.trace, {
		causeIds: mount.traceCauses,
		mountId: mount.id,
		phase: "diff",
		detail: {
			planId: plan.value.id,
			operations: plan.value.operations.length,
			reconciliations: plan.value.reconciliations,
			visitedNodes: plan.value.visitedNodes,
			reusedSubtrees: plan.value.reusedSubtrees,
			...mount.trace?.detailed ? {
				before: mount.view.children,
				after: plan.value.nextView.children,
				patches: plan.value.operations
			} : {}
		}
	});
	return commit(mount, plan.value);
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/expression.ts
function normalizeKey(key) {
	if (key === void 0) return null;
	if (typeof key !== "string" && typeof key !== "number") throw new Error("key는 string 또는 number여야 합니다.");
	const normalized = String(key);
	if (!normalized) throw new Error("빈 key는 허용하지 않습니다.");
	return normalized;
}
function h(type, props, ...children) {
	if (typeof type === "function") {
		const { key, ...childProps } = props ?? {};
		return Object.freeze({
			kind: "component-expr",
			type,
			key: normalizeKey(key),
			props: Object.freeze(childProps)
		});
	}
	normalizeKey(props?.key);
	const input = props ?? {};
	const ownedProps = Object.freeze({
		...input,
		...input.attrs ? { attrs: Object.freeze({ ...input.attrs }) } : {},
		...input.style ? { style: Object.freeze(Object.fromEntries(Object.entries(input.style).map(([name, value]) => [name, typeof value === "string" ? value : Object.freeze({ ...value })]))) } : {},
		...input.events ? { events: Object.freeze(Object.fromEntries(Object.entries(input.events).map(([name, value]) => [name, typeof value === "function" ? value : Object.freeze({ ...value })]))) } : {},
		...input.form ? { form: Object.freeze({
			...input.form,
			...input.form.selectedIndices ? { selectedIndices: Object.freeze([...input.form.selectedIndices]) } : {}
		}) } : {}
	});
	const ownChildren = (values) => Object.freeze(values.map((child) => Array.isArray(child) ? ownChildren(child) : child));
	return Object.freeze({
		kind: "element-expr",
		tag: type.toLowerCase(),
		props: ownedProps,
		children: ownChildren(children)
	});
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/stateGuard.ts
function guardState(value, seen = /* @__PURE__ */ new WeakSet()) {
	return value;
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/hooks.ts
var current = null;
var computationDepth = 0;
var isComputing = () => computationDepth > 0;
function pureComputation(callback) {
	const outer = current;
	current = null;
	computationDepth++;
	try {
		return callback();
	} finally {
		computationDepth--;
		current = outer;
	}
}
function renderWithHooks(frame, callback) {
	if (current || computationDepth) throw new Error("렌더 도중 다른 루트를 렌더할 수 없습니다.");
	current = frame;
	computationDepth++;
	try {
		const result = callback();
		if (!frame.mounting && frame.index !== frame.previous.length) throw new Error("Hook 개수가 이전 render와 다릅니다.");
		return result;
	} finally {
		current = null;
		computationDepth--;
	}
}
function slot(kind) {
	if (!current) throw new Error("Hook은 루트 render에서만 호출할 수 있습니다.");
	const frame = current, index = frame.index++, previous = frame.previous[index];
	if (!frame.mounting && (!previous || previous.kind !== kind)) throw new Error(`Hook ${index}의 개수 또는 종류가 변경되었습니다.`);
	return {
		frame,
		index,
		previous
	};
}
function depsChanged(previous, next) {
	if (previous === void 0 || next === void 0) return true;
	if (previous.length !== next.length) throw new Error("deps 길이는 render 사이에 변경할 수 없습니다.");
	return next.some((value, i) => !Object.is(value, previous[i]));
}
var copyDeps = (deps) => deps === void 0 ? void 0 : Object.freeze([...deps]);
function useState(initial) {
	const { frame, index } = slot("state");
	let entry = frame.candidate[index];
	if (!entry) {
		const value = guardState(typeof initial === "function" ? pureComputation(initial) : initial);
		const enqueue = frame.enqueue;
		entry = {
			kind: "state",
			value,
			setter: (action) => enqueue(index, action)
		};
		frame.candidate[index] = entry;
	}
	if (entry.kind !== "state") throw new Error("State 슬롯 불일치");
	return [entry.value, entry.setter];
}
function useMemo(factory, deps) {
	const { frame, index, previous } = slot("memo");
	if (previous?.kind === "memo" && !depsChanged(previous.deps, deps)) {
		frame.onMemo?.(index, true);
		frame.candidate[index] = previous;
		return previous.value;
	}
	const value = pureComputation(factory);
	frame.onMemo?.(index, false);
	frame.candidate[index] = {
		kind: "memo",
		deps: copyDeps(deps),
		value
	};
	return value;
}
function useEffect(setup, deps) {
	const { frame, index, previous } = slot("effect");
	const old = previous?.kind === "effect" ? previous : void 0;
	if (!old || depsChanged(old.deps, deps)) frame.changedEffects.push(index);
	frame.candidate[index] = {
		kind: "effect",
		deps: copyDeps(deps),
		setup,
		cleanup: old?.cleanup
	};
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/resolve.ts
function keyOf(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	const expression = value;
	return expression.kind === "component-expr" ? expression.key : normalizeKey(expression.props.key);
}
function sameExpressionType(a, b) {
	if (!a || !b || typeof a !== "object" || typeof b !== "object" || Array.isArray(a) || Array.isArray(b)) return typeof a === typeof b;
	const aa = a, bb = b;
	if (aa.kind !== bb.kind || keyOf(aa) !== keyOf(bb)) return false;
	return aa.kind === "element-expr" ? bb.kind === "element-expr" && aa.tag === bb.tag : bb.kind === "component-expr" && aa.type === bb.type;
}
function evaluateExpression(value, previous, reuse, onComponent) {
	let componentExecutions = 0, reusedExpressions = 0;
	function resolveOne(value, old, path) {
		if (old && !sameExpressionType(old.expression, value)) old = void 0;
		if (reuse && old && value && typeof value === "object" && old.expression === value) {
			reusedExpressions++;
			onComponent?.({
				path,
				reused: true
			});
			return old;
		}
		const record = (vnode, children = [], result) => ({
			expression: value,
			vnode,
			children,
			result
		});
		if (Array.isArray(value)) throw new Error("컴포넌트는 하나의 root만 반환해야 합니다.");
		if (value === null || value === void 0 || typeof value === "boolean") return record({
			kind: "comment",
			identity: identity(),
			text: "",
			placeholder: true
		});
		if (typeof value === "string" || typeof value === "number") return record({
			kind: "text",
			identity: identity(),
			text: String(value)
		});
		const expr = value;
		if (expr.kind === "component-expr") {
			componentExecutions++;
			onComponent?.({
				path,
				reused: false,
				name: expr.type.name || "anonymous",
				key: expr.key
			});
			const result = resolveOne(pureComputation(() => expr.type(expr.props)), old?.result, `${path}/result`);
			const child = result.vnode;
			return record({
				...child,
				identity: {
					key: expr.key,
					renderedRootKey: child.identity.boundaries.length ? child.identity.renderedRootKey : child.identity.key,
					boundaries: [{
						type: expr.type,
						key: expr.key
					}, ...child.identity.boundaries]
				}
			}, [], result);
		}
		if (expr.kind !== "element-expr") throw new Error("잘못된 render 결과입니다.");
		if (expr.props.form?.selectedIndices !== void 0 && !Array.isArray(expr.props.form.selectedIndices)) throw new Error("selectedIndices는 index 배열이어야 합니다.");
		const attrs = Object.create(null), style = {}, events = {};
		for (const [rawName, input] of Object.entries(expr.props.attrs ?? {})) {
			const name = rawName.toLowerCase();
			if (input === null || input === void 0) continue;
			if (booleanAttrs.has(name)) {
				if (input !== false) attrs[name] = "";
			} else attrs[name] = String(input);
		}
		for (const [name, value] of Object.entries(expr.props.style ?? {})) style[name] = typeof value === "string" ? {
			value,
			priority: ""
		} : { ...value };
		for (const [name, binding] of Object.entries(expr.props.events ?? {})) events[name] = typeof binding === "function" ? {
			handler: binding,
			capture: false
		} : { ...binding };
		function flatten(values) {
			return values.flatMap((child) => Array.isArray(child) ? flatten(child) : [child]);
		}
		const values = flatten(expr.children), oldChildren = old?.children ?? [];
		const keyed = values.every((child) => keyOf(child) !== null) && oldChildren.every((child) => keyOf(child.expression) !== null);
		const byKey = keyed ? new Map(oldChildren.map((child) => [keyOf(child.expression), child])) : null;
		const children = values.map((child, i) => resolveOne(child, byKey ? byKey.get(keyOf(child)) : oldChildren[i], `${path}/${keyed ? `key:${keyOf(child)}` : i}`));
		return record({
			kind: "element",
			identity: identity(normalizeKey(expr.props.key)),
			tag: expr.tag,
			attrs,
			style,
			events,
			form: expr.props.form ? {
				...expr.props.form,
				...expr.props.form.selectedIndices ? { selectedIndices: [...expr.props.form.selectedIndices] } : {}
			} : [
				"input",
				"textarea",
				"select"
			].includes(expr.tag) ? { mode: "uncontrolled" } : null,
			children: children.map((child) => child.vnode)
		}, children);
	}
	const root = resolveOne(value, previous?.root, "root");
	const snapshot = freezeTree({
		kind: "root",
		children: [root.vnode]
	});
	unwrap(validateTree(snapshot));
	return {
		snapshot,
		nextState: { root },
		componentExecutions,
		reusedExpressions
	};
}
function resolveExpression(value) {
	return evaluateExpression(value, null, false).snapshot;
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/updateQueue.ts
function foldStateUpdates(previous, updates, protect = (value) => value) {
	const candidate = previous.map((slot) => ({ ...slot }));
	let processedThrough = 0;
	for (const request of updates) {
		if (request.sequence <= processedThrough) throw new Error("State 요청 sequence는 FIFO 증가 순서여야 합니다.");
		processedThrough = request.sequence;
		const slot = candidate[request.slot];
		if (!slot || slot.kind !== "state") throw new Error("업데이트의 state 슬롯이 없습니다.");
		candidate[request.slot] = {
			...slot,
			value: protect(typeof request.action === "function" ? request.action(slot.value) : request.action)
		};
	}
	return {
		candidate,
		changed: candidate.some((slot, i) => slot.kind === "state" && !Object.is(slot.value, previous[i].value)),
		processedThrough
	};
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/runtime/FunctionComponent.ts
var FunctionComponent = class {
	render;
	props;
	options;
	host;
	errors = [];
	lastResult;
	committedHooks = [];
	queue = [];
	sequence = 0;
	mounted = false;
	started = false;
	disposed = false;
	busy = false;
	halted = false;
	explicitRequested = false;
	evaluation = null;
	scheduled = false;
	scheduleGeneration = 0;
	consecutiveFlushes = 0;
	blockedOnComposition = false;
	constructor(render, props, container, options = {}) {
		this.render = render;
		this.props = props;
		this.options = options;
		if (container.childNodes.length) throw new Error("Phase 2는 빈 전용 container에서 시작합니다.");
		this.host = createMount(container, options.trace);
		this.host.onHostInput = () => {
			if (this.hasWork()) this.requestFlush();
		};
		this.host.onCompositionEnd = () => {
			this.blockedOnComposition = false;
			this.requestFlush();
		};
	}
	get hooks() {
		return this.committedHooks;
	}
	trace(phase, detail, hookIndex) {
		emitTrace(this.options.trace, {
			causeIds: this.host.traceCauses,
			mountId: this.host.id,
			commitId: this.host.revision,
			phase,
			detail,
			hookIndex
		});
	}
	report(error) {
		const diagnostic = errorDiagnostic(error);
		this.errors.push(diagnostic);
		this.trace("error", { message: diagnostic.message });
		try {
			this.options.onError?.(diagnostic);
		} catch {}
	}
	enqueue = (slot, action) => {
		if (isComputing()) throw new Error("render/updater/Memo/자식 평가 중에는 setter를 호출할 수 없습니다.");
		if (this.disposed) {
			this.report(/* @__PURE__ */ new Error("unmount된 루트의 setter를 무시했습니다."));
			return;
		}
		const sequence = ++this.sequence;
		const causeId = this.host.eventCause ?? `${this.host.id}:update-${sequence}`;
		this.queue.push({
			sequence,
			slot,
			action,
			causeId
		});
		this.blockedOnComposition = false;
		emitTrace(this.options.trace, {
			causeIds: [causeId],
			mountId: this.host.id,
			phase: "enqueue",
			detail: {
				sequence,
				slot
			}
		});
		if (this.mounted) this.requestFlush();
	};
	mount() {
		if (this.started || this.disposed) throw new Error("같은 인스턴스는 한 번만 mount할 수 있습니다.");
		if (isComputing()) throw new Error("render 중 mount는 허용하지 않습니다.");
		this.started = true;
		this.busy = true;
		try {
			this.lastResult = this.perform(true, true);
		} finally {
			this.busy = false;
		}
		if (this.hasWork()) this.requestFlush();
		return this.lastResult;
	}
	update(reason = "explicit") {
		if (isComputing()) throw new Error("render 중 update는 허용하지 않습니다.");
		if (!this.started || this.disposed) throw new Error("mount된 루트만 update할 수 있습니다.");
		if (reason === "explicit") {
			this.halted = false;
			this.blockedOnComposition = false;
			this.consecutiveFlushes = 0;
			this.explicitRequested = true;
		}
		this.requestFlush();
	}
	flushForTest() {
		this.scheduleGeneration++;
		this.scheduled = false;
		if (!this.busy && !this.halted && !this.disposed && !this.blockedOnComposition) this.drain(true);
	}
	hasWork() {
		return !!(this.queue.length || this.explicitRequested || this.host.dirtyForms.size);
	}
	requestFlush() {
		if (this.busy || this.halted || this.disposed || this.blockedOnComposition || !this.hasWork()) return;
		if (this.options.batching === "sync") {
			this.drain(true);
			return;
		}
		if (this.scheduled || this.host.nativeInputPending) return;
		this.scheduled = true;
		const generation = ++this.scheduleGeneration;
		queueMicrotask(() => {
			if (generation !== this.scheduleGeneration || this.disposed) return;
			this.scheduled = false;
			if (!this.halted && !this.host.nativeInputPending) this.drain(false);
		});
	}
	drain(all) {
		this.busy = true;
		try {
			while (!this.halted && !this.disposed && !this.blockedOnComposition && this.hasWork()) {
				if (++this.consecutiveFlushes > 50) {
					this.halted = true;
					this.report(/* @__PURE__ */ new Error("연속 50회 초과 갱신을 중단했습니다."));
					break;
				}
				const explicit = this.explicitRequested;
				this.explicitRequested = false;
				this.lastResult = this.perform(!this.mounted, explicit);
				if (this.lastResult.status === "deferred") {
					this.blockedOnComposition = true;
					this.explicitRequested ||= explicit;
					this.consecutiveFlushes = 0;
				}
				if (!all) break;
			}
		} finally {
			this.busy = false;
			if (!this.hasWork()) this.consecutiveFlushes = 0;
		}
		if (this.hasWork()) this.requestFlush();
	}
	perform(mounting, explicit) {
		const clock = () => this.options.onMeasure ? performance.now() : 0;
		const flushStart = clock();
		let renderMs = 0, diffMs = 0, commitMs = 0, effectMs = 0, commitEnd = flushStart;
		const measure = (result) => {
			if (this.options.onMeasure && (result.status === "committed" || result.status === "noop")) {
				const measurement = {
					renderMs,
					diffMs,
					commitMs,
					flushMs: commitEnd - flushStart,
					effectMs
				};
				try {
					this.options.onMeasure(measurement);
				} catch {}
			}
			return result;
		};
		const patch = (snapshot, dirty) => {
			const diffStart = clock();
			const plan = diff(this.host.view, snapshot, {
				strategy: this.options.reconcile,
				dirtyFormRefs: new Set(dirty.keys()),
				reuseVNode: this.options.reuseVNode
			});
			const commitStart = clock();
			diffMs = commitStart - diffStart;
			const result = applySnapshot(this.host, plan);
			commitEnd = clock();
			commitMs = commitEnd - commitStart;
			return result;
		};
		const pending = [...this.queue];
		this.host.traceCauses = [...new Set(pending.map((request) => request.causeId))];
		const previous = this.committedHooks;
		const changedEffects = [];
		const dirty = new Map(this.host.dirtyForms);
		const acknowledgeDirty = () => {
			for (const [ref, sequence] of dirty) if (this.host.dirtyForms.get(ref) === sequence) this.host.dirtyForms.delete(ref);
		};
		try {
			const { candidate, changed, processedThrough: endSequence } = pureComputation(() => foldStateUpdates(previous, pending, guardState));
			if (!mounting && !explicit && !changed) {
				const result = dirty.size ? patch(this.host.view.snapshot, dirty) : {
					status: "noop",
					revision: this.host.revision,
					counters: emptyCounters()
				};
				if (!dirty.size) commitEnd = clock();
				if (result.status === "rejected") throw new Error(result.diagnostics.map((d) => d.message).join("\n"));
				if (result.status === "faulted") {
					this.halted = true;
					this.report(result.error);
					return result;
				}
				if (result.status === "deferred") return result;
				this.queue = this.queue.filter((request) => request.sequence > endSequence);
				acknowledgeDirty();
				return measure(result);
			}
			const frame = {
				previous,
				candidate,
				mounting,
				enqueue: this.enqueue,
				changedEffects,
				index: 0,
				onMemo: (index, reused) => this.trace("memo", { reused }, index)
			};
			this.trace("render", {
				mounting,
				pending: pending.length
			});
			const renderStart = clock();
			const evaluation = evaluateExpression(renderWithHooks(frame, () => this.render(this.props)), this.evaluation, this.options.reuseVNode !== false, (detail) => this.trace("component", detail));
			renderMs = clock() - renderStart;
			const result = patch(evaluation.snapshot, dirty);
			if (result.status === "rejected") throw new Error(result.diagnostics.map((d) => d.message).join("\n"));
			if (result.status === "faulted") {
				this.halted = true;
				this.report(result.error);
				return result;
			}
			if (result.status === "deferred") return result;
			this.committedHooks = candidate;
			this.evaluation = evaluation.nextState;
			this.mounted = true;
			this.queue = this.queue.filter((request) => request.sequence > endSequence);
			acknowledgeDirty();
			const effectStart = clock();
			for (const index of changedEffects) {
				const next = candidate[index];
				if (next.kind === "effect") next.cleanup = void 0;
			}
			for (const index of changedEffects) {
				const old = previous[index];
				if (old?.kind === "effect" && old.cleanup) {
					this.trace("effect-cleanup", {}, index);
					try {
						old.cleanup();
					} catch (error) {
						this.report(error);
					}
				}
			}
			for (const index of changedEffects) {
				if (this.disposed) break;
				const effect = candidate[index];
				if (effect.kind !== "effect") continue;
				this.trace("effect-setup", {}, index);
				try {
					const cleanup = effect.setup();
					if (cleanup !== void 0 && typeof cleanup !== "function") throw new Error("Effect는 cleanup 함수 또는 undefined만 반환해야 합니다.");
					if (typeof cleanup === "function") {
						if (this.disposed) cleanup();
						else effect.cleanup = cleanup;
					}
				} catch (error) {
					this.report(error);
				}
			}
			effectMs = clock() - effectStart;
			return measure(result);
		} catch (error) {
			this.halted = true;
			this.report(error);
			return {
				status: "rejected",
				diagnostics: [errorDiagnostic(error)]
			};
		} finally {
			this.host.traceCauses = [];
		}
	}
	unmount() {
		if (this.disposed) return;
		if (isComputing()) throw new Error("render 중 unmount는 허용하지 않습니다.");
		this.disposed = true;
		this.scheduleGeneration++;
		this.scheduled = false;
		for (const [index, slot] of this.committedHooks.entries()) if (slot.kind === "effect" && slot.cleanup) {
			this.trace("effect-cleanup", {}, index);
			try {
				slot.cleanup();
			} catch (error) {
				this.report(error);
			}
			slot.cleanup = void 0;
		}
		this.queue = [];
		this.committedHooks = [];
		this.evaluation = null;
		this.explicitRequested = false;
		disposeMount(this.host);
	}
};
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/bench/fixtures.ts
var scenarios = [
	"noop",
	"one-change",
	"prepend",
	"delete-middle",
	"last-to-front",
	"first-to-back",
	"reverse",
	"adjacent",
	"swap-ends",
	"shuffle",
	"mixed"
];
function random(seed) {
	let state = seed >>> 0 || 1;
	return () => {
		state ^= state << 13;
		state ^= state >>> 17;
		state ^= state << 5;
		return (state >>> 0) / 4294967296;
	};
}
function shuffle(values, next) {
	const result = [...values];
	for (let i = result.length - 1; i > 0; i--) {
		const j = Math.floor(next() * (i + 1));
		[result[i], result[j]] = [result[j], result[i]];
	}
	return result;
}
function makeFixture(size, scenario, seed, payload) {
	if (!Number.isInteger(size) || size < 2 || size > 1e4 || !scenarios.includes(scenario) || !Number.isInteger(seed)) throw new Error("입력 크기/시나리오/seed를 확인하세요.");
	const oldRows = Array.from({ length: size }, (_, i) => ({
		id: `row-${i}`,
		label: `항목 ${i}`,
		version: 0
	}));
	let newRows = [...oldRows];
	const middle = Math.floor(size / 2), next = random(seed);
	switch (scenario) {
		case "noop": break;
		case "one-change":
			newRows[middle] = {
				...newRows[middle],
				label: "수정된 항목",
				version: 1
			};
			break;
		case "prepend":
			newRows.unshift({
				id: "new-first",
				label: "새 항목",
				version: 0
			});
			break;
		case "delete-middle":
			newRows.splice(middle, 1);
			break;
		case "last-to-front":
			newRows.unshift(newRows.pop());
			break;
		case "first-to-back":
			newRows.push(newRows.shift());
			break;
		case "reverse":
			newRows.reverse();
			break;
		case "adjacent":
			[newRows[middle - 1], newRows[middle]] = [newRows[middle], newRows[middle - 1]];
			break;
		case "swap-ends":
			[newRows[0], newRows[size - 1]] = [newRows[size - 1], newRows[0]];
			break;
		case "shuffle":
			newRows = shuffle(newRows, next);
			break;
		case "mixed": {
			const count = Math.max(1, Math.floor(size / 10));
			const removed = new Set(shuffle(oldRows, next).slice(0, count).map((row) => row.id));
			newRows = shuffle([...oldRows.filter((row) => !removed.has(row.id)), ...Array.from({ length: count }, (_, i) => ({
				id: `new-${i}`,
				label: `신규 ${i}`,
				version: 1
			}))], next);
			break;
		}
	}
	return {
		schemaVersion: 1,
		seed,
		scenario,
		size,
		payload,
		oldRows,
		newRows
	};
}
function rowsExpression(rows, payload) {
	return h("ul", { attrs: { class: "fixture-list" } }, rows.map((row) => h("li", {
		key: row.id,
		attrs: {
			"data-id": row.id,
			"data-version": row.version
		}
	}, h("span", null, row.label), ...payload === "stateful" ? [h("div", null, h("input", {
		attrs: { "aria-label": `${row.id} 메모` },
		form: {
			mode: "uncontrolled",
			defaultValue: row.id
		}
	}), h("input", {
		attrs: {
			type: "checkbox",
			"aria-label": `${row.id} 완료`
		},
		form: {
			mode: "uncontrolled",
			defaultChecked: false
		}
	}), h("strong", null, "중첩 내용"))] : [])));
}
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/bench/noopProfile.ts
var profile = {
	enabled: false,
	rows: {},
	stack: [],
	reset(enabled) {
		this.enabled = enabled;
		this.rows = {};
		this.stack = [];
	},
	span(name, action) {
		if (!this.enabled || this.stack.some((frame) => frame.name === name)) return action();
		const frame = {
			name,
			start: performance.now(),
			child: 0
		};
		this.stack.push(frame);
		try {
			return action();
		} finally {
			const elapsed = performance.now() - frame.start;
			this.stack.pop();
			const row = this.rows[name] ??= {
				calls: 0,
				inclusiveMs: 0,
				selfMs: 0
			};
			row.calls++;
			row.inclusiveMs += elapsed;
			row.selfMs += elapsed - frame.child;
			const parent = this.stack.at(-1);
			if (parent) parent.child += elapsed;
		}
	}
};
// .validation/noop-tail/noop-cpu-diagnostic/candidate-v1/src/bench/noop.ts
var noopPaths = [
	"same-ref",
	"equal-fresh",
	"memo-unrelated",
	"dirty-controlled",
	"reorder",
	"form-update"
];
var ensure = (condition, message) => {
	if (!condition) throw new Error(message);
};
function accepted(result) {
	ensure(result?.status === "committed" || result?.status === "noop", `Commit failed: ${JSON.stringify(result)}`);
}
async function runNoop(input, output) {
	ensure(noopPaths.includes(input.path), "Unknown path");
	const runtime = [
		"memo-unrelated",
		"dirty-controlled",
		"form-update"
	].includes(input.path);
	const fixture = makeFixture(input.size, input.path === "reorder" ? "last-to-front" : "noop", input.seed, input.payload);
	const events = [];
	const trace = input.mode === "counts" ? { emit: (event) => events.push(event) } : void 0;
	const timings = {
		expressionMs: 0,
		renderMs: 0,
		diffMs: 0,
		commitMs: 0,
		flushMs: 0,
		effectMs: 0,
		scheduledCycleMs: 0
	};
	let mount, root, update;
	let collecting = false, effectSetups = 0, effectCleanups = 0;
	let generationProfile = {};
	profile.reset(false);
	try {
		let target;
		if (runtime) {
			const List = () => rowsExpression(fixture.oldRows, fixture.payload);
			root = new FunctionComponent(() => {
				const [n, set] = useState(0);
				update = () => set(input.path === "dirty-controlled" ? 0 : 1);
				const expression = useMemo(() => h(List, {}), []);
				useEffect(() => {
					effectSetups++;
					return () => {
						effectCleanups++;
					};
				}, [n]);
				return h("div", null, expression, h("input", {
					attrs: { "aria-label": "controlled-probe" },
					form: {
						mode: "controlled",
						value: input.path === "form-update" ? String(n) : "fixed"
					}
				}), h("output", null, n));
			}, {}, output, {
				trace,
				reconcile: "lis",
				onMeasure: input.mode !== "counts" ? (sample) => {
					if (collecting) Object.assign(timings, sample);
				} : void 0
			});
			accepted(root.mount());
			mount = root.host;
		} else {
			mount = createMount(output, trace);
			const old = resolveExpression(rowsExpression(fixture.oldRows, fixture.payload));
			accepted(applySnapshot(mount, diff(mount.view, old, { strategy: "lis" })));
			profile.reset(input.mode === "profile");
			performance.mark(window.__noopTraceId + ":generation:start");
			const start = performance.now();
			target = input.path === "same-ref" ? old : resolveExpression(rowsExpression(fixture.newRows, fixture.payload));
			timings.expressionMs = input.path === "same-ref" ? 0 : performance.now() - start;
			performance.mark(window.__noopTraceId + ":generation:end");
			generationProfile = profile.rows;
			profile.reset(false);
		}
		const previous = /* @__PURE__ */ new Map();
		output.querySelectorAll("li").forEach((node, i) => {
			ensure(node.getAttribute("data-id") === fixture.oldRows[i].id, "Initial order mismatch");
			previous.set(fixture.oldRows[i].id, node);
			if (input.payload === "stateful") {
				const [text, checkbox] = node.querySelectorAll("input");
				text.value = `typed:${fixture.oldRows[i].id}`;
				checkbox.checked = true;
			}
		});
		ensure(previous.size === input.size, "Initial size mismatch");
		const control = output.querySelector("[aria-label=\"controlled-probe\"]");
		if (input.path === "dirty-controlled") {
			control.value = "dirty native value";
			const ref = mount.refs.get(control);
			ensure(ref, "Missing controlled binding");
			mount.dirtyForms.set(ref, ++mount.inputSequence);
		}
		events.length = 0;
		effectSetups = effectCleanups = 0;
		profile.reset(input.mode === "profile");
		collecting = true;
		let coreResult;
		performance.mark(window.__noopTraceId + ":cycle:start");
		const start = performance.now();
		if (runtime) {
			update();
			await Promise.resolve();
		} else {
			const plan = diff(mount.view, target, { strategy: "lis" });
			const diffEnd = performance.now();
			coreResult = applySnapshot(mount, plan);
			const end = performance.now();
			timings.diffMs = diffEnd - start;
			timings.commitMs = end - diffEnd;
			timings.flushMs = end - start;
		}
		timings.scheduledCycleMs = performance.now() - start;
		collecting = false;
		performance.mark(window.__noopTraceId + ":cycle:end");
		const cycleProfile = profile.rows;
		profile.reset(false);
		if (!runtime) accepted(coreResult);
		if (runtime) accepted(root.lastResult);
		const expected = fixture.newRows, nodes = output.querySelectorAll("li");
		ensure(nodes.length === expected.length, "Final size mismatch");
		nodes.forEach((node, i) => {
			const row = expected[i];
			ensure(node === previous.get(row.id), `Identity/order mismatch ${row.id}`);
			ensure(node.getAttribute("data-version") === String(row.version) && node.querySelector("span")?.textContent === row.label, `Host data mismatch ${row.id}`);
			if (input.payload === "stateful") {
				const [text, checkbox] = node.querySelectorAll("input");
				ensure(text.value === `typed:${row.id}` && checkbox.checked, `Uncontrolled input lost ${row.id}`);
			}
		});
		if (runtime) {
			ensure(output.querySelector("output")?.textContent === (input.path === "dirty-controlled" ? "0" : "1"), "State mismatch");
			ensure(control.value === (input.path === "form-update" ? "1" : "fixed"), "Controlled value mismatch");
			ensure(effectSetups === (input.path === "dirty-controlled" ? 0 : 1) && effectCleanups === effectSetups, "Effect semantics mismatch");
			ensure(mount.dirtyForms.size === 0, "Dirty input was not acknowledged");
		}
		const counts = {
			...emptyCounters(),
			visitedNodes: 0,
			reusedSubtrees: 0,
			commits: 0,
			rootExecutions: 0,
			childExecutions: 0,
			effectSetups,
			effectCleanups
		};
		for (const event of events) {
			if (event.phase === "patch") {
				counts.commits++;
				for (const key of Object.keys(emptyCounters())) counts[key] += Number(event.detail[key] ?? 0);
			}
			if (event.phase === "diff") {
				counts.visitedNodes += Number(event.detail.visitedNodes);
				counts.reusedSubtrees += Number(event.detail.reusedSubtrees);
			}
			if (event.phase === "render") counts.rootExecutions++;
			if (event.phase === "component" && !event.detail.reused) counts.childExecutions++;
		}
		return {
			input,
			timings: input.mode === "counts" ? null : timings,
			counts: trace ? counts : null,
			profile: input.mode === "profile" ? {
				generation: generationProfile,
				cycle: cycleProfile
			} : null,
			validation: {
				checkedRows: nodes.length,
				retainedIdentities: previous.size,
				controlled: control?.value,
				effectSetups,
				effectCleanups
			},
			visibility: document.visibilityState,
			focused: document.hasFocus()
		};
	} finally {
		profile.reset(false);
		if (root) root.unmount();
		else if (mount) disposeMount(mount);
		ensure(output.childNodes.length === 0, "Unmount left DOM nodes");
		ensure(!mount || mount.nodes.size === 0 && mount.dirtyForms.size === 0 && mount.composing.size === 0, "Unmount left resources");
	}
}
Object.assign(window, { noopBenchmark: { run: (input) => runNoop(input, document.getElementById("benchmark-output")) } });
