# Mini React B안 — 최종 구현 명세서 및 단계별 체크리스트

- 문서 버전: 1.11 (2026-11-09 E3 일반 채택 기각, E4 보관 상한 후보·정확성 검증)
- 작성일: 2026-11-07
- 상태: 최초 M0~M8 및 no-op 인수와 E3의 초기 비교는 역사적 기록으로 보존한다. 실제 TaskApp 후속 작업은 진행 중이다. E3/A1은 1,000개 CRUD의 새 3세션 n=180에서도 toggle 회귀가 반복돼 일반 채택을 기각했다. 10,000개 보충은 첫 세션 완료 뒤 중단·전량 보존했고 100개 보충은 미실행이며, 이를 성능 PASS로 사용하지 않는다. E3 고정 A0/A1 진단 8개 후 인증 보관을 호출당 최대 64개로 제한한 E4(2a21ec7)를 만들었다. 관련 14개·전체 205개·타입/build가 통과했지만 새 정식 비교와 최종 정책·기본 브라우저 3회 인수는 남아 있다. 실제 한글 IME는 이전 사용자 보고(2026-11-07, 브라우저명 미제공)다. 팀 활동·원격 CI는 계속 미확인이다.
- 기준: 공식 W11 요구사항과 앞선 종합 검토의 **B안 — 권장 차별화형**.
- 이 문서의 TypeScript는 모듈 간 계약 예시이며, 이미 존재하는 프로젝트 코드가 아니다.
- 모든 체크박스는 구현 담당자가 증거를 남긴 뒤 완료 처리한다. 과거 독립 모델의 통과 결과를 프로젝트 테스트 통과로 대신하지 않는다.
- 규칙 충돌 시 우선순위: **공식 과제 요구사항 → 이번에 확정한 B안 범위 → 본 문서의 세부 설계 → 참고 보고서의 제안**.

> 기술적 정체성: DOM 정체성과 입력 상태를 지키면서, 리스트 재배치 전략의 비용을 재현 가능한 실험으로 설명하는 Mini React 엔진.

## 목차

1. 최종 범위와 개발 원칙
2. 요구사항 대응표와 기능 ID
3. 아키텍처·모듈·의존 관계
4. 공통 자료구조와 인터페이스
5. Phase 1 동작 명세
6. Phase 2 동작 명세
7. 오류·자원·브라우저 상태 처리
8. Inspector·계측·벤치마크
9. 테스트 명세와 완료 조건
10. 단계별 개발 체크리스트
11. 팀 독립 구현·선정·병합 계약
12. 최종 인수·축소 기준
13. 참고 자료와 검증 상태

---

## 1. 최종 범위와 개발 원칙

### 1.1 반드시 구현할 범위

**과제 필수**

- 실제 DOM → VDOM 변환과 VDOM → DOM 생성.
- Diff와 Patch, 실제 영역·테스트 영역, 테스트 DOM 직접 편집, Patch 버튼.
- VDOM 기반 History, 뒤로가기·앞으로가기, 두 영역 동기화.
- 함수형 컴포넌트와 이를 관리하는 FunctionComponent 클래스.
- 루트의 hooks 배열, mount(), update().
- useState, useEffect, useMemo.
- State와 Hooks는 루트만 소유. 자식은 props만 받는 순수 함수.
- Phase 2가 Phase 1의 공통 VDOM → Diff → Patch 경로를 재사용.
- 입력·클릭으로 동작하는 목록 앱.
- 핵심 모듈 단위 테스트, 통합 테스트, 실제 브라우저 기능 테스트.

**B안 핵심 차별화**

- 동일 identity 계약의 Keyed Greedy와 LIS 두 전략.
- 명시적인 PatchPlan, 안정적인 노드 참조와 anchor.
- FIFO 상태 업데이트 큐와 microtask Batching.
- 필수 useMemo를 이용한 명시적인 계산·하위 표현 재사용.
- 실제 실행 기록을 표시하는 소형 Inspector.
- 프리셋·시드·실패 입력 재현과 단계별 성능 비교.

**제품 완성 작업**

- 예제·초기화·오류 안내·빈 상태·버튼 상태.
- 키보드 조작·입력 라벨·보이는 focus·색상 외 변경 종류 표시.
- 설치·검증·빌드 명령, CI, 실행 가능한 데모, 설계·실험·한계 문서.
- 공개 배포가 불가능한 환경이라면 동일 산출물을 로컬에서 재현하는 절차를 제공한다. 실제 배포는 구현·검증 후 배포 환경에 맞게 수행한다.

### 1.2 이번에는 구현하지 않을 범위

- Fiber, Concurrent Rendering, 우선순위·중단 가능한 Scheduler.
- 독립 상태를 소유하는 외부 Store와 자식 State·Hooks.
- Signal에서 DOM으로 직접 쓰는 우회 경로.
- Adaptive 임계값 정책, Weighted LIS, React 원본 수정.
- 일반 자식 자동 memo, Selector, tracked memo, 다중 결과 LRU Memo.
- 증분 DOM 캡처, 자동 History 구조 공유, 역 Patch.
- Phase 2 Time Travel.
- Named Hooks, draft 상태 API, 범용 transaction·Managed Effect API.
- SSR, Hydration, Server Components, Resumability.
- Worker Diff, 가상 스크롤, 객체 풀링, 해시 기반 재사용.
- moveBefore() 백엔드, keyed Fragment, 다중 host root 컴포넌트.
- 전체 HTML·SVG·Shadow DOM·Custom Element 호환성.

범위 추가는 필수·B안 기능의 완료 후 별도 의사결정으로 다룬다. 구현 중 재미있는 후보를 발견했다는 이유만으로 이 목록을 바꾸지 않는다.

### 1.3 기술·API 선택

- 구현 언어: **TypeScript 권장**. 팀이 JavaScript를 선택하면 동일 계약을 JSDoc과 런타임 검사로 유지한다.
- 런타임: Vanilla DOM API와 자체 엔진. React·Vue·Preact 등 UI 프레임워크를 제출 앱에 사용하지 않는다.
- JSX 변환기는 이번 범위에서 도입하지 않고 h()를 사용한다.
- 테스트·빌드 도구는 UI 런타임과 분리한다. 예: Vitest, Playwright, Vite. 정확한 버전은 구현 시작 시 선택·lockfile 고정.
- DOM 접근은 capture·host·patch·브라우저 테스트에 한정한다.
- diff·keyed·History 저장 모델·업데이트 fold 로직은 DOM 없이 테스트할 수 있어야 한다.
- 기본 전략: 지원되는 keyed 목록에서 **순서 변화가 있을 때만 LIS**. 비교용 Greedy는 항상 유지한다.
- “순서가 그대로면 LIS를 생략”하는 경로는 채택한다. 크기·시간 임계값으로 Greedy/LIS를 선택하는 Adaptive는 구현하지 않는다.

### 1.4 지원 범위

| 범주 | 이번 지원 계약 |
|---|---|
| 일반 DOM | HTML 요소, 텍스트, 공백 텍스트, 주석, 중첩·빈 자식, 루트 아래 여러 노드 |
| 기본 태그 | div/span/p/목록/표/버튼/폼/label/a/img 등 일반 HTML. parser가 만든 tbody 등 정규화된 실제 구조를 기준으로 캡처 |
| 폼 | text·search·number 등 기본 input, checkbox·radio, textarea, select·option·optgroup. 선택 위치는 selectedIndices로 명시 |
| 속성 | 일반 문자열, data-*, aria-*, boolean 속성. style은 별도 맵 |
| 이벤트 | native 이벤트 이름과 Event 객체. input/change/click/submit/composition 및 데모에 필요한 이벤트 |
| 컴포넌트 | 루트 1개. 자식은 하나의 host root 또는 텍스트 또는 빈 결과를 반환 |
| 빈 자식 | null/undefined/boolean을 내부 comment placeholder로 정규화해 위치 슬롯을 보존 |
| 배열 | host children의 배열·중첩 배열은 순서대로 평탄화. 컴포넌트가 다중 root 배열을 반환하는 것은 미지원 |
| 제외 | script 실행, inline on* 문자열, iframe/object/embed, Custom Element, Shadow DOM, SVG/MathML, contentEditable selection의 범용 복원, 파일 input의 선택 파일 복원 |

빈 자식에 comment placeholder를 사용하는 것은 이 엔진의 단순화된 계약이다. 실제 React의 host 출력과 같다고 주장하지 않는다. 숫자 0과 빈 문자열을 빈 자식으로 삭제하지 않는다.

### 1.5 핵심 불변식

- **I-01** 과거 VDOM과 이전 Hook 값은 이후 업데이트로 변형되지 않는다.
- **I-02** Diff는 실제 DOM을 읽거나 쓰지 않는다.
- **I-03** 일반 UI 갱신은 공통 VDOM → Diff → Patch 경로를 통과한다.
- **I-04** 동일 부모·동일 key·호환 type의 지원 대상 노드는 재사용한다.
- **I-05** key가 같아도 type이 다르면 교체한다.
- **I-06** 서로 다른 mount는 DOM 연결 정보를 공유하지 않는다.
- **I-07** 한 번의 큐 처리에서 포함한 모든 상태 요청은 FIFO로 계산된다.
- **I-08** 실패하거나 보류한 render의 Effect는 실행하지 않는다.
- **I-09** History cursor가 가리키는 VDOM과 실제 영역의 committed VDOM이 일치한다.
- **I-10** History 이동 성공 후 실제 영역·테스트 영역의 관리 대상 내용이 일치한다.
- **I-11** 성능 비교 모드가 정확성 계약을 바꾸지 않는다.
- **I-12** 계측은 렌더 결과와 업데이트 순서를 변경하지 않는다.

---

## 2. 요구사항 대응표와 기능 ID

| 기능 ID | 기능 | 과제/B안 구분 | 완료 증거 |
|---|---|---|---|
| P1-01 | 공통 VDOM·DOM 캡처·DOM 생성 | 필수 | T-V01~T-V06 |
| P1-02 | 기본 Diff·PatchPlan | 필수 + B안 구조 | T-D01~T-D04 |
| P1-03 | Keyed Greedy·LIS | B안 | T-K01~T-K07, T-L01~T-L04 |
| P1-04 | DOM·속성·이벤트·폼 Patch | 필수 품질 | T-P01~T-P06, T-B01~T-B05 |
| P1-05 | 실제/테스트 영역·Patch·History | 필수 | T-H01~T-H06 |
| P1-06 | 편집 입력 경계·오류 안내 | 필수 품질 | T-V05, T-E01~T-E03 |
| P2-01 | FunctionComponent·루트 hooks·순수 자식 | 필수 | T-C01~T-C04 |
| P2-02 | useState·FIFO·Batching | 필수 + B안 | T-S01~T-S07 |
| P2-03 | useEffect·cleanup | 필수 | T-F01~T-F07 |
| P2-04 | useMemo·명시적 표현 재사용 | 필수 + B안 | T-M01~T-M04 |
| APP-01 | 목록 앱 | 필수 | T-A01~T-A03 |
| Q-01 | Inspector·Trace | B안 | T-Q01~T-Q03 |
| Q-02 | 전수·시드·브라우저 검증 | 필수 + B안 | 실제 엔진을 호출하는 테스트 결과 |
| Q-03 | 공정한 벤치마크 | B안 | 재현 입력·환경·raw 결과 |
| Q-04 | CI·데모·문서·설명 | 완성 기준 | 인수 체크리스트 |

기능 ID는 개발 작업·PR·테스트·문서에 공통으로 사용한다. 예: “P1-03 구현 / T-K01~T-K06 통과 / T-B03 미완료”.

---

## 3. 아키텍처·모듈·의존 관계

### 3.1 데이터 흐름

```text
Phase 1
실제 영역 최초 캡처 → VDOM V0 → 테스트 영역 생성 → History[V0]
사용자 테스트 DOM 편집 → 전체 캡처 → 검증 → Diff → PatchPlan
  → 실제 영역 Commit → 테스트 영역의 현재 binding 확정 → History 추가

Phase 2
사용자 이벤트 → 루트 업데이트 큐 → 후보 상태 계산
  → 루트 함수 → 순수 자식 평가 → Host VDOM
  → 동일 Diff → 동일 PatchPlan → 동일 DOM Commit
  → 루트 hooks/VDOM/평가 캐시 확정 → Effect cleanup → Effect setup
```

Phase 1의 DOM을 읽는 경로와 Phase 2의 컴포넌트를 실행하는 경로는 다르지만, 최종 Host VDOM과 Diff/Patch 계약은 동일하다.

### 3.2 제안 모듈

아래 경로는 앞으로 만들 구조의 예시이며, 현재 저장소에 존재한다고 가정하지 않는다.

```text
src/
  core/
    types.ts
    vdom.ts
    normalize.ts
    capture.ts
    reconcile.ts
    keyed.ts
    patch.ts
    mount.ts
    host/
      attributes.ts
      styles.ts
      events.ts
      forms.ts
      selection.ts
  runtime/
    FunctionComponent.ts
    expression.ts
    resolve.ts
    hooks.ts
    updateQueue.ts
    flush.ts
  editor/
    controller.ts
    history.ts
    inputPolicy.ts
  observe/
    trace.ts
    metrics.ts
  inspector/
  app/
  bench/
tests/
  unit/
  integration/
  browser/
  fixtures/
  regressions/
```

### 3.3 책임과 금지 사항

| 모듈 | 책임 | 하지 않는 일 |
|---|---|---|
| types/normalize | 공통 표현·입력 정규화·검사 | DOM 쓰기, 상태 저장 |
| capture | 실제 DOM 전체 읽기·현재 binding 구성 | History 추가, 실제 영역 갱신 |
| reconcile/keyed | 대응·변경·이동 계획 계산 | DOM 접근, Effect 실행 |
| patch/host | 명령 실행·폼·이벤트·selection 처리 | 컴포넌트 실행, Hook 계산 |
| mount | mount별 ref↔DOM 연결·revision·생명주기 | 앱 State 소유 |
| FunctionComponent | 루트 상태·후보/확정 상태·전체 갱신 조정 | 자식 State 생성 |
| resolve | 순수 자식 평가·동일 표현 재사용 | 직접 DOM 갱신, 자식 Hook |
| hooks/updateQueue | 슬롯·의존성·FIFO 계산 | History 복원, DOM 쓰기 |
| history | VDOM 버전·cursor·미래 이력 폐기 | 역 Patch, Phase 2 상태 복원 |
| editor controller | 두 영역 갱신 순서·편집→Patch·Undo/Redo | Diff 자체 구현 |
| trace/metrics | 실행 사실 수집 | 렌더 scheduling 변경 |
| inspector/bench/app | UI·비교·시연 | 공통 엔진 내부 계약 우회 |

### 3.4 의존성 규칙

- core는 editor·app·inspector를 import하지 않는다.
- core와 runtime은 trace sink 인터페이스에만 의존한다. Inspector UI를 직접 호출하지 않는다.
- Hook 코드가 DOM 요소를 직접 수정하지 않는다.
- Phase 1 전용 Diff와 Phase 2 전용 Diff를 별도로 만들지 않는다.
- key 매칭·type 판정은 한 곳에서 정의하고 resolver·planner가 같은 계약을 사용한다.
- UI 표시 비용을 엔진 시간에 섞지 않도록 trace 표시를 commit 이후 분리한다.

---

## 4. 공통 자료구조와 인터페이스

타입 예시는 공개 계약의 기준이다. 구현 과정에서 내부 표현을 단순화할 수 있지만 의미를 바꿀 때는 해당 테스트와 문서를 함께 수정한다.

### 4.1 이름·identity

```ts
type Key = string;
type MountId = string;
type NodeRef = string;       // mount 내의 렌더 위치/노드를 가리키는 불투명 ID
type PlanId = string;
type Revision = number;
type CommitId = number;
type HookIndex = number;
type Deps = readonly unknown[] | undefined;

type PureComponent<P = any> = (props: Readonly<P>) => RenderValue;

interface Identity {
  readonly key: Key | null;
  // 컴포넌트 expression의 외부 key와 별개인 반환 host root의 key.
  // 컴포넌트 경계가 없는 일반 host에는 null을 사용한다.
  readonly renderedRootKey: Key | null;
  // 컴포넌트 경계를 지운 뒤에도 type 변경을 판정할 수 있는 메타데이터.
  // DOM 참조나 앱 State가 아니다.
  readonly boundaries: readonly {
    readonly type: PureComponent;
    readonly key: Key | null;
  }[];
}
```

- 공개 h()의 string/number key는 String(key)로 정규화한다. 1과 "1"은 같은 key다.
- Phase 1은 data-key 값을 그대로 사용한다. trim하거나 내용에서 key를 추측하지 않는다.
- 빈 문자열 key는 입력 오류로 처리한다.
- key는 전역 ID가 아니라 같은 부모 아래의 identity다.
- 배열 index처럼 보이는 key를 모두 오류로 처리하지 않는다. 실제 데이터 identity인지 엔진이 일반적으로 판별할 수 없기 때문이다.
- Host type은 node kind와 HTML tag를 포함한다.
- 자식 컴포넌트 type이 바뀌면 같은 host tag를 반환하더라도 그 경계의 캐시·host root를 교체한다.
- 컴포넌트 expression의 key가 부모와의 대응 기준이다. 반환된 host root의 key가 이 외부 key를 덮어쓰지 않는다. 컴포넌트 내부 후손의 key는 별도 형제 범위다.
- 단일 root로 이어지는 컴포넌트 경계의 type과 key를 순서대로 기록한다. 중간 컴포넌트 key가 바뀐 경우도 같은 host tag라는 이유로 재사용하지 않는다. 컴포넌트가 반환한 host root 자체의 key도 내부 경계 판정에 포함한다.
- 호환성 검사는 node kind/tag, boundaries의 type/key 열, renderedRootKey를 함께 비교한다. key의 부모 범위 매칭과 이 type/경계 검사를 분리한다.

### 4.2 Host VDOM

```ts
interface StyleValue {
  readonly value: string;
  readonly priority: "" | "important";
}
type StyleMap = Readonly<Record<string, StyleValue>>;

interface EventBinding {
  readonly handler: (event: Event) => void;
  readonly capture: boolean;
}

interface FormPolicy {
  readonly mode: "snapshot" | "controlled" | "uncontrolled";
  readonly value?: string;
  readonly checked?: boolean;
  readonly selectedIndices?: readonly number[];
  readonly defaultValue?: string;
  readonly defaultChecked?: boolean;
}

interface VText {
  readonly kind: "text";
  readonly identity: Identity;
  readonly text: string;
}
interface VComment {
  readonly kind: "comment";
  readonly identity: Identity;
  readonly text: string;
  readonly placeholder: boolean;
}
interface VElement {
  readonly kind: "element";
  readonly identity: Identity;
  readonly tag: string;                   // HTML tag, 정규화된 소문자
  readonly attrs: Readonly<Record<string, string>>;
  readonly style: StyleMap;               // CSS 이름은 kebab-case 또는 --custom
  readonly events: Readonly<Record<string, EventBinding>>;
  readonly form: FormPolicy | null;
  readonly children: readonly VNode[];
}
type VNode = VElement | VText | VComment;

interface VRoot {
  readonly kind: "root";
  readonly children: readonly VNode[];
}
```

- VRoot는 실제 wrapper를 새로 만드는 노드가 아니다. mount container의 자식 목록을 표현한다.
- attrs에는 일반 attribute를 둔다. style·이벤트·현재 폼 상태는 별도 필드다.
- 캡처한 value/checked attribute와 현재 value/checked property는 구분해 보존한다.
- boolean attribute는 존재 여부가 의미다. disabled="false"는 false로 해석하지 않는다.
- 이벤트 함수는 Phase 2 메모리 내 VDOM에만 존재할 수 있다. DOM 캡처로 기존 addEventListener 함수를 복원한다고 가정하지 않는다.
- Phase 1 History에는 이벤트 함수·DOM 참조 없는 캡처 스냅샷을 저장한다.
- 빈 문자열 텍스트와 공백은 보존한다. filter(Boolean)로 children을 정규화하지 않는다.
- SVG·MathML namespace를 HTML로 잘못 생성하지 말고 미지원 오류로 반환한다.
- 사용자 상태·props·VDOM 객체를 직접 변경하지 않는다. 개발 모드 동결은 지원하는 plain object/array에 한정한다.

### 4.3 컴포넌트 expression

```ts
interface ElementInputProps {
  key?: string | number;
  attrs?: Readonly<Record<string, string | number | boolean | null | undefined>>;
  style?: Readonly<Record<string, string | StyleValue>>;
  events?: Readonly<Record<string, ((event: Event) => void) | EventBinding>>;
  form?: FormPolicy;
}
interface ElementExpr {
  readonly kind: "element-expr";
  readonly tag: string;
  readonly props: ElementInputProps;
  readonly children: readonly RenderValue[];
}
interface ComponentExpr<P = any> {
  readonly kind: "component-expr";
  readonly type: PureComponent<P>;
  readonly key: Key | null;
  readonly props: Readonly<P>;
}
type RenderValue =
  | ElementExpr | ComponentExpr
  | string | number | null | undefined | boolean
  | readonly RenderValue[];

function h(
  tag: string,
  props: ElementInputProps | null,
  ...children: RenderValue[]
): ElementExpr;

function h<P>(
  component: PureComponent<P>,
  props: P & { key?: string | number }
): ComponentExpr<P>;
```

계약:

- h()는 DOM을 만들거나 컴포넌트를 즉시 실행하지 않는다.
- component의 key는 예약 필드이며 자식 props에서 분리한다.
- 자식에게 children이 필요하면 props.children으로 명시적으로 전달한다.
- host children 배열은 평탄화하지만 컴포넌트 반환값은 단일 root로 제한한다.
- null/undefined/boolean은 placeholder comment로 정규화한다.
- 컴포넌트 평가 함수는 DOM 접근·State 변경·Effect 등록 없이 props로 결과를 계산한다.
- managed child 호출은 resolver가 수행한다. 앱 코드에서 자식을 임의로 직접 실행하는 방식은 지원 계약에서 제외한다.
- 동일한 expression 객체를 여러 위치에 사용해도 mount별·위치별로 별도의 DOM 연결을 가진다.

### 4.4 mount와 논리적 view

```ts
interface ViewNode {
  readonly ref: NodeRef;
  readonly vnode: VNode;
  readonly children: readonly ViewNode[];
}
interface MountView {
  readonly mountId: MountId;
  readonly revision: Revision;
  readonly rootRef: NodeRef;
  readonly snapshot: VRoot;
  readonly children: readonly ViewNode[];
}
interface MountHandle {
  readonly id: MountId;
  readonly container: HTMLElement;
  revision: Revision;
  view: MountView;
  readonly nodes: Map<NodeRef, Node>;
  readonly refs: WeakMap<Node, NodeRef>;
  disposed: boolean;
  faulted: boolean;
}
```

- MountView는 DOM 참조를 포함하지 않는다. Diff의 입력으로 사용한다.
- MountHandle은 현재 실제 DOM과의 연결을 소유한다.
- WeakMap의 방향은 **mount별 Node → ref**다. 전역 VNode → DOM 하나로 구현하지 않는다.
- 실제 영역과 테스트 영역은 다른 MountHandle을 사용한다.
- DOM 노드 삭제 시 해당 subtree의 registry와 이벤트 기록을 정리한다.
- history snapshot 안에 ref나 MountHandle을 저장하지 않는다.
- NodeRef는 key와 다르다. 같은 key도 다른 부모·mount에서는 다른 ref다.
- 외부 편집이 가능한 테스트 영역은 캡처 때 현재 DOM으로 view와 binding을 재구성한다.

### 4.5 capture·mount 인터페이스

```ts
interface Diagnostic {
  readonly code: string;
  readonly message: string;
  readonly path?: string;
}
type Result<T> =
  | { ok: true; value: T }
  | { ok: false; diagnostics: readonly Diagnostic[] };

interface CaptureResult {
  readonly snapshot: VRoot;
  readonly view: MountView;
  readonly bindings: ReadonlyMap<NodeRef, Node>;
  readonly visitedNodes: number;
  readonly createdVNodes: number;
}

function captureDOM(mount: MountHandle): Result<CaptureResult>;
function adoptCapture(
  mount: MountHandle,
  captured: CaptureResult
): Result<MountView>;
function createMount(container: HTMLElement): MountHandle;
function disposeMount(mount: MountHandle): void;
```

- captureDOM은 전체 DOM을 읽는다. MutationObserver 캐시를 정확성의 전제로 삼지 않는다.
- captureDOM은 실제 영역을 변경하거나 History를 추가하지 않는다.
- ref 할당과 DOM binding 수집은 허용하되, 편집 결과를 committed snapshot으로 자동 확정하지 않는다.
- 최초 실제 영역은 기존 DOM을 캡처하여 adopt한다. 최초 캡처 자체가 DOM을 불필요하게 재생성하지 않는다.
- 테스트 영역 생성은 캡처 VDOM을 공통 Patch 경로로 빈 mount에 적용한다.
- snapshot mode에서 현재 value/checked/selectedIndices를 읽는다. 파일 input의 파일 목록 등 미지원 상태는 진단한다.
- adoptCapture는 검증된 현재 DOM의 snapshot·ref binding을 해당 mount의 view로 채택하고 revision을 증가시킨다. History를 추가하거나 DOM을 쓰지 않는다. capture 당시 mount ID/revision이 다르면 거절한다.
- adopt 시 제거된 노드의 registry를 정리한다. 캡처 직후 다른 편집이 발생했다면 그 결과를 채택하지 않고 다시 캡처한다. 캡처→검증→채택은 동기 controller 작업으로 묶는다.
- 편집 가능한 테스트 mount의 view는 현재 물리적 DOM을 설명하는 자료다. 이 view를 adopt하는 것과 실제 영역의 History commit은 별개다.
- Phase 2 mount는 빈 전용 container에서 시작한다. 기존 DOM을 adopt하는 진입점은 Phase 1의 명시적인 초기화 경로로 한정한다.

### 4.6 Diff·PatchPlan 인터페이스

```ts
type ReconcileStrategy = "greedy" | "lis";

interface DiffOptions {
  readonly planId: PlanId;
  readonly strategy: ReconcileStrategy;
  readonly reuseVNode: boolean;
  readonly dirtyFormRefs: ReadonlySet<NodeRef>;
}

type PatchOp =
  | { kind: "CREATE_SUBTREE"; tree: ViewNode }
  | { kind: "REMOVE_SUBTREE"; node: NodeRef; parent: NodeRef }
  | { kind: "SET_TEXT"; node: NodeRef; value: string }
  | { kind: "SET_COMMENT"; node: NodeRef; value: string }
  | { kind: "SET_ATTR"; node: NodeRef; name: string; value: string }
  | { kind: "REMOVE_ATTR"; node: NodeRef; name: string }
  | { kind: "SET_STYLE"; node: NodeRef; name: string; value: StyleValue }
  | { kind: "REMOVE_STYLE"; node: NodeRef; name: string }
  | { kind: "SET_EVENT"; node: NodeRef; name: string; binding: EventBinding | null }
  | {
      kind: "PLACE_BEFORE";
      placement: "insert" | "move";
      node: NodeRef;
      parent: NodeRef;
      anchor: NodeRef | null;
    }
  | { kind: "SYNC_FORM"; node: NodeRef; policy: FormPolicy };

interface PatchPlan {
  readonly id: PlanId;
  readonly mountId: MountId;
  readonly baseRevision: Revision;
  readonly target: VRoot;
  readonly nextView: MountView;
  readonly operations: readonly PatchOp[];
}
function diff(
  base: MountView,
  target: VRoot,
  options: DiffOptions
): Result<PatchPlan>;
```

명령 규칙:

1. CREATE_SUBTREE는 분리된 DOM subtree를 만들기 위한 명령이다. 그 하위 노드에 CREATE/INSERT를 중복 발행하지 않는다.
2. REMOVE_SUBTREE는 하위 삭제를 포함한다. 조상 삭제와 후손 삭제를 중복 발행하지 않는다.
3. 교체는 create + remove + insert로 표현한다. 별도 REPLACE가 필요하면 이 조합으로 낮춘다.
4. 새 ref는 plan ID와 로컬 순번으로 충돌 없이 생성한다. 실패한 plan의 ref를 다른 살아 있는 노드에 재사용하지 않는다.
5. anchor는 해당 parent의 직접 자식이거나 null이다. 아직 생성되지 않은 노드를 참조할 수는 있지만, 실행 시에는 생성·배치 순서가 보장되어야 한다.
6. 숫자 index는 설명·계측용으로만 쓴다. 실제 수정 대상을 index만으로 찾지 않는다.
7. 새 subtree 내부 이벤트·폼 초기 상태도 같은 host adapter가 설정한다.
8. dirtyFormRefs는 controlled 입력의 native 편집을 반영한다. 같은 VNode 참조라도 이 ref의 폼 동기화는 별도로 계획할 수 있다.
9. 일반 Diff는 O(N)에 가까운 순회가 기준이다. keyed LIS의 추가 비용은 해당 형제 구간에 한정한다.
10. diff는 오래된 snapshot·view를 수정하지 않으며 DOM·History·Hook queue에 접근하지 않는다.

### 4.7 keyed planner 인터페이스

```ts
interface MatchedSlot {
  readonly newIndex: number;
  readonly oldIndex: number | null;
  readonly ref: NodeRef;
  readonly vnode: VNode;
}
interface ReorderPlan {
  readonly stableNewIndices: ReadonlySet<number>;
  readonly moveNewIndices: readonly number[];
  readonly insertNewIndices: readonly number[];
  readonly removedRefs: readonly NodeRef[];
  readonly usedLIS: boolean;
}
function planKeyedChildren(
  oldChildren: readonly ViewNode[],
  newChildren: readonly VNode[],
  strategy: ReconcileStrategy
): Result<ReorderPlan>;
```

실제 구현에서는 매칭 결과를 입력으로 받아 중복 매칭을 줄일 수 있다. Greedy와 LIS는 같은 key/type 매칭을 공유하고 **남겨둘 노드 선택만** 달라야 한다.

- Greedy: 재사용 oldIndex의 running maximum. 그보다 작은 index를 이동 대상으로 표시.
- LIS: 재사용 oldIndex의 증가 부분수열을 복원하고 그 밖을 이동 대상으로 표시.
- 신규 노드는 LIS 수열에 포함하지 않는다. oldIndex=0을 신규 sentinel로 오인하지 않는다.
- 같은 key라도 type이 달라 재사용하지 못하면 삭제+신규 삽입.
- 두 전략 모두 같은 PLACE_BEFORE executor와 DOM API를 사용한다.
- 공통 executor는 새 순서의 오른쪽부터 anchor를 확정한다. 따라서 Greedy는 **React식 이동 판정 비교군**이지 React 전체 commit 순서 복제본이 아니다.
- 지원 조건: 같은 부모 아래의 양쪽 목록에서 모든 직접 자식이 고유 key를 가진 element. 빈 목록은 허용.
- key 누락·텍스트/주석 혼재는 일반 positional diff. 공백 텍스트도 임의 제거하지 않는다.
- 중복 key는 일반 Diff로 숨기지 않고 사전 오류로 처리한다.
- positional 경로도 같은 위치에서 key 또는 호환 type이 바뀌면 교체한다. 혼합 목록에서는 key를 따라 다른 index로 이동하는 재사용을 보장하지 않는다.
- 순서가 증가하면 LIS 계산을 건너뛴다. 작은 n이라는 이유로 다른 알고리즘을 고르는 임계값은 두지 않는다.

### 4.8 Commit 인터페이스

```ts
interface CommitCounters {
  createdNodes: number;
  removedNodes: number;
  insertedRoots: number;
  movedRoots: number;
  textWrites: number;
  attributeWrites: number;
  styleWrites: number;
  propertyWrites: number;
  listenerAdds: number;
  listenerRemoves: number;
  skippedHostCalls: number;
}
type CommitResult =
  | { status: "committed"; revision: Revision; counters: CommitCounters }
  | { status: "noop"; revision: Revision; counters: CommitCounters }
  | { status: "deferred"; reason: "composition" }
  | { status: "rejected"; diagnostics: readonly Diagnostic[] }
  | { status: "faulted"; error: unknown };

function commit(mount: MountHandle, plan: PatchPlan): CommitResult;
```

실행 순서:

1. mount ID·revision·지원 shape·ref·부모·anchor의 계획상 유효성 검사.
2. IME 충돌 여부 검사. 보류할 경우 DOM을 쓰지 않는다.
3. focus·지원 selection 정보 저장.
4. 신규 subtree를 detached 상태로 준비.
5. 제거 → 재사용 노드의 텍스트/속성/style/event 변경 → 배치.
6. 자식 목록·option 갱신 후 폼 property 동기화.
7. 살아남은 입력의 focus·지원 selection 보정.
8. 현재 view와 registry를 확정하고 revision 갱신.
9. 호출자에게 결과 반환. Effect와 History 확정은 호출자 책임.

DOM API가 예상하지 못한 예외를 던지면 전체 rollback을 보장하지 않는다. mount를 faulted로 두고 후속 Patch를 막은 뒤 초기화 경로를 제공한다.

“noop”은 실행할 변경이 없고 target도 현재 view와 의미상 동일한 경우다. DOM 작업은 없어도 key·이벤트·폼 정책 등 논리적 view가 바뀌면 새 view를 확정해야 한다.

### 4.9 History 인터페이스

```ts
interface HistoryEntry {
  readonly version: number;
  readonly snapshot: VRoot;
  readonly label: string;
}
interface HistoryState {
  readonly entries: readonly HistoryEntry[];
  readonly cursor: number;
}
function createHistory(initial: VRoot): HistoryState;
function pushHistory(
  history: HistoryState,
  next: VRoot,
  label: string
): HistoryState;
function getHistoryTarget(
  history: HistoryState,
  direction: "undo" | "redo"
): HistoryEntry | null;
function moveHistoryCursor(
  history: HistoryState,
  targetVersion: number
): HistoryState;
```

- version은 고유하게 증가한다. 배열 index와 혼동하지 않는다.
- 뒤로 간 뒤 새 변경을 확정하면 cursor 뒤의 미래 이력을 버린다.
- 의미상 동일한 캡처는 새 항목을 만들지 않는다.
- snapshot 저장 후 deep clone을 반복하지 않는다. 캡처가 만든 독립 불변 트리를 저장한다.
- 구조 공유를 위한 별도 canonicalization·hash·객체 풀은 도입하지 않는다.
- History의 초기 형태는 전체 스냅샷이므로 보관 비용은 대략 O(버전 수 × 트리 크기)다. 메모리 절감 성과를 주장하지 않는다.
- History 자체는 DOM을 수정하지 않는다. 두 영역 갱신 성공 후 controller가 cursor를 바꾼다.

### 4.10 Root·Hooks·업데이트 큐 인터페이스

```ts
type StateAction<T> = T | ((previous: T) => T);
type StateSetter<T> = (action: StateAction<T>) => void;
type EffectCleanup = () => void;
type EffectSetup = () => void | EffectCleanup;

type HookSlot =
  | { kind: "state"; value: unknown; setter: StateSetter<any> }
  | { kind: "memo"; deps: Deps; value: unknown }
  | {
      kind: "effect";
      deps: Deps;
      setup: EffectSetup;
      cleanup: EffectCleanup | undefined;
    };

interface StateUpdate {
  readonly sequence: number;
  readonly slot: HookIndex;
  readonly action: StateAction<unknown>;
  readonly causeId: string;
}
interface EngineOptions {
  reconcile: "greedy" | "lis";
  batching: "sync" | "microtask";
  reuseVNode: boolean;
  trace: "off" | "summary" | "detail";
  metrics: "off" | "counts" | "timing";
}

class FunctionComponent<P> {
  readonly hooks: HookSlot[]; // 외부 수정 금지. 과제 요구사항에 따라 배열로 보유한다.
  constructor(
    render: (props: Readonly<P>) => RenderValue,
    props: Readonly<P>,
    container: HTMLElement,
    options: EngineOptions
  );
  mount(): CommitResult;
  update(reason?: "state" | "explicit"): void;
  flushForTest(): void;
  unmount(): void;
}

function useState<T>(initial: T | (() => T)): [T, StateSetter<T>];
function useEffect(setup: EffectSetup, deps?: readonly unknown[]): void;
function useMemo<T>(factory: () => T, deps?: readonly unknown[]): T;
```

- mount()는 최초 렌더를 수행한다. 같은 인스턴스의 중복 mount는 오류다.
- update()는 기본적으로 업데이트를 예약한다. state 사유는 상태 동등성에 따라 렌더를 생략할 수 있다.
- explicit update는 앱 State가 같아도 렌더 요청을 처리한다.
- flushForTest()는 일반 앱 API로 쓰지 않는다. 테스트에서 명시적으로 큐를 완료시키기 위한 진입점이다.
- unmount()는 idempotent하게 동작하고 Effect·이벤트·예약 작업을 정리한다.
- State setter는 루트와 Hook 슬롯을 캡처한다. 호출 때의 currentHookIndex를 사용하지 않는다.
- StateUpdate는 루트의 단일 sequence 순서로 처리한다. child별 queue는 없다.

### 4.11 순수 자식 평가·재사용 계약

```ts
interface EvaluationState {
  // 구현 소유의 불투명 기록. mount 위치 + 부모 scope + key/슬롯 + type으로 구분.
  readonly records: unknown;
}
interface EvaluationResult {
  readonly snapshot: VRoot;
  readonly nextState: EvaluationState;
  readonly componentExecutions: number;
  readonly reusedExpressions: number;
}
function resolveExpression(
  expression: RenderValue,
  previous: EvaluationState | null,
  reuseVNode: boolean
): Result<EvaluationResult>;
```

- 실제 DOM 참조는 EvaluationState에 넣지 않는다.
- 같은 렌더 위치의 같은 type·key이고 expression 참조가 같을 때만 이전 결과를 재사용한다.
- 같은 함수라는 이유로 모든 인스턴스가 캐시 하나를 공유하지 않는다.
- 후보 평가 기록은 commit 성공 후에만 현재 기록으로 확정한다.
- 일반 props shallow 비교·deep 비교·LRU는 구현하지 않는다.
- 루트가 만든 새 expression은 기본적으로 평가한다.
- 동일 VNode 재사용을 비활성화해도 결과와 Effect 의미론은 유지되어야 한다.
- stateful DOM의 native 변경은 별도 dirty form 동기화 규칙을 따른다. 참조가 같다는 이유로 controlled 입력 복원을 생략하지 않는다.

### 4.12 Trace·벤치마크 인터페이스

```ts
interface TraceEvent {
  readonly causeIds: readonly string[];
  readonly mountId: MountId;
  readonly commitId?: CommitId;
  readonly phase:
    | "event" | "enqueue" | "render" | "component" | "memo"
    | "diff" | "patch" | "effect-cleanup" | "effect-setup" | "error";
  readonly nodeRef?: NodeRef;
  readonly hookIndex?: HookIndex;
  readonly detail: Readonly<Record<string, unknown>>;
}
interface TraceSink {
  emit(event: TraceEvent): void;
}
interface BenchmarkCase {
  readonly id: string;
  readonly size: number;
  readonly seed: number;
  readonly payload: "light" | "stateful";
  readonly oldTree: VRoot;
  readonly newTree: VRoot;
}
```

- Trace에는 live DOM·Event 객체·cleanup 함수 등을 그대로 보관하지 않는다.
- 식별자와 값 요약을 저장한다. 거대한 트리 전체는 선택한 사례에서만 별도 보관한다.
- 로그는 기본 최근 100 commit 범위의 ring buffer로 제한한다. 이는 History 제한과 별개다.
- count run과 timing run을 구분한다. timing run에서는 상세 trace와 Inspector 갱신을 끈다.
- 실패 fixture에는 이벤트 함수 대신 정의된 handler ID를 사용하고, 테스트가 ID를 함수로 다시 연결한다.

---

## 5. Phase 1 동작 명세

### 5.1 최초 로드

1. 실제 영역의 샘플 DOM을 준비한다.
2. 실제 영역을 createMount 후 captureDOM으로 adopt한다.
3. 최초 VDOM V0를 History 첫 항목으로 저장한다.
4. 빈 테스트 영역에 V0를 diff/commit으로 렌더링한다.
5. 두 영역의 관리 대상 구조·속성·폼 값 일치를 확인한다.
6. Undo/Redo는 모두 비활성 상태다.

초기 실제 영역을 무조건 innerHTML로 다시 생성하지 않는다. DOM→VDOM 과정이 실제로 사용되어야 한다.

### 5.2 테스트 영역 직접 편집

필수 UI:

- 실제 영역, 테스트 영역, Patch, Undo, Redo, 초기화.
- 테스트 영역의 텍스트 직접 편집.
- 선택 노드의 태그·속성·폼 값을 변경하는 간단한 편집 도구.
- 자식 추가·삭제·이동 도구 또는 동일 동작이 가능한 HTML 편집 경로.
- 테스트 영역의 변경은 Patch 전까지 실제 영역과 History에 반영하지 않는다.

HTML 문자열을 받는 경우 inert한 파싱 단계에서 지원 태그·속성·URL을 검사한 뒤 DOM에 연결한다. 붙여넣기도 같은 경계를 통과시킨다. contentEditable의 native HTML 붙여넣기를 허용해 놓고 나중의 Patch 시점에만 검사하는 것으로 안전성을 보장하지 않는다.

스크립트·inline on*·위험한 URL·미지원 namespace·Custom Element는 거부한다. textContent를 사용하는 것만으로 모든 HTML 입력이 안전해진다고 주장하지 않는다.

DevTools나 임의 외부 스크립트가 이미 실행한 코드를 이 엔진이 되돌린다고 보장하지 않는다.

### 5.3 Patch 버튼

1. composition 중이면 적용을 보류하고 안내한다.
2. 현재 테스트 DOM 전체를 captureDOM으로 읽는다.
3. 지원 범위·key·폼 상태를 검사한다.
4. 현재 실제 영역의 committed view와 새 snapshot을 diff한다.
5. 실제 영역에 commit한다.
6. commit 성공 후 테스트 영역의 캡처 binding을 최신 view로 채택한다.
7. History에 새 snapshot을 넣는다. 의미상 no-op이면 항목 추가하지 않는다.
8. Inspector와 버튼 상태를 갱신한다.

실제 영역을 통째로 교체해서 Diff 오류를 숨기지 않는다. 의도적인 전체 재생성 모드는 비교용 실험실에만 둔다.

### 5.4 Undo/Redo

- 실제 영역 기준: 현재 committed VDOM.
- 테스트 영역 기준: **현재 편집 DOM을 새로 캡처한 VDOM**.
- 테스트 캡처를 검증한 뒤 adoptCapture로 현재 binding/view를 먼저 맞추고, 반환된 최신 revision을 기준으로 plan을 계산한다. 과거 committed binding으로 새 캡처 plan을 실행하지 않는다.
- 목표: 선택한 History snapshot.
- 두 영역 각각 별도 plan을 만들고 먼저 검증한다.
- 두 commit이 성공한 뒤 History cursor를 바꾼다.
- Undo/Redo 자체는 새 History를 만들지 않는다.
- 미확정 테스트 편집은 선택한 과거/미래 버전으로 덮어쓴다.
- 이동할 항목이 없으면 버튼 비활성화와 no-op.
- composition 중에는 History 이동 버튼을 비활성화하고 programmatic 요청도 거부한다.
- 두 영역의 원자적 rollback은 보장하지 않는다. 적용 도중 예외가 나면 fault 상태로 전환하고 마지막 정상 History를 기준으로 초기화할 수 있게 한다.

### 5.5 Keyed 경로에서 제외되는 예시

```html
<ul>
  <li data-key="a">A</li>
  <li data-key="b">B</li>
</ul>
```

위 HTML에는 실제 공백 텍스트가 포함될 수 있다. 따라서 이 목록은 혼합 노드로 판정되어 positional 경로를 사용할 수 있다. 예제 프리셋은 공백 없는 직접 keyed 자식 목록도 제공하여 LIS 경로를 확실하게 시연한다.

Inspector에는 “텍스트/주석이 섞여 keyed 최적화 미적용”처럼 이유를 표시한다. 전체 capture에서 공백을 삭제해 문제를 숨기지 않는다.

---

## 6. Phase 2 동작 명세

### 6.1 루트 갱신의 단계

1. 큐에서 이번 flush가 처리할 마지막 sequence를 고정한다.
2. 확정된 state 슬롯에서 후보 state를 FIFO로 계산한다.
3. 모든 state가 Object.is로 같고 explicit 요청도 없으면 함수 실행을 생략할 수 있다.
4. 단, dirty controlled 입력은 현재 VDOM 정책으로 PatchPlan을 만들어 복원한다.
5. 루트 함수 실행 동안만 root Hook dispatcher를 활성화한다.
6. 함수 종료 시 Hook 개수·종류를 검사한다.
7. dispatcher를 비활성화하고 순수 자식을 평가한다.
8. 새 VDOM과 PatchPlan을 계산한다.
9. commit한다.
10. 성공한 경우에만 후보 hooks·VDOM·평가 기록을 확정한다.
11. 처리한 sequence까지만 큐에서 제거한다. 이후 들어온 요청은 보존한다.
12. Effect cleanup → setup 순서로 실행한다.
13. Effect·native callback에서 새로 들어온 요청은 다음 flush로 처리한다.

commit 결과가 noop이어도 render를 실제로 수행했고 오류 없이 마쳤다면 후보 Hook 값은 확정하고 해당 render의 Effect 규칙을 적용한다. DOM 쓰기 0회와 render 생략을 혼동하지 않는다. 반대로 render 없이 dirty form만 복원한 flush에서는 Effect를 다시 실행하지 않는다.

중단 가능한 렌더를 구현하지 않는다. 후보/확정 상태 분리는 실패 시 상태와 DOM이 어긋나지 않도록 하는 작은 동기 구조다.

### 6.2 useState

- 최초 슬롯 생성 때만 initial 또는 lazy initializer를 평가한다.
- 배열 슬롯은 호출 순서로 연결한다.
- 함수형 action은 이전 후보값을 받아 계산한다.
- 일반 action은 값을 대체한다.
- 함수를 상태 값으로 저장하려면 함수형 updater가 그 함수를 반환하게 한다.
- Object.is를 비교 기준으로 사용한다. NaN·+0/-0도 테스트한다.
- updater는 순수해야 한다. 네트워크·DOM 쓰기·다른 setter 호출을 updater 안에서 수행하지 않는다.
- 상태 객체를 직접 수정한 뒤 같은 참조로 setState하는 방식은 지원하지 않는다.
- setter 호출 즉시 현재 이벤트 핸들러의 지역 변수 값이 바뀌지 않는다.
- render·Memo 계산·순수 자식 평가 도중 setter 호출은 오류다.
- unmount된 루트의 setter는 무시하고 개발 모드에서 진단한다.

예상 결과:

| 초기값·호출 | 최종값 | microtask 모드의 갱신 commit |
|---|---:|---:|
| 0, 함수형 +1 세 번 | 3 | 1 |
| 1, 함수형 +1 뒤 ×2 | 4 | 1 |
| 1, SET 5 뒤 +1 | 6 | 1 |
| 0을 캡처한 count로 SET(count+1) 세 번 | 1 | 1 |
| 현재 3에 SET 3 | 3 | 일반 상태 변경은 0 |
| SET 1 뒤 SET 0, 초기 0 | 0 | 다른 dirty 작업이 없으면 0 |

### 6.3 Batching

- 기본은 queueMicrotask 한 번으로 flush 예약.
- 한 동기 실행 구간의 요청을 모은다.
- 별도 사용자 클릭은 별도 처리한다.
- Promise·await 전후가 항상 같은 batch라는 보장은 하지 않는다.
- 마지막 updater만 남기는 방식은 금지한다.
- 비교 모드 sync는 각 외부 setter 뒤 갱신한다. render/commit/Effect 중에는 중첩 flush하지 않는다.
- Effect가 발생시킨 요청은 sync 모드에서도 현재 commit과 Effect 처리가 끝난 뒤 처리한다.
- flush 도중 들어온 요청을 기존 후보 큐로 덮어쓰지 않는다.
- 같은 연쇄에서 50회를 넘는 연속 flush는 무한 갱신 의심 오류로 중단한다. 이 값은 프로젝트의 진단 정책이며 React와 동일하다는 뜻이 아니다.
- 오류로 중단된 요청을 성공한 것으로 기록하지 않는다. root 초기화·명시적 재시도 전까지 자동 반복을 막는다.
- sync/microtask 비교는 순수 action의 최종 State·DOM을 일치시킨다. 중간 commit과 Effect 횟수는 Batching으로 달라질 수 있으며 비교 결과에 함께 기록한다. Effect가 다시 State를 바꾸는 사례를 단순한 성능 비교 입력에 섞지 않는다.

### 6.4 useEffect

| deps | 실행 규칙 |
|---|---|
| 생략 | 성공한 매 render commit 이후 실행 |
| [] | 최초 mount commit 이후 1회, unmount cleanup |
| [a,b] | 길이·각 항목 Object.is 비교. 변경 시 cleanup 후 setup |

- deps 배열 자체는 복사하여 보관한다. 내부 객체의 불변성은 호출자 계약이다.
- deps 길이 변경은 개발 오류로 처리한다.
- 개발용 Strict Mode 이중 실행은 구현하지 않는다.
- 이번 엔진은 DOM commit 후 같은 flush의 후반 단계에서 Effect를 실행한다. paint 이후를 보장하지 않는다.
- 변경된 Effect의 cleanup을 Hook 순서로 모두 시도한 뒤 새 setup을 Hook 순서로 실행한다.
- cleanup 예외는 기록하되 나머지 cleanup을 중단하지 않는다.
- setup 예외가 이미 완료한 DOM commit을 되돌리지는 않는다.
- setup이 Promise를 반환하면 잘못된 cleanup으로 등록하지 않고 오류를 알린다.
- 비동기 작업의 취소/무시는 앱 Effect의 cleanup에서 명시적으로 처리한다.
- 임의의 외부 요청·타이머를 엔진이 자동 추적·취소하는 API는 만들지 않는다.

### 6.5 useMemo·명시적 재사용

- deps 생략: render마다 계산.
- []: 해당 mount에서 최초 계산 결과 유지.
- deps 유지: 직전 결과 재사용.
- deps 변경: 새로 계산하고 성공한 commit의 후보 값으로 보관.
- 다중 결과 캐시·LRU·자동 deps 추론은 없다.
- factory는 순수해야 하며 Hook이나 setter를 호출하지 않는다.
- 일반 계산 결과와 expression을 모두 저장할 수 있다.
- 같은 expression을 같은 위치에서 다시 사용하면 resolver가 평가를 생략할 수 있다.

```ts
const summary = useMemo(
  () => h(Summary, { items }),
  [items]
);
```

주의:

- items가 바뀌면 Summary도 다시 계산될 수 있다.
- 이는 각 행의 props를 자동 비교하는 memo가 아니다.
- 루트 함수 실행 자체는 남는다.
- hooks를 items.map 안에서 호출해 행별 캐시를 만들지 않는다.
- 이벤트 함수가 mode를 캡처한다면 mode도 deps에 포함해야 한다.
- 함수 props를 임의로 비교에서 제외하는 최적화는 금지한다.

### 6.6 Hook 사용 오류 진단

- 루트 render 밖에서 호출: 오류.
- resolver가 실행하는 자식에서 호출: 오류.
- 이전 render와 개수·종류가 달라짐: commit 전 오류.
- 같은 종류의 Hook을 조건에 따라 바꿔 부르되 개수까지 같은 경우는 런타임 검사로 전부 탐지할 수 없다. 코드 리뷰와 테스트가 필요하다.
- 이 진단을 React의 모든 Rules of Hooks 검증과 동일하다고 설명하지 않는다.

### 6.7 실제 앱: 작은 목록 관리 앱 하나

필수 기능:

- 항목 추가·이름 수정·삭제·완료 토글.
- 검색/필터·정렬·전체 개수와 완료 개수.
- 안정적인 데이터 ID를 key로 사용.
- useMemo로 파생 데이터 또는 고정 Summary expression 재사용.
- useEffect로 document title 또는 window listener 같은 외부 동기화와 cleanup 시연.
- 한 이벤트에서 함수형 업데이트 여러 번을 실행하는 Batching 프리셋.
- 마지막 항목을 맨 앞으로 옮기는 LIS 프리셋.
- root State는 하나 이상의 루트 useState 슬롯에만 존재.
- 자식은 props·콜백만 받는다.
- 렌더러 내부 캐시는 앱의 자식 State로 사용하지 않는다.

앱 기능을 라우터·서버·인증·대규모 도메인 모델로 확대하지 않는다.

---

## 7. 오류·자원·브라우저 상태 처리

### 7.1 이벤트

- React SyntheticEvent를 복제하지 않는다. native Event를 그대로 전달한다.
- input은 input 이벤트, checkbox/select는 change 등 명시한 native 이름을 사용한다.
- 동일 노드·이벤트 이름·capture 조합에는 안정적인 wrapper 하나를 둔다.
- wrapper는 현재 handler를 읽는다. 업데이트 시 과거 closure를 계속 호출하지 않는다.
- handler 제거와 노드 해제 시 wrapper를 제거한다.
- capture 값이 바뀌면 이전 listener를 제거한 후 새 listener를 등록한다.
- once/passive 등 고급 옵션은 초기 API에서 제공하지 않는다.
- 일반 이벤트 위임 시스템은 만들지 않는다.
- native 콜백이 commit 중 상태 변경을 요청하더라도 중첩 commit하지 않는다.

### 7.2 폼의 세 가지 소유 모드

| mode | 의미 | 갱신 규칙 |
|---|---|---|
| snapshot | Phase 1에서 읽은 현재 값 | value/checked/selectedIndices를 목표 snapshot으로 적용 |
| controlled | Phase 2 State가 현재 값을 결정 | 입력 이벤트→setter→Patch로 반영. 거부한 입력도 현재 정책으로 복원 |
| uncontrolled | 브라우저가 현재 값을 소유 | default 값은 mount 때만 적용. 무관한 render·재배치에서 현재 값을 덮어쓰지 않음 |

- 같은 노드에서 controlled/uncontrolled 전환은 이번 계약에서 오류로 처리한다.
- textarea는 value property를 사용한다. 자식 텍스트와 value를 동시에 서로 다른 값으로 제어하지 않는다.
- select는 option children 갱신 이후 selectedIndices를 적용한다.
- selectedIndices는 select.options 순서의 index다. multiple=false이면 최대 하나만 허용한다.
- checked는 boolean으로 처리한다. radio는 브라우저의 같은 name 그룹 동작을 포함해 검사한다.
- Phase 1의 radio는 각 영역 내부의 독립된 form 소유 그룹만 지원한다. 같은 문서의 두 영역에서 form 없는 동명 radio가 서로 해제되는 입력은 거부한다. form 속성으로 영역 밖 소유자를 참조하는 입력도 미지원이다.
- 두 영역을 복제한 데모는 document 전체 ID 참조에 의존하지 않는다. label은 해당 input을 감싸고, 테스트 대상은 영역 root 안에서 조회한다. 임의의 중복 id·외부 label/ARIA ID 참조까지 격리하는 기능은 이번 범위에 없다.
- Phase 2의 value/checked/selected 현재 값은 form 필드 하나로 소유한다. 같은 값을 attrs나 textarea children으로 동시에 제어하는 입력은 거부한다. Phase 1 snapshot은 원래 attribute/default 값과 현재 property를 따로 보존한다.
- programmatic value 변경도 Phase 1 Patch 버튼의 전체 캡처에서는 읽혀야 한다.
- 현재 값과 같은 value는 재대입하지 않는다.
- uncontrolled live 값은 새로 렌더링한 DOM의 초기값과 다를 수 있다. 이를 정확성 실패로 잘못 판정하지 않는다.

**controlled no-op의 예외**

사용자가 input의 live 값을 바꾸었지만 핸들러가 이전 State를 그대로 유지하면, State는 같아도 DOM 복원은 필요하다.

- native input/change 이벤트의 대상 ref를 dirtyFormRefs에 기록한다.
- 이 추적은 사용자 handler의 존재와 무관한 host 내부 listener로 수행한다. handler 처리 후에는 setter가 호출되지 않았어도 복원 flush를 예약한다. radio는 native 동작으로 함께 바뀐 같은 그룹의 관리 노드도 dirty로 표시한다.
- State가 Object.is로 같아 render를 생략하더라도, 현재 VDOM으로 SYNC_FORM 계획을 만들어 공통 patch를 통과시킨다.
- 이벤트 이후 UI 코드가 직접 value를 쓰는 별도 우회 경로를 만들지 않는다.
- 관리 이벤트 없이 외부 스크립트가 Phase 2 DOM을 임의로 바꾸는 것은 지원하지 않는다.

### 7.3 focus·selection·IME

- 같은 key/type의 DOM 객체를 재사용하는 것만으로 focus 보존을 완료 처리하지 않는다.
- commit 전 activeElement와 지원되는 input/textarea selection을 저장한다.
- 해당 노드가 살아남고 다른 명시적 focus 이동이 없을 때만 복원한다.
- 값 변경으로 길이가 달라졌으면 selection을 유효 범위로 제한한다. 임의 문자열 편집에 대한 의미론적 caret 매핑은 보장하지 않는다.
- 삭제한 입력이나 type을 바꿔 교체한 입력에 focus를 강제로 되돌리지 않는다.
- compositionstart/end로 현재 조합 대상을 추적한다.
- 조합 중에는 해당 input의 value를 엔진이 덮어쓰지 않는다. live 값은 일시적으로 브라우저가 소유한다.
- 조합 중인 노드 또는 조상의 이동·제거·교체가 필요한 plan은 쓰기 전에 전체 적용을 보류한다.
- 조합 대상의 type 등 입력 방식을 바꾸는 속성 변경도 충돌로 본다. 단순히 SET_ATTR 명령이라는 이유로 조합 중 안전하다고 간주하지 않는다.
- 보류한 plan을 그대로 나중에 재사용하지 않는다. 큐를 보존하고 compositionend 시 최신 상태에서 다시 계산한다.
- 무관한 영역의 안전한 변경은 진행할 수 있다. 보류한 폼 동기화는 compositionend에 다시 처리한다.
- unmount·명시적 초기화는 조합 추적을 해제한다.
- 실제 한글 IME는 Windows 브라우저에서 수동 확인한다. 합성 이벤트 테스트와 수동 검증 결과를 구분해 기록한다.

### 7.4 오류 정책

| 오류 위치 | 상태·화면 정책 | 필수 동작 |
|---|---|---|
| 입력 검사·중복 key | 기존 실제 영역·History 유지 | 경로와 이유 표시 |
| render·updater·Memo·Diff | 후보 폐기, 마지막 정상 commit 유지 | Effect 금지, 자동 재시도 폭주 금지 |
| stale plan·다른 mount plan | DOM 쓰기 전에 거절 | 오류 기록 |
| commit 도중 예외 | 부분 변경 가능, faulted 전환 | 후속 적용 차단·초기화 제공 |
| Effect cleanup/setup | 완료된 DOM은 유지 | 오류 기록, 가능한 다른 정리 계속 |
| unmount 뒤 setter | 갱신 무시 | 개발 모드 진단 |

root-level 오류 격리만 구현한다. 범용 자식 ErrorBoundary API나 DOM 트랜잭션 rollback은 범위 밖이다.

### 7.5 자원 정리

- 루트 unmount: Effect cleanup, 이벤트 wrapper, 예약 flush, mount registry, 평가 기록 해제.
- 제거 subtree: 해당 노드와 후손의 listener/registry 정리.
- benchmark reset: 이전 root/mount dispose 후 새 실행 준비.
- Inspector: live DOM이나 Event를 로그에 장기 보관하지 않음.
- 대기 작업 무효화에 사용하는 generation은 증가만 시킨다. History cursor와 함께 과거로 돌리지 않는다.

---

## 8. Inspector·계측·벤치마크

### 8.1 Inspector 필수 화면

- 이전·이후 VDOM 트리: 접기/펼치기 수준.
- Patch 목록: 종류·대상 ref/key·부모·anchor.
- 생성·삭제·이동·텍스트·속성·property·listener 변경 수.
- 기존 DOM 객체 재사용 여부.
- 상태 요청 → 루트/자식 실행 → Memo → Diff → Patch → Effect 순서.
- keyed/LIS 경로 사용 여부와 fallback 이유.
- 오류·실패 seed·초기화·재실행 버튼.
- 선택한 Patch 대상 강조. 제거한 노드는 이전 트리 기록에서 표시.

고급 트리 애니메이션·브라우저 확장 프로그램·범용 개발자 도구는 만들지 않는다.

### 8.2 지표 정의

| 지표 | 측정 범위 | 포함하지 않는 것 |
|---|---|---|
| T_capture | 테스트 DOM을 VDOM으로 읽기 | Diff·Patch |
| T_render | 루트 함수와 순수 자식 평가 | DOM commit |
| T_diff | 이미 준비된 VDOM/view에서 plan 계산 | DOM 쓰기 |
| T_commit | plan 적용부터 host 반영·선택 복원까지 | 이후 browser paint |
| T_flush | 큐 처리 시작부터 정의한 commit 완료까지 | 사용자 이벤트 전달 전 대기·실제 표시 지연 |
| Effect 시간 | cleanup/setup | T_commit에 섞지 않음 |
| 계획 이동 수 | planner가 선택한 기존 노드 이동 | 실제 호출 수와 동일하다고 가정하지 않음 |
| 실제 host 호출 수 | executor에서 수행한 insert/remove/move/write | MutationObserver record 수 |
| 브라우저 렌더링 | 별도 trace의 style/layout/paint | performance.now 차이로 추정하지 않음 |

- insertedRoots/movedRoots는 부모 목록에 배치한 root 수다.
- createdNodes/removedNodes는 실제 subtree 내부 노드까지 포함한 수다.
- 큰 li 하나의 이동을 모든 descendant의 이동으로 세지 않는다.
- 이미 정확한 위치에 있는 PLACE_BEFORE를 생략했다면 skippedHostCalls로 구분한다.
- 노드 수·객체 수는 heap byte가 아니다. 메모리 주장은 별도 프로파일 근거가 있어야 한다.

### 8.3 비교 축

| 실험 | 바꾸는 항목 | 고정할 항목 |
|---|---|---|
| Greedy vs LIS | 남겨둘 노드 선택 | VDOM·매칭·executor·폼·이벤트·입력 |
| Batching on/off | flush 예약 | action 순서·초기 State·렌더·Diff·앱 |
| VNode 재사용 on/off | 참조 기반 재사용 | deps·컴포넌트·State·DOM 계약 |

- 한 번에 한 축만 바꾼다.
- 상세 Trace와 Inspector 표시는 timing run에서 끈다.
- 전체 재생성·인덱스 Diff는 교육용 별도 모드다. keyed identity를 지키는 두 전략과 같은 정확성 등급으로 순위를 매기지 않는다.
- 실제 React 앱 비교와 React Fork는 이번 benchmark에 넣지 않는다.
- 새 입력마다 초기 old DOM으로 복구한다. 변경 결과 B에 다시 A→B plan을 적용하지 않는다.
- reset·fixture 생성·정답 검사는 측정 구간 밖에서 수행한다.
- layout 측정 목적이 아닌 실행 중 offsetWidth 등 강제 layout 읽기를 추가하지 않는다.

### 8.4 기본 입력

크기: **10 / 100 / 1,000**, 스트레스 크기 **10,000**.

Payload:

- light: 단순 li + span 텍스트.
- stateful: input·checkbox와 중첩 HTML을 가진 li. 각 keyed 항목의 이동 root는 li 하나.

시나리오:

1. no-op.
2. 한 항목의 텍스트/속성만 변경.
3. 맨 앞 삽입 1개.
4. 중간 삭제 1개.
5. 마지막 1개를 맨 앞으로.
6. 첫 1개를 맨 뒤로.
7. 전체 역순.
8. 인접 교환.
9. 양끝 교환.
10. 고정 seed 무작위 순열.
11. 10% 삽입·삭제와 생존 항목 재배치 혼합.

8개 항목의 알려진 이동 판정:

| 입력: ABCDEFGH → | Greedy | LIS |
|---|---:|---:|
| HABCDEFG | 7 | 1 |
| BCDEFGHA | 1 | 1 |
| HGFEDCBA | 7 | 7 |
| HBCDEFGA | 7 | 2 |
| ACBDEFGH | 1 | 1 |

표는 같은 부모·고유 key·같은 type·항목당 하나의 host root라는 모델의 값이다. 브라우저 속도 배율로 해석하지 않는다.

### 8.5 반복·결과 저장

- 기본 입력은 warm-up 20회 후 측정 100회.
- 최소 3개의 독립 실행 세션에서 반복한다.
- 각 paired run의 Greedy/LIS 순서를 고정 seed로 섞는다.
- 10,000 항목 스트레스는 기본 warm-up 5회·측정 30회로 시작한다. 표본 수가 적은 p95는 참고값으로 표시한다.
- 실행 중 백그라운드 탭·절전 상태가 되면 해당 run을 별도 표기한다.
- median·IQR·p95·샘플 수·세션별 분포를 저장한다.
- 작은 차이는 효과 없음/불확실로 보고할 수 있어야 한다.
- CPU·RAM·OS·브라우저 정확한 버전·전원 모드·빌드 모드·코드 commit·seed·옵션을 기록한다.
- 정답 검증 실패 run은 성능 성과로 집계하지 않고 실패 fixture로 저장한다.
- JSON 또는 CSV raw 결과를 내보낸다. 그래프의 원본 수치를 남긴다.

**성능 완료 기준**

- 특정 재배치에서 이동 수 감소를 실제 executor로 확인.
- no-op·역순·작은 목록처럼 이득이 없거나 손해인 입력도 보고.
- T_diff 증가와 T_commit 감소를 분리.
- “항상 빠르다”, “이동 7→1이므로 7배 빠르다”는 주장 금지.
- 시간상 개선이 없어도 정확한 이동 수 감소·비용 분석은 결과로 남긴다.
- 시간 성능이 나쁘다는 이유로 테스트 입력을 사후 제거하지 않는다.

---

## 9. 테스트 명세와 완료 조건

### 9.1 공통 oracle

기본 관계:

```text
Patch(Render(A), Diff(A, B))
≈
Render(B)
```

동등성의 범위는 구조·텍스트·주석·관리 attribute/style·snapshot/controlled 폼 값이다.

**uncontrolled live 값은 fresh Render(B)의 초기값과 단순 비교하지 않는다.** 유지되는 노드의 사용자 입력값을 별도의 상태 보존 oracle로 검사한다.

별도 불변식:

- 지원 keyed 항목의 기존 DOM 객체 === 갱신 후 해당 항목의 객체.
- 삭제된 노드는 mount에서 제거됨.
- 새 노드는 이전 identity 집합에 없음.
- 이벤트 호출 횟수·실제 호출 함수가 정확함.
- snapshot은 이후 편집으로 변경되지 않음.
- Effect 실행·cleanup 순서가 계약과 일치함.

innerHTML 문자열 하나만 비교해서 완료 처리하지 않는다.

### 9.2 DOM·Diff·Patch 테스트

| ID | 입력·상황 | 기대 결과 |
|---|---|---|
| T-V01 | 요소·텍스트·공백·주석·중첩·빈 root | capture/render 왕복의 관리 데이터 일치 |
| T-V02 | 사용자가 value/checked/select를 바꾼 DOM | attribute와 live property를 구분해 캡처 |
| T-V03 | 0, "", null, false, 중첩 child 배열 | 0/"" 보존, 빈 값 placeholder, 순서 유지 |
| T-V04 | 동일 VDOM을 두 mount에 렌더 | DOM 객체·ref 분리, 한쪽 Patch가 다른 쪽에 영향 없음 |
| T-V05 | 위험 태그·inline event·위험 URL·미지원 namespace | DOM 연결 전 오류, 기존 화면 유지 |
| T-V06 | 외부 편집 캡처→adopt→Diff/Patch, 오래된 capture 채택 | 최신 binding/revision으로 실행, stale capture 거절 |
| T-D01 | 추가·삭제·교체·텍스트·속성 변경 | 정확한 최종 구조와 필요한 명령 |
| T-D02 | 의미상 같은 트리·같은 참조 | 일반 no-op 쓰기 0, 기존 DOM 유지 |
| T-D03 | 삭제+이동+수정 혼합 | index 변화와 무관하게 올바른 대상 수정 |
| T-D04 | 루트 아래 전체 삭제·단일 root 교체·여러 root | container 자체는 유지, children 정확 |
| T-P01 | 속성/style 추가·변경·삭제 | 이전 값이 남지 않음, boolean 처리 정확 |
| T-P02 | handler A→B→없음·capture 변경 | 최신 handler 1회, 중복·제거 누락 없음 |
| T-P03 | 동일 key/type 재정렬 중 입력 | DOM 재사용, 정의한 입력 상태 보존 |
| T-P04 | select option 삽입·삭제 후 선택 복원 | children 변경 후 selectedIndices 적용 |
| T-P05 | 큰 subtree 생성/제거/이동 | root 배치 수와 내부 노드 수를 구분해 집계 |
| T-P06 | 동일 VNode·동일 State이나 controlled input live 값 변경 | render 생략 가능, dirty form Patch는 수행 |

### 9.3 Keyed·LIS 테스트

| ID | 입력·상황 | 기대 결과 |
|---|---|---|
| T-K01 | 같은 key/type 이동 | 기존 객체 유지 |
| T-K02 | 같은 key, li→input 또는 컴포넌트 type 변경 | 해당 경계 교체, 오래된 캐시 폐기 |
| T-K03 | key 변경·삭제·신규 삽입 | 재사용/삭제/생성 구분 정확 |
| T-K04 | old/new 중복 key | commit 전 거절, History 변화 없음 |
| T-K05 | key 누락·공백·텍스트·placeholder 혼재 | 일반 Diff, fallback 이유 표시 |
| T-K06 | 같은 key를 다른 부모·mount에서 사용 | 상호 간 잘못된 재사용 없음 |
| T-K07 | 같은 외부 key·host tag, 내부 컴포넌트/반환 root key 변경 | 내부 경계 변경을 감지하고 해당 root 교체 |
| T-L01 | n=1~8 모든 순열 | 실제 planner+모델 executor에서 순서·identity 정확 |
| T-L02 | n≤7 BFS 최단 이동 oracle | 실제 LIS 계획이 최소 이동 수 달성 |
| T-L03 | key 4개 부분 순열 4,225쌍 | 삽입·삭제·이동 혼합, sentinel 처리 정확 |
| T-L04 | type 변경 포함 seed 입력 10,000쌍 | 결과·identity 정확, 실패 seed 보존 |

- 실제 프로젝트의 planner를 호출한다. 테스트 안에서 만든 별도 LIS만 검증하지 않는다.
- 모델 executor는 production DOM executor와 독립적인 단순 배열 연산으로 구현한다.
- BFS oracle는 LIS 공식을 이용해 정답을 만들어서는 안 된다.
- n≤8 전수 검사를 모두 실제 브라우저 DOM에서 반복할 필요는 없다.
- 브라우저에서는 대표 사례와 고정 seed의 작은 트리/목록을 별도로 적용해 모델과 host 구현 사이를 검증한다.
- 권장 브라우저 seed smoke 범위: 200개, 노드 수 0~30. 실패 시 해당 입력을 regressions에 고정한다.

### 9.4 History 테스트

| ID | 입력·상황 | 기대 결과 |
|---|---|---|
| T-H01 | 초기 로드→편집→Patch | V0→V1, 실제 영역만 부분 갱신, 두 내용 일치 |
| T-H02 | 3회 Patch 후 Undo/Redo | 두 영역이 선택 snapshot으로 복원 |
| T-H03 | Undo 후 새 Patch | 기존 미래 이력 폐기 |
| T-H04 | 테스트 영역에 X를 추가하고 Patch 없이 Undo | X가 남지 않음 |
| T-H05 | 저장 후 원래 입력 객체·DOM을 변경 | 과거 snapshot 불변 |
| T-H06 | no-op Patch·끝 경계 Undo/Redo·검증 실패 | 불필요한 버전 없음, cursor 손상 없음 |

### 9.5 Component·State·Hook 테스트

| ID | 입력·상황 | 기대 결과 |
|---|---|---|
| T-C01 | FunctionComponent mount/update | 같은 공통 diff/commit 호출 경로 사용 |
| T-C02 | 자식 props 변경·같은 함수 여러 위치 | 독립 평가 기록, child 앱 State 없음 |
| T-C03 | 루트 밖/자식 Hook·Hook 개수/종류 변경 | commit 전 오류 |
| T-C04 | 같은 expression을 여러 위치 사용 | 결과 재사용과 DOM binding을 혼동하지 않음 |
| T-S01 | 여러 state 슬롯·재렌더 | 값과 setter가 올바른 슬롯에 연결 |
| T-S02 | lazy initializer·함수 값 저장 | 초기화 횟수·action 해석 정확 |
| T-S03 | 함수형 +1×3 | 최종 +3, batching commit 1회 |
| T-S04 | +1→×2, SET→함수, 같은 값 대체 | FIFO 결과 정확 |
| T-S05 | 두 의도적 클릭·await 전후 | 문서화한 경계 유지, 무조건 전체 합치지 않음 |
| T-S06 | flush/Effect 중 새 요청 | 처리한 prefix만 제거, 새 요청 보존 |
| T-S07 | Object.is, 직접 mutation 오용, unmount 뒤 setter | 동일값·진단·해제 처리 정확 |
| T-F01 | deps 생략·[]·같음·변경 | 정확한 setup 횟수 |
| T-F02 | deps 변경·unmount | 이전 cleanup 후 setup, 마지막 cleanup |
| T-F03 | render/diff 실패·IME 보류 | 후보 Effect 실행 없음 |
| T-F04 | Effect 안 setter | 중첩 commit 없이 다음 flush |
| T-F05 | cleanup/setup 예외·Promise 반환 | 정의한 오류 정책, 다른 정리 계속 |
| T-F06 | 반복 mount/unmount·취소 가능한 비동기 예제 | 타이머·리스너 중복과 오래된 응답 덮어쓰기 없음 |
| T-F07 | explicit render의 DOM no-op, render 없는 dirty form flush | 앞 경우만 render 기준 Effect 규칙 적용 |
| T-M01 | deps 같음/변경/생략 | 값·계산 횟수 정확 |
| T-M02 | 같은 expression 유지 | resolver·하위 Diff 생략, 결과 동일 |
| T-M03 | mode를 캡처한 이벤트 함수 | 올바른 deps에서 최신 mode 사용 |
| T-M04 | reuseVNode on/off | 상태·DOM·Effect 의미론 동일 |

### 9.6 브라우저·오류·관찰·앱 테스트

| ID | 입력·상황 | 기대 결과 |
|---|---|---|
| T-B01 | 실제 키보드 입력·checkbox·radio·select | native 상태와 VDOM 계약 일치 |
| T-B02 | focus·selection 상태에서 무관한 갱신 | 입력 노드와 지원 selection 유지 |
| T-B03 | 포커스된 행 재정렬·삭제·type 교체 | 재사용 시 보정, 삭제한 입력에 강제 focus 없음 |
| T-B04 | composition 합성 이벤트·충돌 plan | 보호 규칙·보류·최신 재계산 동작 |
| T-B05 | 실제 Windows 한글 IME로 입력 중 다른 UI 갱신 | 조합 중복·누락·불필요한 중단 없음; 수동 기록 |
| T-E01 | stale revision·다른 mount의 plan | host 쓰기 0, 명확한 오류 |
| T-E02 | render/updater 예외 | 마지막 정상 commit 유지, Effect 없음 |
| T-E03 | commit 예외 강제 주입·초기화 | faulted 이후 쓰기 차단, 초기화 가능 |
| T-Q01 | Patch 계획·실제 호출·Inspector 비교 | 항목·횟수·대상 일치 |
| T-Q02 | trace off/on·ring buffer·실패 재실행 | 결과 동일, 무제한 로그 보관 없음 |
| T-Q03 | 계측 모드·benchmark reset | 관측 부하 분리, 매번 동일 old 상태 |
| T-A01 | 추가·수정·삭제·완료·검색·정렬 | 입력/클릭→루트 State→공통 엔진 |
| T-A02 | 빈 상태·키보드·라벨·오류·초기화 | 사용자 흐름 완결 |
| T-A03 | 앱 mount/unmount·프리셋 연속 실행 | 누수·이벤트 중복·이전 데이터 잔류 없음 |

브라우저 기준:

- 주 검증: 구현 당시의 Chrome 또는 Chromium, 정확한 버전 기록.
- 보조 검증: Firefox 또는 WebKit 중 하나의 기본 기능 smoke.
- OS IME는 주 사용 환경에서 수동 검증.
- 모든 브라우저·입력기 호환성을 주장하지 않는다.
- MutationObserver 기록 수를 DOM API 호출 수로 사용하지 않는다.

### 9.7 실패 fixture 최소 형식

```json
{
  "schemaVersion": 1,
  "caseId": "mixed-reorder-001",
  "seed": 539365639,
  "strategy": "lis",
  "oldTree": {},
  "newTree": {},
  "actions": [],
  "expected": {},
  "observed": {},
  "planSummary": [],
  "environment": {
    "engineCommit": "",
    "browser": "",
    "os": ""
  }
}
```

위 숫자는 형식 예시이며 실행 결과가 아니다. 실제 실패에서는 generator의 정확한 seed·버전·입력을 저장한다. 환경 변수·개인 입력·인증 정보는 fixture에 포함하지 않는다.

---

## 10. 단계별 개발 체크리스트

완료 근거 형식:

```text
기능 ID:
담당:
검증한 commit:
실행 명령:
통과한 테스트:
남은 실패/미지원:
시연 또는 결과 파일:
설명할 핵심 원리:
```

### M0 — 범위·계약 고정

선행: 없음. 우선순위 P0.

- [ ] 공식 요구사항을 팀원 전원이 확인한다. — 이번 구현에서는 원문을 확인했다. 팀원 전원의 확인은 미확인.
- [ ] State/Hook 루트 제한과 공통 엔진 재사용을 합의한다. — 코드·테스트에 반영 완료. 팀 합의 여부는 미확인.
- [x] 지원 태그·폼·빈 자식·key·컴포넌트 반환 범위를 확정한다. — 최종 지원표와 M1 지원 부분집합을 구현 기록에 구분했다.
- [x] VDOM, MountView, PatchPlan, HookSlot, TraceEvent 계약을 공유한다. — src/core/types.ts와 docs/m0-m1.md로 제공. 팀원별 확인을 의미하지 않는다.
- [x] 과제 필수와 B안 차별화·후속 연구를 구분한다. — M1 구현과 M4/M5/M6/M7 후속 범위를 기록했다.
- [x] 공통 fixture와 실행/검증 명령 이름을 정한다. — tests/fixtures/helpers.ts; dev/typecheck/test/test:browser/build/preview.
- [x] 기본 계측 진입점은 정의하되 Inspector UI를 먼저 만들지 않는다. — TraceSink와 emitTrace, diff/patch/render/Hook 실행 진입점.
- [ ] 남은 기간과 독립 구현 종료 시점을 팀에서 정한다. — 팀 일정 정보가 없어 미완료로 유지.

Gate M0:
- 입력과 출력의 의미를 보고 서로 다른 구현을 테스트할 수 있다.
- 아직 결정하지 않은 필수 의미론을 “나중에 통합하면서”로 남기지 않는다.

2026-11-07 판정: 기술 계약·fixture·명령은 준비했다. 팀 확인 3항목은 증거가 없어 남겼으며, **M0 전체 Gate 완료로 표시하지 않는다.**

### M1 — 각자 최소 동작 엔진 독립 구현

선행: M0. 우선순위 P0. 전체 남은 시간의 약 20~25% 이내에서 시간 제한을 둔다.

- [x] P1-01: DOM 캡처와 기본 렌더를 만든다. — capture/mount/patch 및 T-V01 통과.
- [x] P1-02: 위치 기반 기본 Diff와 Patch를 연결한다. — DOM 없는 planner와 DOM 통합 T-D01 통과.
- [x] P1-05: 두 영역·Patch·기본 History를 연결한다. — T-H01~T-H06 및 Chromium 기본 흐름 통과.
- [x] P2-01: FunctionComponent·hooks·mount/update를 만든다. — T-C01 통과. 루트 Hook 제한 검사 포함.
- [x] useState/useEffect/useMemo의 최소 계약을 연결한다. — T-S01/T-F01/T-M01 통과. M1 State는 동기 갱신.
- [x] 카운터 또는 작은 목록으로 Phase 2→공통 Diff/Patch를 확인한다. — 두 State·순수 Summary·Memo·문서 제목 Effect 카운터.
- [x] T-V01, T-D01, T-H01, T-C01, T-S01, T-F01, T-M01을 실행한다. — 지정 7개 ID 통과; 전체 단위·통합 52/52, 브라우저 4/4.
- [x] 미완료·실패를 숨기지 않고 비교표에 기록한다. — docs/m0-m1.md의 현재 후보 비교·실패 기록.
- [x] 이 단계에서는 LIS·자동 memo·스케줄러·화려한 Inspector를 추가하지 않는다. — positional/sync 기준 구현만 제공.

Gate M1:
- 각자가 같은 fixture에 대한 결과·실패·설계 설명을 제출한다.
- 모든 구현이 완성될 때까지 선택을 무기한 늦추지 않는다. 시간 제한 도달 시 실제 증거를 기준으로 M2를 진행한다.

2026-11-07 판정: **현재 저장소의 M1 후보 구현·검증·설명 자료 완료.** 다른 팀원의 제출·시간 제한 합의는 미확인이며, 팀 비교/M2 선정은 진행하지 않았다.

검증 기록: [M0~M1 구현·검증·핵심 원리](<C:/Github/mini-react/docs/m0-m1.md>) · [실행 요약 JSON](<C:/Github/mini-react/docs/validation/m0-m1.json>) · [설치·재현 명령](<C:/Github/mini-react/README.md>)

미완료 경계: Keyed Greedy/LIS, microtask Batching(+1×3을 commit 1회로 처리), expression 평가 재사용, controlled no-op 복원·radio·focus/selection·IME 전체 계약, Inspector/benchmark, 목록 앱, CI/보조 브라우저/공개 배포. 일부 M3 대상의 기본 회귀가 통과했어도 M3~M8 단계 전체는 완료 처리하지 않는다.

### M2 — 기준 구현 선택·부분 이식

선행: M1. 우선순위 P0.

- [ ] 동일 fixture로 후보를 비교한다. — 다른 후보 미제공. 비교했다고 기록하지 않는다.
- [x] 필수 충족·정확성·공통 엔진·설명 가능성을 먼저 평가한다. — docs/m2-selection.md, 기준 재검증 52+4/typecheck/build 통과.
- [x] 메인 구현 하나를 선택하고 이유를 기록한다. — 사용자 허용에 따른 현재 phase1/705fde0의 잠정 선정. 팀 최종 선정과 구분.
- [ ] 병합할 장점은 작은 기능 단위로 목록화한다. — 외부 후보가 없어 이식 대상 없음.
- [ ] 다른 구현의 장점을 증명하는 테스트를 먼저 옮긴다. — 외부 후보가 없어 해당 작업 없음.
- [ ] 타입·Patch·Hook·History 계약에 맞게 이식한다. — 외부 후보가 없어 해당 작업 없음.
- [x] 메인 구현의 설치·테스트·빌드 명령을 고정한다. — package.json/pnpm-lock.yaml 및 Windows 보조 실행기.
- [x] 필수 실패를 우선순위 작업으로 전환한다. — 계획 사전 검증, 폼 소유/dirty 복원, 오류·자원 회귀를 M3에 배치.

Gate M2:
- 하나의 통합 엔진과 하나의 기본 테스트 경로가 있다.
- 두 개의 호환되지 않는 renderer/hooks 시스템이 동시에 남지 않는다.

2026-11-07: 다른 후보 없는 경우의 잠정 선정을 사용자가 허용했다. 현재 후보를 기술 검토·재검증하여 M3의 기준으로 사용한다. 후보 비교·팀 합의는 미수행. [M2 선정 기록](<C:/Github/mini-react/docs/m2-selection.md>) · [이후 단계 진행 기록](<C:/Github/mini-react/docs/progress.md>).

### M3 — 과제 필수 정확성 완성

선행: M2. 우선순위 P0.

- [x] T-V01~T-V06, T-D01~T-D04를 통과한다. — vdom/diff/patch/plan-validation/forms 테스트. D03의 이동은 executor 계획을 직접 검증하며, keyed planner 결합은 M4.
- [x] 속성·style 삭제·boolean·텍스트·주석을 처리한다. — patch.test.ts 및 왕복 검사.
- [x] native 이벤트 교체·제거·capture 변경을 처리한다. — wrapper 최신 handler/제거/재등록 및 입력 observer 해제 검증.
- [x] snapshot/controlled/uncontrolled 폼 계약을 구현한다. — forms.test.ts 25개와 Chromium native 폼/그룹/파일 경계. focus/selection/IME 종합 검증은 M7.
- [x] 미확정 편집 후 Undo를 포함해 T-H01~T-H06을 통과한다. — history.test.ts 및 Chromium 편집/폼 History.
- [x] 두 mount의 binding과 History 데이터를 분리한다. — T-V04/T-H01/T-H05, radio form 격리 검증.
- [x] Hook 슬롯·deps·cleanup·기본 오류를 검증한다. — hooks.test.ts 24개, 오류·반복 mount/unmount 회귀.
- [x] render 실패 시 마지막 정상 화면을 유지한다. — 후보 State/Memo/Effect 폐기와 explicit 재시도 검증.
- [x] 초기화·오류 안내·Undo/Redo 버튼 상태를 만든다. — fault 후 마지막 정상 History로 두 영역 복구, 브라우저 UI 확인.

Gate M3:
- B안 최적화 없이도 과제 전체 흐름이 동작한다.
- 알려진 필수 정확성 실패가 남아 있으면 다음 최적화를 기본 경로에 넣지 않는다.

2026-11-07: M3 기본 정확성 Gate 통과. 단위·통합 95/95, Chromium 9/9, typecheck/build PASS. native listener 사이의 microtask로 정상 입력이 되돌아가던 실제 브라우저 실패를 수정하고 부모 bubble handler 회귀로 고정했다. [M3 구현·증거](<C:/Github/mini-react/docs/m3-correctness.md>) · [실행 요약](<C:/Github/mini-react/docs/validation/m3.json>). M4/M5 최적화와 M7 실제 IME·보조 브라우저는 별도 단계다.

### M4 — Keyed Greedy 후 LIS

선행: M3. 우선순위 P1.

- [x] key·type·부모 scope의 매칭 함수를 하나로 만든다. — core/keyed.ts + 공통 compatible().
- [x] Greedy 이동 판정을 먼저 구현한다. — running maximum 비교 경로 유지.
- [x] T-K01~T-K07으로 identity와 fallback을 검증한다. — keyed 통합/전수/기존 mount·boundary 테스트.
- [x] stable ref·anchor 기반 PLACE_BEFORE를 검증한다. — 양 전략 동일 planner 출력/공통 executor, 실제 DOM 400회 seed smoke.
- [x] 재사용 oldIndex 수열과 LIS 복원을 구현한다. — predecessor/tails 복원, 신규 null 및 기존 index 0 구분.
- [x] monotonic/no-reorder에서는 LIS 계산을 생략한다. — usedLIS=false, 기본 경로 no-op 테스트.
- [x] Greedy/LIS가 같은 executor를 쓰게 한다. — commit/insertBefore 공통 경로.
- [x] T-L01~T-L04를 실제 프로젝트 planner로 실행한다. — 순열 46,233 / BFS 5,913 / 부분 순열 4,225쌍 / seed 10,000쌍 통과.
- [x] 대표 입력을 실제 DOM에 적용하고 identity를 확인한다. — HABCDEFG + seed 200쌍×2전략; live uncontrolled 입력도 보존.
- [x] planner 이동 수와 실제 host 호출 수를 분리한다. — reconciliations.moves와 counters.movedRoots/skippedHostCalls.

Gate M4:
- 순서·identity 실패 0.
- 제한 모델에서 LIS 이동 수가 독립 oracle와 일치한다.
- 실패한 최적화가 있으면 기본 Greedy를 유지하고 LIS를 비활성화한다.

2026-11-07: M4 Gate 통과 후 LIS를 기본값으로 전환했다. 단위·통합 113/113, Chromium 10/10, typecheck/build PASS. 위 전수 수치는 과거 독립 모델을 재사용한 결과가 아니라 이번 production planner를 호출한 새 실행이다. [M4 증거·설명](<C:/Github/mini-react/docs/m4-keyed.md>) · [실행 요약](<C:/Github/mini-react/docs/validation/m4.json>). 시간 성능과 focus/IME 완료를 주장하지 않는다.

### M5 — FIFO Batching·명시적 Memo 재사용

선행: M3; M4와 독립 부분 병행 가능. 우선순위 P1.

- [x] 루트 StateUpdate에 sequence·slot·cause ID를 부여한다.
- [x] 후보값 계산과 확정값 변경을 분리한다.
- [x] microtask 예약을 중복하지 않는다.
- [x] T-S02~T-S07의 FIFO·no-op·재진입을 검증한다.
- [x] 처리한 sequence 뒤의 요청을 보존한다.
- [x] Effect 업데이트를 다음 flush로 보낸다.
- [x] controlled no-op에서도 dirty form을 복원한다.
- [x] 동일 expression 재사용과 위치별 캐시를 구현한다.
- [x] T-M01~T-M04를 통과한다.
- [x] batching/reuse on/off가 결과를 바꾸지 않는지 확인한다.

Gate M5:
- +1×3은 +3/commit 1회.
- 중첩 commit·요청 유실·오래된 handler 사용이 없다.
- 자동 shallow memo나 새 Hook API를 추가하지 않는다.

2026-11-07: M5 Gate 통과. 단위·통합 138/138, Chromium 12/12, typecheck/build PASS. FIFO·후속 요청·실패 후보 폐기·위치별 캐시·최신 handler·dirty form을 검증했다. 기본 microtask와 sync 비교 모드를 유지한다. [M5 증거·설명](<C:/Github/mini-react/docs/m5-batching-reuse.md>) · [실행 요약](<C:/Github/mini-react/docs/validation/m5.json>). 시간 성능과 실제 IME는 후속 단계다.

### M6 — Inspector·재현·벤치마크

선행: M4·M5. 우선순위 P1.

- [x] Q-01: 실제 Trace를 표시하는 Inspector를 만든다.
- [x] 계획·실제 작업·DOM identity를 함께 보여준다.
- [x] key 경로 fallback 이유와 Effect 실행 순서를 표시한다.
- [x] 예제 초기화·전환·실패 seed 재실행을 만든다.
- [x] 동일 초기 상태를 보장하는 benchmark harness를 만든다.
- [x] counts run과 timing run을 분리한다.
- [x] 기본 크기·입력·payload·세션 조건을 기록한다.
- [x] no-op·역순·작은 목록의 불리한 결과도 저장한다. — 전체 행렬 보존. 1,000개 stateful mixed의 불리한 시간 결과도 보고서에 포함.
- [x] T-Q01~T-Q03을 통과한다.
- [x] raw 결과 내보내기와 결과 읽는 법을 문서화한다. — 세션별 gzip JSONL·CSV·감사 JSON·4개 PNG/SVG와 지표/해석/재현 문서.

Gate M6:
- Inspector 값이 실제 실행과 일치한다.
- 다른 사람이 seed·옵션·환경 정보를 보고 재현할 수 있다.
- 브라우저 측정 전에는 속도 향상 수치를 문서에 쓰지 않는다.

2026-11-07: M6 전체 Gate 통과. 최초 harness 검증(145 unit/integration + Chromium 13, smoke)은 당시 기록으로 보존한다. 최종 기능 소스 3190268과 같은 build를 실행 commit ebc8f46에서 전체 3세션 측정했고, 624 counts / 10,140 warm-up / 51,480 timing 행과 4,368개 구간 통계가 원본 감사에서 일치했다. 결과 commit은 0d1cfea다. [전체 결과·raw·그래프·해석](<C:/Github/mini-react/docs/benchmark-results.md>) · [감사 JSON](<C:/Github/mini-react/docs/bench/m8-full/analysis.json>). 최초 중단 원본과 실행기 보완은 [복구 기록](<C:/Github/mini-react/docs/benchmark-runner-recovery.md>)에 별도로 보존했으며 부분 표본을 최종 통계에 합산하지 않았다.

### M7 — 실제 앱·브라우저·IME·자원 검증

선행: M3~M6. 우선순위 P0/P1.

- [x] APP-01 목록 앱의 입력·검색·정렬·수정·삭제를 완성한다.
- [x] useMemo와 Effect cleanup의 실제 사용 예를 넣는다.
- [x] T-A01~T-A03을 통과한다.
- [x] T-B01~T-B04 자동 브라우저 테스트를 통과한다.
- [x] T-B05 실제 한글 IME를 수동 검증하고 환경·절차·결과를 남긴다. — 사용자 Windows 한글 IME 직접 확인, 문제 없음. 브라우저명·버전은 미제공으로 기록.
- [x] 반복 mount/unmount·프리셋 실행에서 중복 이벤트를 검사한다.
- [x] 보조 브라우저 smoke를 실행한다.
- [x] 키보드·라벨·focus·오류·빈 상태를 확인한다.
- [x] 실제 사용자 작업의 별도 Performance trace를 수집한다.

Gate M7:
- 순서·폼·이벤트·History·Hook 필수 실패 0.
- IME 미검증을 자동 테스트 통과로 대체하지 않는다.
- 구현하지 않은 브라우저/태그/동작은 지원표에 남긴다.

2026-11-07: M7 앱·자동 브라우저 검증 완료. 단위·통합 157/157, Chromium 19/19 + Firefox 10/10, typecheck/build PASS. 실제 Performance trace를 따로 수집했다. T-B05는 도구의 URL 확인 제한 후 사용자 직접 검증으로 확인했다. 2026-11-07 응답은 “직접 확인 완료 — 문제 없음”이며 조합 중 이동 보류·종료 후 이동·문자/focus 보존 요청 절차를 기준으로 한다. 브라우저명·버전은 미제공이다. M7 필수 검증을 충족했다. [M7 증거·수동 절차](<C:/Github/mini-react/docs/m7-app-browser.md>) · [실행 요약](<C:/Github/mini-react/docs/validation/m7.json>).

### M8 — 기능 동결·인수·포트폴리오

선행: M7. 우선순위 P0. 마지막 일정의 약 20%를 확보한다.

- [x] 필수·B안 기능 ID별 완료 근거를 연결한다.
- [x] test/typecheck/build/브라우저 검증을 정리한다.
- [ ] CI에서 같은 명령을 실행한다. — workflow 구성·YAML/명령 검사 완료, 같은 명령의 로컬 검증 PASS. 원격 push/실행은 범위 밖이므로 미실행.
- [x] 실패 seed를 회귀 테스트로 고정한다. — 정답 무작위 실패 seed는 미발견. 실제 native input·plan·cleanup 회귀를 고정했고, 대용량 browser 할당 실패의 seed 539365639·10,000/stateful/mixed와 raw를 보존해 집중 재현·20회 자원 진단·timeout 검증을 추가했다. 메모리 압력의 세부 원인은 미확정이다.
- [x] 실행 가능한 데모와 로컬 재현 절차를 확인한다.
- [x] 요구사항 대응표·구조·알고리즘·지원 범위·한계를 작성한다.
- [x] benchmark raw 데이터와 그래프·해석을 연결한다. — 전체 3세션 원본·통계 대조 및 네 그림 PNG/SVG 검토 완료.
- [ ] 각 팀원이 핵심 실행 경로를 직접 추적·설명한다.
- [ ] 작은 동작 변경 후 해당 테스트로 검증하는 연습을 한다.
- [x] 구현하지 않은 연구 성과를 이력서 문구에서 제거한다.

2026-11-07: M8 기술 인수를 충족했다. [기능·69개 테스트 ID 대응표](<C:/Github/mini-react/docs/requirements-tests.md>), [구조·알고리즘·지원 한계](<C:/Github/mini-react/docs/architecture.md>), [데모·핵심 원리·연습·성과 문구](<C:/Github/mini-react/docs/demo-and-explanation.md>), [전체 benchmark 보고서](<C:/Github/mini-react/docs/benchmark-results.md>), [최종 인수](<C:/Github/mini-react/docs/m8-acceptance.md>)를 연결했다. 소스·테스트 59개 hash가 보관한 최종 검증 상태와 일치하고 로컬 데모는 HTTP 200이다. 팀원 설명·변경 연습·실제 발표와 원격 CI 실행은 미확인으로 남겼다.

Gate M8:
- 기능 존재 + 검증 통과 + 사용 가능한 데모 + 원리 설명을 모두 충족한다.

---

## 11. 팀 독립 구현·선정·병합 계약

### 11.1 메인 선택 기준

| 기준 | 비중 | 확인 방법 |
|---|---:|---|
| 필수 정확성과 안정성 | 40 | 공통 테스트·실제 DOM 결과 |
| 두 Phase 통합과 모듈 계약 | 20 | 동일 Diff/Patch 사용, 책임 분리 |
| 설명·수정 가능성 | 15 | 작은 입력 추적·변경 실습 |
| 테스트·관찰 확장성 | 15 | fixture·Trace·실패 재현 |
| 동일 조건의 성능 | 10 | 정확성 조건을 통과한 비교만 |

점수보다 먼저 필수 제약 위반 여부를 확인한다. 자식 Hook이나 별도 DOM 직접 갱신으로 빠른 구현은 메인 채택 대상이 아니다.

### 11.2 병합 전에 확인할 항목

- [ ] key 정규화·중복·누락·type 변경 규칙이 같은가?
- [ ] 빈 자식·공백·주석의 위치 의미가 같은가?
- [ ] attribute/property/style/event 표현이 같은가?
- [ ] Patch의 node/parent/anchor와 실행 순서가 같은가?
- [ ] Hook 슬롯·setter·deps·cleanup 시점이 같은가?
- [ ] queue flush·no-op·Effect 재진입 규칙이 같은가?
- [ ] History snapshot과 mount binding을 분리했는가?
- [ ] 해당 장점의 테스트를 메인 엔진에서 재현했는가?

내부 표현이 다르면 adapter로 작은 부분을 이식한다. 기존 전체 renderer를 함께 유지해 복잡성을 늘리지 않는다.

### 11.3 통합 후 분담 단위

| 작업 단위 | 책임 | 공동 검토가 필요한 변경 |
|---|---|---|
| VDOM·Diff·keyed | 정규화·매칭·계획 | VNode·identity·PatchOp |
| DOM·폼·이벤트 | host adapter·executor·IME | FormPolicy·commit 순서 |
| Root·Hooks·큐 | 후보/확정 상태·Effect·Memo | HookSlot·flush 계약 |
| 편집기·History | 두 영역·Undo/Redo | capture view·History 계약 |
| 검증·benchmark | oracle·seed·환경·결과 | 계측 지표 정의 |
| Inspector·앱·문서 | 시연·Trace 표시·설명 | TraceEvent |

팀원 수가 적으면 여러 단위를 묶는다. 서로 같은 핵심 파일을 동시에 수정하기보다 계약을 먼저 고정하고 책임자를 정한다.

### 11.4 일정 시나리오

팀원 수·현재 잔여 기간은 확정 정보가 아니다. 자료4의 전체 5일 조건을 현재 남은 5일로 해석하지 않는다.

| 가정 | 진행 |
|---|---|
| 1명·3일 이하·기본 엔진 미완료 | 필수 정확성 중심 A안으로 축소. B안 미완료를 분명히 표시 |
| 2~3명·5일·기본 구현 일부 존재 | B안 목표, 초반 기준 구현 선정, 마지막 하루 안정화 |
| 3명 이상·7~10일·기본 기능 안정 | B안 완성 후에도 C 후보 자동 추가 금지 |
| 별도 연구 기간 확보 | React anchor 탐색 연구를 과제와 별도 진행 |

B안 통합 작업량은 약 9~14인일의 설계 추정이다. 각자의 독립 구현 중복·학습·환경 문제는 추가될 수 있다. AI 코드 생성 속도를 검증·이해 시간의 대체값으로 사용하지 않는다.

---

## 12. 최종 인수·축소 기준

### 12.1 최종 인수 체크리스트

2026-11-07 최종 기술 대조: 아래 완료 표시는 실제 구현·검증과 설명 자료를 기준으로 한다. [기능/테스트 대응표](<C:/Github/mini-react/docs/requirements-tests.md>) · [최종 인수](<C:/Github/mini-react/docs/m8-acceptance.md>) · [전체 실험 보고서](<C:/Github/mini-react/docs/benchmark-results.md>). M6 전체 실험과 M8 기술 인수를 충족했다. 팀원 설명/연습/실제 발표와 원격 CI 실행 완료를 뜻하지 않는다.

**과제 충족**

- [x] 실제 DOM에서 출발해 VDOM을 만든다.
- [x] 테스트 영역을 직접 편집하고 Patch로 실제 영역의 변경분만 적용한다.
- [x] VDOM History와 Undo/Redo가 두 영역을 동기화한다.
- [x] FunctionComponent·hooks 배열·mount/update가 존재한다.
- [x] useState/useEffect/useMemo가 실제 앱에서 사용된다.
- [x] State·Hooks는 루트 전용이다.
- [x] 자식은 props 순수 함수다.
- [x] 두 Phase가 같은 VDOM·Diff·Patch를 사용한다.
- [x] Vanilla 런타임이며 외부 UI 프레임워크를 쓰지 않는다.
- [x] 단위·통합·브라우저 테스트를 통과한다.

**B안 차별화**

- [x] Greedy와 LIS가 같은 매칭·executor에서 비교된다.
- [x] 노드 identity와 최소 이동의 지원 조건을 설명할 수 있다.
- [x] Batching이 상태 요청을 버리지 않는다.
- [x] useMemo·동일 expression 재사용이 결과를 바꾸지 않는다.
- [x] Inspector가 실제 실행 기록을 보여준다.
- [x] 실패 입력·seed를 재현할 수 있다.
- [x] 이동 수·계산 시간·DOM 시간·브라우저 trace를 구분한다.

**품질·설명**

- [x] 폼·이벤트·focus·selection·IME 지원 경계를 검증했다.
- [x] 미확정 편집 후 Undo를 시연할 수 있다.
- [x] mount/unmount·초기화 후 자원이 정리된다.
- [x] 오류·빈 상태·키보드·라벨·focus 표시가 있다.
- [x] 재현 명령·CI·데모·지원표·한계 문서가 있다.
- [x] 최소 하나의 실패 사례와 수정 근거를 설명한다.
- [ ] 유리한 입력과 불리한 입력을 함께 발표한다. — 양쪽 결과·그래프·시연 자료 작성 완료. 실제 팀 발표 수행 여부는 미확인.
- [x] 아직 하지 않은 React 원본 개선·성능 성과를 주장하지 않는다.

### 12.2 중단·축소 기준

| 문제 | 즉시 조치 | 유지할 범위 |
|---|---|---|
| LIS 순서·identity 실패 | LIS 비활성화, Greedy로 재현·수정 | 필수 엔진·브라우저 테스트 |
| 입력·IME 손상 | 속도 최적화 중단, 보호 규칙 수정 | 부분 업데이트·입력 정확성 |
| Hook 요청 유실·Effect 중복 | queue/commit 계약 복구 | FIFO·cleanup·필수 Hooks |
| History 두 영역 불일치 | 현재 테스트 DOM 재캡처 경로 수정 | VDOM History 필수 |
| 일정 후반 필수 실패 잔존 | Inspector 꾸밈·추가 benchmark·B안 선택 기능 순으로 축소 | 필수 전체·핵심 검증 |
| LIS 시간상 이득 불확실 | 이동 수 성과와 시간 결과를 분리해서 보고 | 정확한 비교 실험 |
| C안 후보로 범위 확대 | 해당 작업을 backlog로 이동 | 본 명세의 B안 |

B안에서 일부 차별화를 완료하지 못했다면 “B안 완료”로 표시하지 않는다. 실제 완료 범위를 A안 또는 부분 B안으로 기록한다.

### 12.3 설명해야 할 핵심 질문

1. 실제 DOM과 불변 VDOM·mount binding을 왜 분리했는가?
2. 동일 key라도 type이나 부모가 달라지면 왜 재사용하지 않는가?
3. Greedy가 HABCDEFG에서 7개를 옮기는 이유는 무엇인가?
4. 역순에서는 LIS도 왜 n-1개를 옮기는가?
5. anchor를 숫자 index로만 표현하면 어떤 오류가 나는가?
6. 화면 구조가 같아도 input·이벤트·identity가 잘못될 수 있는 이유는 무엇인가?
7. Hook 슬롯과 클로저는 어떻게 다른가?
8. +1을 세 번 요청하면서 commit은 한 번만 가능한 이유는 무엇인가?
9. VDOM History로 Phase 2 앱 상태까지 복원할 수 없는 이유는 무엇인가?
10. DOM 이동 수 감소가 전체 브라우저 시간 감소를 보장하지 않는 이유는 무엇인가?

### 12.4 완료 후 사용할 수 있는 성과 표현

측정과 구현을 실제로 완료한 경우에만 사용한다.

- “두 Phase가 공유하는 VDOM·Diff·Patch와 루트 Hooks를 구현했다.”
- “같은 identity 계약 아래 Greedy·LIS를 비교하고 특정 입력의 이동 수를 줄였다.”
- “함수형 업데이트 순서를 유지하며 Batching으로 중복 commit을 줄였다.”
- “History·폼·이벤트·Effect 회귀를 자동 테스트와 실제 브라우저에서 검증했다.”
- “실패 seed와 단계별 성능 결과를 재현하는 Inspector·실험 환경을 만들었다.”

금지되는 과장:

- “React보다 일반적으로 빠르다.”
- “LIS를 새로 발명했다.”
- “DOM 이동이 7→1이므로 브라우저가 7배 빨라졌다.”
- “실제 React를 개선했다.” — React 원본 적용·검증을 하지 않은 경우.
- “완전한 React 호환성·모든 브라우저 상태 보존을 보장한다.”

---

## 13. 참고 자료와 검증 상태

### 13.1 로컬 입력

- [공식 과제 요구사항](<C:/Users/nica7/Desktop/리액트 조사/w11_미니리액트_요구사항.txt>)
- [자료1](<C:/Users/nica7/Desktop/리액트 조사/자료1.txt>) — 품질·Inspector·Keyed Diff·검증 후보.
- [자료2](<C:/Users/nica7/Desktop/리액트 조사/자료2.txt>) — 실제 React 아키텍처 연구 후보.
- [자료3](<C:/Users/nica7/Desktop/리액트 조사/자료3.txt>) — 외부 Store·우선순위·rebase. 이번 범위 제외.
- [자료4](<C:/Users/nica7/Desktop/리액트 조사/자료4.txt>) — 이전 범위 결정 대화 링크.
- [자료5](<C:/Users/nica7/Desktop/리액트 조사/자료5.txt>) — 자체 엔진 개선과 실제 React 개선 구분.
- [자료6](<C:/Users/nica7/Desktop/리액트 조사/자료6.txt>) — Patch·History·브라우저 상태 설계.
- [자료7](<C:/Users/nica7/Desktop/리액트 조사/자료7.txt>) — anchor·EMPTY·미확정 편집 등 반례.
- [자료8](<C:/Users/nica7/Desktop/리액트 조사/자료8.md>) — Greedy·LIS·Adaptive 비용 분석.

### 13.2 앞선 종합 검토에서 대조한 공식 소스

React 기준은 19.3.1, commit 61aa00df822d0eb76d0362eb8b6fdd3527693efe다. 아래 링크는 알고리즘·동작을 설명하는 근거이며, 이 명세의 자체 API가 React 전체 의미론과 같다는 뜻은 아니다.

- [React placeChild](https://github.com/react/react/blob/61aa00df822d0eb76d0362eb8b6fdd3527693efe/packages/react-reconciler/src/ReactChildFiber.js#L511)
- [React getHostSibling](https://github.com/react/react/blob/61aa00df822d0eb76d0362eb8b6fdd3527693efe/packages/react-reconciler/src/ReactFiberCommitHostEffects.js#L271)
- [React useMemo 구현](https://github.com/react/react/blob/61aa00df822d0eb76d0362eb8b6fdd3527693efe/packages/react-reconciler/src/ReactFiberHooks.js#L2944)
- [React 상태 업데이트 큐 설명](https://react.dev/learn/queueing-a-series-of-state-updates)
- [React useEffect](https://react.dev/reference/react/useEffect)
- [Vue 3.5.45 조건부 LIS](https://github.com/vuejs/core/blob/v3.5.45/packages/runtime-core/src/renderer.ts#L2056)
- [Preact 11.2.0 LIS](https://github.com/preactjs/preact/blob/c95929dd5bac761906626d27b484d9e82e2ba273/src/diff/children.js#L309)
- [HTML input value 표준](https://html.spec.whatwg.org/multipage/input.html#dom-input-value)
- [브라우저 layout 비용](https://web.dev/articles/avoid-large-complex-layouts-and-layout-thrashing)

### 13.3 기존 독립 모델과 프로젝트 검증의 구분

앞선 종합 검토에서 프로젝트 밖의 JavaScript 배열 모델을 실행했다.

- 순열 46,233개.
- BFS 상태 5,913개.
- 삽입·삭제 혼합 4,225쌍.
- 타입 변경 포함 무작위 10,000쌍.
- anchor 탐색의 제한 모델.

[독립 모델 코드](C:/Users/nica7/.codex/visualizations/2026/11/07/01a1b3e1-9ad2-7900-a812-88e78cb9c9f7/mini-react-review-probe/review-probe.cjs) · [당시 결과](C:/Users/nica7/.codex/visualizations/2026/11/07/01a1b3e1-9ad2-7900-a812-88e78cb9c9f7/mini-react-review-probe/results.json)

이 결과는 실제 프로젝트 Diff/Patch·DOM·React 런타임·브라우저 성능·IME의 통과 증거가 아니다. 2026-11-07에 수행한 실제 프로젝트 M1 검증은 아래 13.4절로 별도 기록한다. 과거 독립 모델 수치는 프로젝트 결과에 합산하지 않는다.

**최초 명세 작성 시점(버전 1.0)에는 프로젝트 코드를 변경하지 않았다. 버전 1.1은 사용자의 M0~M1 구현 요청에 따라 실제 구현·검증 결과를 반영했다.**

### 13.4 실제 프로젝트 M0~M1 검증 (2026-11-07)

- 저장소: C:/Github/mini-react, phase1. 시작 commit bdea95c, 시작 시 README만 존재.
- 실행: pnpm typecheck, pnpm test, pnpm test:browser, pnpm build. 현재 Windows의 pnpm PATH 부재는 scripts/pnpm.ps1 보조 실행기로 해결했다.
- 결과: 타입 검사 PASS, 단위·통합 52/52 PASS(5개 파일), Chromium 기능 4/4 PASS, production build PASS.
- 환경: Windows, Node 24.22.1, pnpm 11.25.0, TypeScript 7.0.2, Vite 8.3.6, Vitest 5.1.0, jsdom 31.0.0, Playwright 1.62.1 / Chromium 151.0.7922.34.
- M1 지정 ID: T-V01, T-D01, T-H01, T-C01, T-S01, T-F01, T-M01 통과. 실제 production 모듈 호출을 검증했다.
- 브라우저: 직접 편집/Patch/미확정 편집/Undo/Redo, State 입력/클릭/Memo/Effect/재마운트, 미지원 HTML 거절, 390px/키보드 smoke.
- 실패·수정: Effect 반환 타입 처리, 테스트 함수 상태 타입 추론, 브라우저 실행 파일 설치, innerText/textContent 혼합 oracle 수정. Effect 내부 unmount의 cleanup 누락·중복 가능 경로는 수정하고 2개 회귀 테스트로 고정했다.
- 검증하지 않은 것: B안 성능, keyed identity/최소 이동, Batching, 실제 한글 IME, 전체 브라우저 호환성. 브라우저 실행 시간을 성능 개선 수치로 해석하지 않는다.
- 상세 증거와 후속 범위: [구현 기록](<C:/Github/mini-react/docs/m0-m1.md>) 및 [결과 JSON](<C:/Github/mini-react/docs/validation/m0-m1.json>).

### 13.5 최초 B안 기술 검증 — 당시 스냅샷 (2026-11-07)

- branch phase1에서 단계별 로컬 커밋. [단계·커밋 전체 기록](<C:/Github/mini-react/docs/progress.md>). 원격 push·PR·배포 미수행.
- 단위·통합 157/157, Chromium 19/19 + Firefox 10/10, typecheck/build PASS. 최초 인수 9f3f3d3 시점의 소스·테스트 hash 59개가 검증 당시와 일치했다. 후속 기능 변경 결과는 13.6절로 구분한다.
- 실제 Windows 한글 IME: 요청된 지연 이동/조합 종료/문자·focus 보존 절차에 사용자 직접 확인 PASS. 브라우저명·버전 미제공.
- benchmark: 3세션, 312개 조건 쌍/624개 옵션별 조건, 총 62,244행(counts 624 + warm-up 10,140 + timing 51,480), 구간 통계 4,368개 원본 재계산 일치.
- 해석: 10,000개 stateful 마지막→처음 이동은 9,999→1회, median 시간은 세션별 4.4%/5.1%/6.9% 낮았다. 1,000개 mixed에서는 이동 감소에도 median이 세 세션 모두 높았다. 대규모 no-op 비용도 공개했다. paint·사용자 지연·일반적인 React 대비 우위를 주장하지 않는다.
- [당시 원자료·그래프·해석](<C:/Github/mini-react/docs/benchmark-results-m8.md>) · [최종 감사 JSON](<C:/Github/mini-react/docs/validation/m8.json>) · [기술 인수와 외부 확인 구분](<C:/Github/mini-react/docs/m8-acceptance.md>).
- 외부 미확인: 팀 합의·다른 후보 비교·팀원 설명/변경 연습/실제 발표·원격 CI 실행. 코드·문서 작성 사실로 이 활동을 완료 처리하지 않았다.

### 13.6 브라우저 안정화·no-op 후속 재검토 (2026-11-07)

- [x] 후속 26/29 실패 원본·trace를 보존하고 재현한다. — 기존 29/29를 허위로 취급하지 않음. 기본 재현 29/29, worker 2/1 진단 모두 통과.
- [x] 서버 기동/모듈 응답/앱 ready/action/assertion/전체 시간을 분리한다. — 모듈 34개 준비 후 health 200, 앱 초기화 확인, 단계별 JSON.
- [x] 기존 action/assertion을 유지하며 실행 불안정성을 수정한다. — CRUD 목적별 분리, 정렬→수동 이동 경계 유지. worker 2/test timeout 30초/retry 0 유지.
- [x] 기본 Chromium+Firefox 전체를 새 서버·브라우저로 3회 연속 통과한다. — 31/31씩, 67.84/67.57/68.41초, skipped/unexpected/flaky/retry 모두 0.
- [x] 최적화 전 동일 하네스 기준선과 정밀 프로파일링을 분리해 보존한다. — baseline-v1, noop-baseline-before / noop-profile-before.
- [x] 정확성 검사와 DOM binding 검사를 유지하는 no-op 개선·반례를 구현한다. — 비교용 host 객체 할당 제거, 깊은 불변 whole-root 검증 캐시. T-N01~N07 추가.
- [x] 단위·통합/브라우저/타입/build를 검증한다. — 184/184, 31×3, typecheck/build PASS; 실제 IME는 이전 사용자 보고와 현재 합성 회귀를 구분.
- [x] 이전·이후 전체 3세션을 같은 고정 build/harness로 비교하고 원본 통계를 감사한다. — 4크기×2payload×6경로, 28,728 raw / 23,760 timing / 2,016 통계 일치. 전후·세션 간 counts 동일. 결과 dbdc4de.
- [x] 작은 목록/재배치/폼·새 VDOM 생성 비용 및 불리한 p95를 포함해 성능 보고서를 확정한다. — 큰 stateful 네 no-op cycle median 29–62% 감소. 새 동등 트리 생성+cycle 약 5%, 재배치 3–17% 악화 및 일부 cycle p95 악화 보존. 별도 GC/CPU 진단과 한계를 기록.
- [x] 후속 인수·보고서·단계별 커밋과 최종 clean 상태를 대조한다. — phase1 유지, 후속 6개 로컬 커밋(7757e3c → 4d5a66f), 미커밋 변경 없음. 원격 push/PR/배포 없음.

[후속 진단·원리](<C:/Github/mini-react/docs/browser-noop-followup.md>) · [정확성 증거](<C:/Github/mini-react/docs/validation/noop-followup.json>) · [커밋 진행](<C:/Github/mini-react/docs/progress.md>) · [당시 성능 보고서 보존본](<C:/Github/mini-react/docs/benchmark-results-noop.md>)

### 13.7 실제 TaskApp 표현 재사용·캐시 정책 후속 검증 (2026-11-08, 진행 중)

- [x] 현재 phase1 / 4d5a66f(clean)를 확인하고 같은 브랜치에서 단계별 로컬 커밋으로 진행한다. — 비교 설계 6c3fa1f, 앱 변경 5ed7f34, 첫 정식 결과 dfd20dc, E3 후보 ff9e24e. 원격 push/PR/merge/배포 없음.
- [x] E0/E1/E2 × A0/A1의 실제 TaskApp·소스·의존성·build·하네스·seed를 고정하고 사전 반복/채택 기준을 기록한다. — 기준을 불리한 결과에 맞춰 완화하지 않음.
- [x] 루트 useMemo와 안정된 함수형 updater로 목록 표현·행 callback을 재사용한다. — 자식 Hook/자동 props memo/함수 props 무시 없음. 단계 B 관련 64개·TaskApp browser 8개·타입/build 통과. 최종 전체 검증과 별도임.
- [x] 여섯 조합의 production 정식 3세션과 모든 action의 State/DOM/입력/순서/identity oracle을 완료한다. — 720/720 조건, raw 48,294 / 측정 작업 41,040 / action 58,320, 통계 12,024·비교 18,036·그래프 240점 독립 검산. 10,000개는 stress로 구분.
- [x] 앱 효과와 엔진 효과를 분리하고 새 생성·CRUD 하위 action·재배치·fresh 초기화·불리한 p95를 보존한다. — 반복 재사용 이득과 검색/정렬/이동 등 회귀를 함께 기록. 일반 성능 개선/최종 채택으로 해석하지 않음.
- [x] 별도 CPU/할당/GC/보유 heap/long task/정의된 Paint 진단을 수행한다. — 작은 진단 12개와 본 진단 24개 완료. 최초 CPU timeDelta 분석 실패와 수정 근거도 보존. 실제 화면 표시 완료나 모든 지연의 GC 원인을 단정하지 않음.
- [x] E3의 깊은 증명 순서·인증 보관 범위를 수정하고 반례를 검증한다. — 변경 전 Proxy 반례 2개 실패 보존, 변경 후 관련 19/19·전체 단위/통합 203/203·typecheck/build PASS. VNode 불변성 증명과 전체 root의 문맥 검증을 구분하며 DOM/plan/폼/Effect/IME 검사는 유지.
- [x] 고정 A1의 E1/E2/E3 및 고정 E3의 A0/A1 새 정식 3세션을 완료하고 원자료·회귀 판정을 감사한다. — task-candidate-v1의 480개 조건, raw 32,196 / 측정 작업 27,360 / action 38,880, 통계·비교 각 8,016 / 그림 480점 검산. 2026-11-09 완료. 작은 40개/stress 10개 smoke를 성능 채택 근거로 쓰지 않음.
- [ ] 후보의 별도 진단과 필요한 새 3세션 n=180 p95 보충을 수행해 최종 캐시 정책·적용 범위를 선택한다. — 회귀·불확실성을 숨기거나 기준을 완화하지 않음.
- [ ] 최종 선택 소스에서 typecheck / 전체 unit·integration / production build / 기본 Chromium+Firefox 전체 33개를 새 서버·브라우저로 3회 연속 검증한다. — worker 2/timeout 30초/retry 0, skip·assertion 약화 없음. 이전 184/31 또는 후보 203을 최종 새 검증으로 재인용하지 않음.
- [ ] 최종 보고서·체크리스트·외부 파일 hash·기능 소스 증거·단계별 커밋과 phase1 clean 상태를 대조한다. — 현재는 진행 중이며 최종 완료 표시가 아님.
- [x] 이전 보고서·원자료·실제 IME 사용자 확인 시점을 보존한다. — 원본 v1.8과 진행 v1.9 사본/hash를 저장소에 보존하되, Desktop의 원본 파일 자체가 Git 커밋에 포함됐다고 표현하지 않음. 팀 합의/다른 팀 후보/팀원 설명·발표/원격 CI는 계속 미확인.

[사전 기준](<C:/Github/mini-react/docs/task-app-comparison-plan.md>) · [작업 진행](<C:/Github/mini-react/docs/task-app-followup.md>) · [앱 변경 원리](<C:/Github/mini-react/docs/task-app-reuse.md>) · [첫 정식 결과](<C:/Github/mini-react/docs/task-app-baseline-results.md>) · [E3 후보·반례](<C:/Github/mini-react/docs/task-app-engine-candidate.md>) · [외부 체크리스트 갱신 영수증](<C:/Github/mini-react/docs/validation/task-checklist-progress.json>)

### 13.8 E3 후보 정식 결과·진단 이력 (2026-11-09, 최종 인수 전)

- [x] 후보의 새 3세션 정식 비교와 통계/판정/그림 감사를 완료한다. — 480/480 조건, 실패·재시도 없음. 큰 S1 검색/정렬 회귀와 이동 p95, 작은 조건/CRUD 하위 action의 초과도 보존한다.
- [x] 후보의 별도 CPU·allocation·GC·heap·long task·Paint 진단 36개를 수집·감사한다. — 동일 A1의 E1/E2/E3, 1,000/10,000개. 동결·증명 self와 보유 heap은 E2보다 줄었지만 allocation 추정량은 줄지 않았고 dispose 뒤 heap은 E1보다 컸다. 모든 비교군의 DOM/listener 수는 초기값으로 돌아왔다. 실제 E3 viewport PNG 확인도 완료.
- [x] 사전 허용 범위를 넘은 엔진 5개·앱 6개 조건을 모두 보충 대상으로 고정한다. — 1,000개 CRUD, 10,000개 search/sort/move/CRUD, 100개 search/filter/dirty 순서. 기존 네 비교군·warm-up·하네스·oracle 유지.
- [ ] 위 조건을 새 3세션 n=180으로 보충하고 최종 정책·적용 범위를 선택한다. — 원래 raw와 합치지 않고 불리한 후보를 보존한다. 이번 갱신 시점에는 보충 실행 전이다.
- [ ] 최종 선택 소스에서 typecheck / 전체 unit·integration / build / 기본 Chromium+Firefox 전체 3회와 문서·hash·단계별 커밋·clean 인수를 완료한다. — 진행 중이며 이전 결과로 대체하지 않는다.

[후보 결과·진단 해석](<C:/Github/mini-react/docs/task-app-engine-candidate.md>) · [진단 원자료·표](<C:/Github/mini-react/docs/bench/task-diagnostic-candidate-v1/diagnostics.md>) · [보충 계획](<C:/Github/mini-react/docs/bench/task-candidate-v1/tail-supplement-plan-e3.json>) · [항목별 완료 조건 대조](<C:/Github/mini-react/docs/task-app-completion-audit.md>) · [v1.10 외부 파일 영수증](<C:/Github/mini-react/docs/validation/task-checklist-candidate.json>)

### 13.9 E3 기각·보충 보존·E4 후보 검증 (2026-11-09, 진행 중)

- [x] 1,000개 CRUD를 기존 네 비교군의 새 3세션 n=180으로 보충하고 통계를 감사한다. — 12개 조건, raw 2,304 / 측정 작업 2,160 / action 10,800, 통계·비교 각 672개. 최초 n=60과 합치지 않음.
- [x] 회귀가 반복된 E3/A1의 일반 채택을 기각하고 불리한 결과를 보존한다. — E3 A0→A1 toggle median +44.02/+14.94/+13.37%, p95 +61.26/+29.73/+29.57%. 세 세션 모두 앱 gate 초과, 기준 완화 없음.
- [x] 기각 뒤 10,000개 보충을 첫 세션 완료 경계에서 중단하고 모든 자료를 보존한다. — 완료 세션 16개 조건/raw 2,992/action 5,760과 빈 다음 세션 원본까지 보존. 3세션 보충 PASS가 아님. 100개 보충은 후보 기각으로 미실행이며 해당 tail은 미확인. 원래 보충 계획과 중단 판단/종료 기록을 모두 보존.
- [x] E3 고정 A0/A1의 별도 CPU·할당·GC·heap 진단 8개를 실행·감사한다. — toggle 차이는 여러 구간에 걸쳐 있으며 GC 단독 원인 또는 A1만의 객체 누수를 단정하지 않음.
- [x] E4의 인증 보관 범위 제한과 한도 이후의 깊은 검사 반례를 구현·검증한다. — 2a21ec7, freezeTree 호출당 새 인증 최대 64개. E3의 상한 반례 실패(386개)를 보존하고 E4 관련 14/14·전체 단위/통합 205/205·typecheck/build PASS. 기존 Proxy·문맥·DOM·폼·Effect 계약 유지. T-N08 추가, 현재 계약 ID 79개.
- [ ] E4의 고정 A1 엔진 비교와 같은 E4의 A0/A1 앱 비교를 새 3세션으로 수행·감사하고 최종 정책을 선택한다. — 앱·하네스·seed·원 gate 유지. 작은 smoke를 성능 채택으로 사용하지 않음.
- [ ] 최종 소스의 typecheck / 전체 unit·integration / build / 기본 Chromium+Firefox 전체 33개를 새 서버·브라우저로 3회 연속 인수한다. — 후보 205개 결과와 이전 수동 IME 보고로 대신하지 않음.
- [ ] 최종 정책·보고서·외부 원본 hash·단계별 커밋·phase1 clean을 대조한다. — 진행 중이며 기술 인수 완료 표시가 아님.

[기각·보충·진단](<C:/Github/mini-react/docs/task-app-tail-results.md>) · [E4 원리·검증 계획](<C:/Github/mini-react/docs/task-app-bounded-candidate.md>) · [E4 정확성](<C:/Github/mini-react/docs/validation/task-e4-correctness/result.json>) · [v1.11 외부 파일 영수증](<C:/Github/mini-react/docs/validation/task-checklist-bounded-candidate.json>)
